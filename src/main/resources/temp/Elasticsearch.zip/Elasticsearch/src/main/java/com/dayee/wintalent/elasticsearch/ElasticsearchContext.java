
package com.dayee.wintalent.elasticsearch;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import com.dayee.wintalent.elasticsearch.constant.Constants;
import com.dayee.wintalent.elasticsearch.service.CorpService;
import com.dayee.wintalent.elasticsearch.thread.ResumeConsumerRunnable;
import com.dayee.wintalent.elasticsearch.thread.ResumePoolManager;
import com.dayee.wintalent.elasticsearch.timer.QuartzServiceManage;
import com.dayee.wintalent.elasticsearch.util.ConfigUtils;

@Component
public class ElasticsearchContext implements ApplicationRunner {

    @Autowired
    private CorpService corpService;

    @Override
    public void run(ApplicationArguments args) {

        corpService.refreshCorpList();

        QuartzServiceManage.init();

        if (ConfigUtils.isRabbitmqEnable()) {
            return;
        }
        for (int index = 0; index < Constants.CONSUMER_THREAD_SIZE; index++) {
            ResumePoolManager.addConsumerListener(new ResumeConsumerRunnable());
        }
    }
}
