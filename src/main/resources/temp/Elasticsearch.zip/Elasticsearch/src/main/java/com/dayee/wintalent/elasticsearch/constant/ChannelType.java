
package com.dayee.wintalent.elasticsearch.constant;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ChannelType  {

    /** 网络、机构、内荐、中介、校园、其他 */
    public static final int             AGENT                       = 1;

    /** 前台品牌 */
    public static final int             WEB                         = 2;

    /** 网络 */
    public static final int             NET                         = 3;

    /** 公共人才库 */
    public static final int             CAIKU                       = 4;

    /** 个人内荐 */
    public static final int             INNER                       = 5;

    /** 机构内荐 */
    public static final int             ORG                         = 6;

    /** 校园 */
    public static final int             CAMPUS                      = 7;

    /** 其它 */
    public static final int             OTHER                       = 8;

    /** 主动呼出 */
    public static final int             ZDHC                        = 10;

    /** 再次入职 */
    public static final int             ZCRZ                        = 11;

    /** 自荐 */
    public static final int             ZJ                          = 12;

    /** 媒体广告 */
    public static final int             MTGG                        = 13;

    /** 招聘会 */
    public static final int             ZPH                         = 14;                                 

    /** 微信举贤宝 */
    public static final int             WXJXB                       = 15;                                 

    /** 举贤宝APP */
    public static final int             JXBAPP                      = 16;

    /** 非凡网 */
    public static final int             FEIFAN                      = 17;                                 

    /** 手机端招聘前台-微信前台招聘 */
    public static final int             MOBWEB                      = 18;

    /** 易信举贤宝 */
    public static final int             YXJXB                       = 19;

    /** 爱奇艺app 手机端招聘前台-微信前台招聘 */
    public static final int             AIQIYI_APP                  = 21;

    /** e成 */
    public static final int             ECHENG                      = 22;                                

    /** 手机web前台 */
    public static final int             MOBILE_WEBSTIE              = 23;

    /** 微内招 */
    public static final int             IRECURIT                    = 24;

    /** 外推渠道：社会 校园 海外实习生 用户推荐的内推简历 */
    public static final int             OUTER_RECOMMEND             = 25;

    /** 内部招聘PC端 */
    public static final int             NBZPPCD                     = 26;

    /** 内部招聘 */
    public static final int             NBZP                        = 27;                                 

    /** ICBC融E联 */
    public static final int             ICBCELINE                   = 28;

    /** 专场招聘 */
    public static final int             SPECIAL                     = 32;                                

    /** 小荐人悬赏聘 */
    public static final int             XJR                         = 34;

    /** 小荐人普通职位 */
    public static final int             XJR_NORMAL                  = 37;

    /** 汉能app */
    public static final int             HANERGYAPP                  = 35;

    /** 第三方推荐平台（E成内推等） */
    public static final int             THIRD_PARTY_RECOMMEND       = 36;

    /**简历来源，内推码 */
    public static final int             RESUME_SOURCE_ACTYCO        = 38;

    /** 内外部推荐 */
    public static final int             INNER_EXTERNAL_RECOMMEND    = 200;

    /** 新浪 */
    public static final int             SINA                        = 30;

    /** 内部推荐PC端 */
    public static final int             INNER_RECOMMEND             = 20;

    /** 输入方式-渠道字典 */
    public static final int             INPUT_MODE_DIC              = 1;

    /** 输入方式-手动 */
    public static final int             INPUT_MODE_MANUAL           = 2;

    /** VIPS-自猎 */
    public static final int             VIPS_OWN                    = 45;

    /** 500号前台模板 */
    public static final int             FRONT_WEB_500               = 46;     

    private static Map<Integer, String> channelNameMap;

    /** 可管理的渠道类型 */
    public static final List<Integer>   canManageChannelTypeList    = new ArrayList<Integer>() {
                                                                        {
                                                                            add(NET);
                                                                            add(INNER);
                                                                            add(ORG);
                                                                            add(CAMPUS);
                                                                            add(OTHER);
                                                                            add(AGENT);
                                                                            add(ZDHC);
                                                                            add(ZCRZ);
                                                                            add(ZJ);
                                                                            add(MTGG);
                                                                            add(ORG);
                                                                            add(CAMPUS);
                                                                            add(OTHER);
                                                                            add(AGENT);
                                                                            add(ZDHC);
                                                                            add(ZCRZ);
                                                                            add(ZJ);
                                                                            add(MTGG);
                                                                            add(ZPH);
                                                                            add(WXJXB);
                                                                            add(JXBAPP);
                                                                            add(MOBWEB);
                                                                            add(INNER_RECOMMEND);
                                                                            add(ECHENG);
                                                                            add(IRECURIT);
                                                                            add(NBZPPCD);
                                                                            add(NBZP);
                                                                            add(OUTER_RECOMMEND);
                                                                            add(XJR);
                                                                            add(XJR_NORMAL);
                                                                            add(INNER_EXTERNAL_RECOMMEND);
                                                                            add(HANERGYAPP);
                                                                            add(MOBILE_WEBSTIE);
                                                                            add(SINA);
                                                                            add(THIRD_PARTY_RECOMMEND);
                                                                            add(SPECIAL);
                                                                            add(FRONT_WEB_500);
                                                                        }
                                                                    };

    /** 搜狐网络渠道  */
    public static final List<Integer>   canSohuChannelType          = new ArrayList<Integer>() {
                                                                        {
                                                                            add(AGENT);
                                                                            add(NET);
                                                                            add(INNER);

                                                                        }
                                                                    };

    public static final List<Integer>   commonManageChannelTypeList = new ArrayList<Integer>() {
                                                                        {
                                                                            add(NET);
                                                                            add(INNER);
                                                                            add(ORG);
                                                                            add(CAMPUS);
                                                                            add(OTHER);
                                                                            add(ZDHC);
                                                                            add(ZCRZ);
                                                                            add(ZJ);
                                                                            add(MTGG);
                                                                            add(ZPH);
                                                                        }
                                                                    };

}
