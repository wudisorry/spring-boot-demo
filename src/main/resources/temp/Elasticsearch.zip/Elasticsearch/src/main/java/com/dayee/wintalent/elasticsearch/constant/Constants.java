
package com.dayee.wintalent.elasticsearch.constant;

public class Constants {

    /** es查询最多返回记录数 */
    public static final int     BATCH_ES_QUERY_SIZE         = 3000;

    /** 单次查询数据库 */
    public static final int     BATCH_DB_QUERY_SIZE         = 1000;

    /** 一次请求（es服务）索引简历数 */
    public static final int     BATCH_ES_INDEX_SIZE         = 1000;

    /** 消费者pool最大简历数量 */
    public static final Integer RESUME_POOL_SIZE            = 50000;

    /** 每个线程处理10万 */
    public static final Integer THREAD_HANDLE_SIZE          = 100000;

    /** 消费者线程数量 8*/
    public static final Integer CONSUMER_THREAD_SIZE        = 8;

    /** 生产者最大线程数量 4*/
    public static final Integer MAX_FETCH_THREAD            = 4;

    public static final String  FID                         = "FID";

    public static final String  RESUME_ID                   = "F_RESUME_ID";

    public static final String  TEXT_CONTENT                = "F_TEXT_CONTENT";

    public static final String  F_CORP_NAME                 = "F_CORP_NAME";

    public static final String  F_CONTENT_1                 = "F_CONTENT1";

    public static final String  FULL_TEXT_CH                = "full_text_ch";

    public static final String  F_CONTENT_2                 = "F_CONTENT2";

    public static final String  FULL_TEXT_EN                = "full_text_en";

    public static final String  F_CONTENT_3                 = "F_CONTENT3";

    public static final String  F_CONTENT_4                 = "F_CONTENT4";

    public static final String  F_NAME                      = "F_NAME";

    public static final String  F_GENDER                    = "F_GENDER";

    public static final String  F_BIRTHDAY                  = "F_BIRTHDAY";

    public static final String  F_MOBILE_PHONE              = "F_MOBILE_PHONE";

    public static final String  F_EMAIL                     = "F_EMAIL";

    public static final String  F_GRADUATION_SCHOOL         = "F_GRADUATION_SCHOOL";

    public static final String  F_BEGIN_DATE                = "F_BEGIN_DATE";

    public static final String  F_END_DATE                  = "F_END_DATE";

    public static final String  F_IS_LAST_RECORD            = "F_IS_LAST_RECORD";

    public static final String  F_SCHOOL                    = "F_SCHOOL";

    public static final String  F_EDUCATION                 = "F_EDUCATION";

    public static final String  F_SUBJECT                   = "F_SUBJECT";

    public static final String  F_DEGREE                    = "F_DEGREE";

    public static final String  F_NAME_CH                   = "F_NAME_CH";

    public static final String  F_NAME_EN                   = "F_NAME_EN";

    public static final String  F_POST_ID                   = "F_POST_ID";

    public static final String  F_POST_TYPE                 = "F_POST_TYPE";

    public static final String  F_POST_NAME                 = "F_POST_NAME";

    public static final String  F_PROJECT_ID                = "F_PROJECT_ID";

    public static final String  F_ORG_ID                    = "F_ORG_ID";

    public static final String  F_EXTERNAL_NAME             = "F_EXTERNAL_NAME";

    public static final String  F_EXTERNAL_NAME_CH          = "F_EXTERNAL_NAME_CH";

    public static final String  F_EXTERNAL_NAME_EN          = "F_EXTERNAL_NAME_EN";

    public static final String  F_WORK_YEARS                = "F_WORK_YEARS";

    public static final String  F_WORK_PLACE                = "F_WORK_PLACE";

    public static final String  F_LIVING_PLACE              = "F_LIVING_PLACE";

    public static final String  F_ACCOUNT_PLACE             = "F_ACCOUNT_PLACE";

    public static final String  F_GRADUATION_DATE           = "F_GRADUATION_DATE";

    public static final String  F_ID_NUM                    = "F_ID_NUM";

    public static final String  F_ADD_USER                  = "F_ADD_USER";

    public static final String  F_ADD_DATE                  = "F_ADD_DATE";

    public static final String  F_ORIGINAL_ID               = "F_ORIGINAL_ID";

    public static final String  F_LABEL_ID                  = "F_LABEL_ID";

    public static final String  F_APPLY_ID                  = "F_APPLY_ID";

    public static final String  F_PERS_CODE                 = "F_PERS_CODE";

    public static final String  F_UPDATE_DATE               = "F_UPDATE_DATE";

    public static final String  F_CURRENT_INTO_CAND_DATE    = "F_CURRENT_INTO_CAND_DATE";

    public static final String  F_REASON                    = "F_REASON";

    public static final String  F_RECRUIT_TYPE              = "F_RECRUIT_TYPE";

    public static final String  F_RESUME_SOURCE             = "F_RESUME_SOURCE";

    public static final String  F_NET_CHANNEL_ID            = "F_NET_CHANNEL_ID";

    public static final String  F_WEB_USER_ID               = "F_WEB_USER_ID";

    public static final String  F_BRAND_ID                  = "F_BRAND_ID";

    public static final String  F_IS_LOCKED                 = "F_IS_LOCKED";

    public static final String  F_IS_SENIOR                 = "F_IS_SENIOR";

    public static final String  F_INTO_TALENTPOOL_TACHE     = "F_INTO_TALENTPOOL_TACHE";

    public static final String  F_HAD_EV_TYPE               = "F_HAD_EV_TYPE";

    public static final String  F_FIRST_INTO_CAND_DATE      = "F_FIRST_INTO_CAND_DATE";

    public static final String  F_OVERALL_SCORE             = "F_OVERALL_SCORE";

    public static final String  F_HEADHUNTING_ID            = "F_HEADHUNTING_ID";

    public static final String  F_TALENT_POST_TYPE          = "F_TALENT_POST_TYPE";

    public static final String  F_TALENTPOOL_TYPE           = "F_TALENTPOOL_TYPE";

    public static final String  F_IS_DISUSE                 = "F_IS_DISUSE";

    public static final String  F_SHOW_LIST                 = "F_SHOW_LIST";

    public static final String  F_IS_INNER                  = "F_IS_INNER";

    public static final String  F_IS_BLACKUSER              = "F_IS_BLACKUSER";

    public static final String  F_CONTACT_STATE             = "F_CONTACT_STATE";

    public static final String  F_SUITABLE_OR_IMPROPER      = "F_SUITABLE_OR_IMPROPER";

    public static final String  F_IS_HIGHTEST_EDUCATION_RECORD = "F_IS_HIGHTEST_EDUCATION_RECORD";

    public static final String  F_HIGHTEST_DEGREE           = "F_HIGHTEST_DEGREE";

    public static final String  F_FIRST_DEGREE              = "F_FIRST_DEGREE";

    public static final String  F_STAFF_NO                  = "F_STAFF_NO";

    public static final String  F_UNDER_GRADUATION_DATE     = "F_UNDER_GRADUATION_DATE";

    public static final String  F_EVALUATE_VALUE            = "F_EVALUATE_VALUE";

    public static final String  F_ITEM_VALUE                = "F_ITEM_VALUE";

    public static final String  F_INNER_RECRUIT_TYPE        = "F_INNER_RECRUIT_TYPE";

    public static final String  F_REMARK                    = "F_REMARK";

    public static final String  F_LANGUAGE_TYPE             = "F_LANGUAGE_TYPE";

    public static final String  F_LANGUAGE_LEVEL            = "F_LANGUAGE_LEVEL";

    public static final String  F_SPEAKING_ABILITY          = "F_SPEAKING_ABILITY";

    public static final String  F_WRITE_ABILITY             = "F_WRITE_ABILITY";

    public static final String  F_SEND_RESUME_RECEIVE_USER  = "F_SEND_RESUME_RECEIVE_USER";

    public static final String  F_CAREERFAIR_ID             = "F_CAREERFAIR_ID";

    public static final String  F_SITE                      = "F_SITE";

    public static final String  F_REJECTED_OFFER_REASON     = "F_REJECTED_OFFER_REASON";

    public static final String  F_STRUCTURE_ID              = "F_STRUCTURE_ID";

    public static final String  F_RESUME_ANNEX_SIZE         = "F_RESUME_ANNEX_SIZE";

    public static final String  F_FOLDER_ID                 = "F_FOLDER_ID";

    public static final String  F_SHOW_IN_TALENTPOOL        = "F_SHOW_IN_TALENTPOOL";

    public static final String  F_IS_HIGHEND_TALENTPOOL     = "F_IS_HIGHEND_TALENTPOOL";

    public static final String  F_RESUME_OWNERSHIP          = "F_RESUME_OWNERSHIP";

    public static final String  F_APPLY_STATUS              = "F_APPLY_STATUS";

    public static final String  F_APPLY_STATUS_TYPE         = "F_APPLY_STATUS_TYPE";

    public static final String  SO_FAR                      = "1000-01-01";

    public static final String  SO_FAR_1                    = "1000-01-01 00:00:00.0";

    public static final String  TYPE_APPLY                  = "apply";

    public static final String  TYPE_CAND                   = "cand";

    public static final String  TABLE_APPLY                 = "T_APPLY_";

    public static final String  TABLE_CAND                  = "T_CAND_";

    public static final int     RESUME_TYPE_APPLY           = 1;                      // 应聘简历

    public static final int     RESUME_TYPE_CAND            = 2;                      // 人才库简历

    public static final String  PERS_INFO                   = "PERS_INFO";

    public static final String  EDUC_EXPE                   = "EDUC_EXPE";

    public static final String  WORK_EXPE                   = "WORK_EXPE";

    public static final String  JOB_INTENTION               = "JOB_INTENTION";

    public static final String  LANG_ABIL                   = "LANG_ABIL";

    public static final String  CH                          = "ch";

    public static final String  EN                          = "en";

    public static final int     CHINA_LOCALE                = 1;

    public static final int     ENGLISH_LOCALE              = 2;

    public static final String  RESUME_VALUE_NULL_START_STR = "N/";

    public static final int     YES                         = 0;

    public static final int     NO                          = 1;

    public static final String  EDUCATION_BACHELOR         = "本科";

    public static final String  EDUCATION__COLLEGE         = "大专";

    /** 热门候选人标签id */
    public static final Integer LABEL_HOT_CANDIDATES        = 160005;

    public static final Integer DEFAULT_ORG_ID              = 0;

    /** 机构类型为公司的值 */
    public static final Integer ORG_TYPE_COMPANY            = 1;

    /** 面试待安排 */
    public static final Integer APPLY_STATUS_UNSCHEDULED    = 7;

    /** 面试流程中 */
    public static final Integer APPLY_STATUS_UNEVALUATED    = 9;

    /** 已面试评价 */
    public static final Integer APPLY_STATUS_EVALUATED      = 10;

    /** 内推推荐(推荐别人) */
    public static final Integer RECRUIT_TYPE_INNER_RECOMMEND= 8;

    /** 内推推荐(校园) */
    public static final Integer INNER_RECOMMEND_SCHOOL      = 1;

    /** 内推推荐(社会) */
    public static final Integer INNER_RECOMMEND_SOCIAL      = 2;

    /** 简历类别未分类code */
    public static final String TALENT_POOL_RESUME_NO_TYPE_CODE = "0/15020/1";

    /** 职位类别未分类code */
    public static final String TALENT_POOL_POST_NO_TYPE_CODE   = "0/12270/1";

    /** 超级用户id */
    public static final int SUPER_ID                           = 1;

}
