
package com.dayee.wintalent.elasticsearch.constant;

import java.util.HashMap;
import java.util.Map;

/**
 * 搜索相关常量
 *
 * @author wsk
 * @date 2019/9/16
 */
public class SearchConstants {

    /**
     * 常量
     */
    public static final int           MAX_RESUME_ROW_SIZE             = 1000;

    public static final String        YES                             = "0";

    public static final String        NO                              = "1";

    public static final int           INDEX_MAX_RESULT_WINDOW         = 10000;

    public static final String        INTO_TALENT_POOL_TACHE_STORE    = "999999";

    /**
     * 查询
     */
    public static final String        MUST                            = "must";

    public static final String        SHOULD                          = "should";

    public static final String        MUST_NOT                        = "must_not";

    public static final String        BOOL                            = "bool";

    public static final String        EXISTS                          = "exists";

    public static final String        GTE                             = "gte";

    public static final String        LTE                             = "lte";

    public static final String        RANGER                          = "range";

    public static final String        WILDCARD                        = "wildcard";

    public static final String        MATCH_PHRASE                    = "match_phrase";

    public static final String        FILTER                          = "filter";

    public static final String        TERM                            = "term";

    public static final String        ORDER                           = "order";

    public static final String        FIELD                           = "field";

    public static final String        ASC                             = "ASC";

    public static final String        DESC                            = "DESC";

    public static final String        RAW                             = "raw";

    /**
     * 企业code
     */
    public static final String        SOHO                            = "sohu";

    public static final String        MIDEA                           = "midea";

    /**
     * 字段
     */
    public static final String        UNIQUE_KEY                      = "uniqueKey";

    public static final String        RESUME_ID                       = "resumeId";

    public static final String        NAME                            = "name";

    public static final String        NAME_EN                         = "enName";

    public static final String        CORP_NAME                       = "corpName";

    public static final String        SCHOOL                          = "school";

    public static final String        TARGET_SCHOOL_PARAM             = "keyword_targetSchool";

    public static final String        POST_TYPE                       = "postType";

    public static final String        TALENT_POOL_POST_TYPE           = "talentPoolPostType";

    public static final String        TALENT_POST_TYPE                = "talentPostType";

    public static final String        GENDER                          = "gender";

    public static final String        EDUCATION                       = "education";

    public static final String        FIRST_DEGREE                    = "firstDegree";

    public static final String        FIRST_DEGREE_SCHOOL             = "firstDegreeSchool";

    public static final String        HIGHEST_DEGREE                  = "highestDegree";

    public static final String        HIGHTEST_DEGREE_SCHOOL          = "hightestDegreeSchool";

    public static final String        LABEL_ID                        = "labelId";

    public static final String        LABEL_ID_PARAM                  = "labelIdStr";

    public static final String        FOLDER_ID                       = "folderId";

    public static final String        WORK_YEARS                      = "workYears";

    public static final String        LIVING_PLACE                    = "livingPlace";

    public static final String        BIRTHDAY                        = "birthday";

    public static final String        EMAIL                           = "email";

    public static final String        ORIGINAL_ID                     = "originalId";

    public static final String        ORIGINAL_ID_PARAM               = "netChannelOriginalId";

    public static final String        RECRUIT_TYPE                    = "recruitType";

    public static final String        INNER_RECRUIT_TYPE              = "innerRecruitType";

    public static final String        INNER_RECRUIT_TYPE_PARAM        = "queryInnerRecruitType";

    public static final String        PERS_CODE                       = "persCode";

    public static final String        PERS_CODE_PARAM                 = "personnelId";

    public static final String        STAFF_NO                        = "staffNo";

    public static final String        KEYWORD_SMART                   = "keyword_smart";

    public static final String        KEYWORD_SMART_TABLE             = "smartkeywordTable";

    public static final String        KEYWORD_MAP                     = "keywordMap";

    public static final String        FULL_TEXT                       = "fullText";

    public static final String        FULL_TEXT_PARAM                 = "keyword_resume";

    public static final String        POST_ID                         = "postId";

    public static final String        POST_ID_PARAM                   = "postIdStr";

    public static final String        POST_NAME                       = "postName";

    public static final String        POST_NAME_PARAM                 = "keyword_post";

    public static final String        EXTERNAL_POST_NAME              = "externalPostName";

    public static final String        EXTERNAL_POST_NAME_PARAM        = "externalPositionName";

    public static final String        GRADUATE_DATE                   = "graduateDate";

    public static final String        FINAL_GRADUATION_BEGIN_DATE     = "finalGraduationBeginDate";

    public static final String        FINAL_GRADUATION_END_DATE       = "finalGraduationEndDate";

    public static final String        UNDER_GRADUATE_DATE             = "underGraduateDate";

    public static final String        UNDER_GRADUATION_BEGIN_DATE     = "underGraduationDate";

    public static final String        UNDERE_GRADUATION_END_DATE      = "underGraduationEndDate";

    public static final String        MOBILE_PHONE                    = "mobilePhone";

    public static final String        MOBILE_PHONE_PARAM              = "queryPhoneNum";

    public static final String        ID_NUM                          = "idNum";

    public static final String        ID_NUM_PARAM                    = "identityCard";

    public static final String        REMARK                          = "remark";

    public static final String        REMARK_PARAM                    = "keyword_remark";

    public static final String        SEND_TO                         = "sendTo";

    public static final String        CAREER_FAIRID                   = "careerFairId";

    public static final String        SITE                            = "site";

    public static final String        SITE_PARAM                      = "sites";

    public static final String        LANGUAGE_LEVEL                  = "languageLevel";

    public static final String        SPEAKING_SKILLS                 = "speakingSkills";

    public static final String        WRITE_SKILLS                    = "writeSkills";

    public static final String        CONTACT_STATE                   = "contactState";

    public static final String        SUITABLE_OR_IMPROPER            = "suitableOrImproper";

    public static final String        SIGN_HOT_USER                   = "signHotUser";

    public static final String        SIGN_HOT_USER_PARAM             = "signHotUserIds";

    public static final String        SIGN_HOT_DATE                   = "signHotDate";

    public static final String        SIGN_HOT_BEGIN_TIME             = "signHotBeginTime";

    public static final String        SIGN_HOT_END_TIME               = "signHotEndTime";

    public static final String        SUBJECT                         = "subject";

    public static final String        ACCOUNT_PLACE                   = "accountPlace";

    public static final String        RESUME_SOURCE                   = "resumeSource";

    public static final String        NET_CHANNEL_ID                  = "netChannelId";

    public static final String        BRAND_ID                        = "brandId";

    public static final String        HEAD_HUNTING_ID                 = "headhuntingId";

    public static final String        SOURCE_CHANNEL                  = "sourceChannel";

    public static final String        NET_CHANEL_LIST                 = "netChannelList";

    public static final String        RESUME_TYPE                     = "resumeType";

    public static final String        SENIOR_RESUME_TYPE              = "seniorResumeType";

    public static final String        STRUCTURE_ID                    = "structureId";

    public static final String        STRUCTURE_ID_PARAM              = "talentPoolCategory";

    public static final String        EXPECT_WORK_PLACE               = "expectWorkPlace";

    public static final String        TALENTPOOL_TYPE                 = "talentPoolType";

    public static final String        CURRENT_INTO_CAND_DATE          = "currentIntoCandDate";

    public static final String        TALENT_POOL_RESUME_TYPE         = "talentResumeType";

    public static final String        ALL_TALENT_POOL_RESUME_TYPE     = "allTalentPostTypeList";

    public static final String        OVERALLSCORE                    = "overallScore";

    public static final String        HAD_EV_TYPE                     = "hadEvType";

    public static final String        LAST_CORP_NAME                  = "keyword_lastCompany";

    public static final String        TARGET_COMPANY                  = "keyword_targetCompany";

    public static final String        UPDATE_DATE                     = "updateDate";

    public static final String        UPDATE_RESUME_BEGIN_DATE        = "updateResumeBeginDate";

    public static final String        UPDATE_RESUME_END_DATE          = "updateResumeBeginDate";

    public static final String        MIN_OVER_ALL_SCORE              = "matchDegree";

    public static final String        MAX_OVER_ALL_SCORE              = "maxMatchDegree";

    public static final String        MIN_AGE                         = "minAge";

    public static final String        MAX_AGE                         = "maxAge";

    public static final String        REASON                          = "reason";

    public static final String        REASON_PARAM                    = "intoTalentPoolReason";

    public static final String        INTO_TALENT_POOL_TIME           = "intoTalentPoolTime";

    public static final String        INTO_TALENT_POOL_BEGIN_DATE     = "intoTalentPoolBeginDate";

    public static final String        INTO_TALENT_POOL_ENG_DATE       = "intoTalentPoolEndDate";

    public static final String        CURRENT_INTO_CAND_BEGIN_DATE    = "currentIntoCandBeginDate";

    public static final String        CURRENT_INTO_CAND_ENG_DATE      = "currentIntoCandEndDate";

    public static final String        INTO_TALENT_POOL_TACHEU_BOOL    = "intoTalentPoolTacheuBool";

    public static final String        INTO_TALENT_POOL_TACHE          = "intoTalentPoolTache";

    public static final String        INTO_TALENT_POOL_OPERATER       = "intoTalentPoolOperater";

    public static final String        TALENT_POOL_INTO_TALENT_POOL_TACHE = "talentPoolIntoTalentPoolTache";

    public static final String        INTO_TALENT_POOL_OPERATER_PARAM = "intoTalentPooloperater";

    public static final String        INTERVIEW_EVALUATE              = "interviewEvaluate";

    public static final String        INTERVIEW_EVALUATE_PARAM        = "keyword_interview";

    public static final String        IS_SENIOR                       = "isSenior";

    public static final String        IS_LOCKED                       = "isLocked";

    public static final String        IS_LOCKED_PARAM                 = "locked";

    public static final String        IS_BLACKUSER                    = "isBlackuser";

    public static final String        SHOWLIST                        = "showlist";

    public static final String        F_SHOW_IN_TALENTPOOL            = "showInTalentPool";

    public static final String        RESUME_OWNER_SHIP               = "resumeOwnerShip";

    public static final String        IS_INNER                        = "isInner";

    public static final String        F_IS_HIGHEND_TALENTPOOL         = "isHighEndTalentPool";

    public static final String        IS_FROM_STRUCTURE               = "isFromStructure";

    public static final String        IS_DISUSE                       = "isDisuse";

    public static final String        IS_ALL_SEARCH                   = "isAllSearch";

    public static final String        IS_SENIOR_TALENT_POOL_PURVIEW   = "isSeniorTalentPoolPurview";

    public static final String        IS_CORP_TALENT_PURVIEW          = "isCorpTalentPoolPurview";

    public static final String        IS_SMART_RECOMMEND_RESUME_PAGE  = "isSmartRecommendResumePage";

    public static final String        IS_LOOK_REPEAT                  = "isLookRepeat";

    public static final String        REPEATE_RESUME_IDS_STR          ="repeateResumeIdsStr";

    public static final String        ORG_ID                          = "orgId";

    public static final String        ORG_ID_PARAM                    = "orgIdList";

    public static final String        ORG_ID_CHOOSE                   = "orgIds";

    public static final String        PROJECT_ID                      = "projectId";

    public static final String        PROJECT_ID_PARAM                = "projectIdStr";

    public static final String        LABEL_QUERY_TYPE                = "labelQueryType";

    public static final String        DEFAULT_ORDER_LIST              = "defaultOrder";

    public static final String        INTERVIEW_TYPE                  = "_interviewType_";

    public static final String        EVALUATE_STATUS                 = "_evaluateStatus_";

    public static final String        USER_ID                         = "userId";

    public static final String        THREAD_FLAG                     = "threadFlag";

    public static Map<String, String> orderMap                        = null;

    static {
        orderMap = new HashMap<>();
        orderMap.put("applyId", RESUME_ID);
        orderMap.put("age", BIRTHDAY);
        orderMap.put("resumeMatching", OVERALLSCORE);
        orderMap.put("miningRulesScore", OVERALLSCORE);
        orderMap.put(UNIQUE_KEY, RESUME_ID);
        orderMap.put("graduationDate", GRADUATE_DATE);
        orderMap.put("resumeAnnexSize", "annexSize");
        orderMap.put(REASON_PARAM, "reason.raw");
        orderMap.put(UNDER_GRADUATION_BEGIN_DATE, "underGraduateDate");
        orderMap.put(NAME, "name.raw");
        orderMap.put(EDUCATION, "education.raw");
        orderMap.put(SCHOOL, "school.raw");
        orderMap.put(SUBJECT, "subject.raw");
        orderMap.put(LIVING_PLACE, "livingPlace.raw");
        orderMap.put(ACCOUNT_PLACE, "accountPlace.raw");
        orderMap.put(POST_NAME, "postName.raw");
        orderMap.put(EXTERNAL_POST_NAME, "externalPostName.raw");
        orderMap.put(EXPECT_WORK_PLACE, "expectWorkPlace.raw");

        orderMap.put(WORK_YEARS, WORK_YEARS);
        orderMap.put(RESUME_SOURCE, RESUME_SOURCE);
        orderMap.put(NET_CHANNEL_ID, NET_CHANNEL_ID);
        orderMap.put(EMAIL, EMAIL);
        orderMap.put(GENDER, GENDER);
        orderMap.put(ID_NUM, ID_NUM);
        orderMap.put(RECRUIT_TYPE, RECRUIT_TYPE);
        orderMap.put(MOBILE_PHONE, MOBILE_PHONE);
        orderMap.put(BRAND_ID, BRAND_ID);
        orderMap.put(RESUME_TYPE, RESUME_TYPE);
        orderMap.put(CURRENT_INTO_CAND_DATE, CURRENT_INTO_CAND_DATE);
        orderMap.put(OVERALLSCORE, OVERALLSCORE);
        orderMap.put(HAD_EV_TYPE, HAD_EV_TYPE);
        orderMap.put(UPDATE_DATE, UPDATE_DATE);
        orderMap.put(INTO_TALENT_POOL_TIME, INTO_TALENT_POOL_TIME);
        orderMap.put(INTO_TALENT_POOL_TACHE, INTO_TALENT_POOL_TACHE);
        orderMap.put(INTO_TALENT_POOL_OPERATER, INTO_TALENT_POOL_OPERATER);
    }
}
