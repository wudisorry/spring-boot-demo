
package com.dayee.wintalent.elasticsearch.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.dayee.wintalent.elasticsearch.pojo.Corp;
import com.dayee.wintalent.elasticsearch.service.CorpService;

@Controller
public class CorpController {

    @Autowired
    private CorpService corpService;

    @RequestMapping("/corp/listAllCorp")
    public String listAllIndex(Model model) {

        List<Corp> corpList = corpService.refreshCorpList();
        corpList = corpService.getFilterCorpList(corpList);
        List<Corp> list = corpService.getCorpIndexList(corpList);

        model.addAttribute("list", list);
        return "listAllCorp";
    }
}
