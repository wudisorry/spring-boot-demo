
package com.dayee.wintalent.elasticsearch.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.dayee.wintalent.elasticsearch.util.ConfigUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dayee.wintalent.elasticsearch.framework.datasource.DynamicDataSourceContextHolder;
import com.dayee.wintalent.elasticsearch.service.IndexerService;
import com.dayee.wintalent.elasticsearch.util.StringUtils;

@RestController
public class IndexerController {

    private static final Logger logger = LoggerFactory
            .getLogger(IndexerController.class);

    @Autowired
    private IndexerService      indexerService;

    /***
     * 重建索引，先删除后创建
     * 
     * @param request
     * @return
     * @throws Exception
     */
    @RequestMapping("/indexer/rebuild")
    public String rebuild(HttpServletRequest request) throws Exception {

        String corpCode = request.getParameter("corpCode");
        String type = null;
        if (StringUtils.hasLength(corpCode, true)) {
            type = request.getParameter("type");
        } else {
            corpCode = request.getParameter("corpCodes");
        }
        indexerService.build(corpCode, type, true);
        return "{\"message\":\"hello rebuild spring boot\",\"code\":200}";
    }

    /***
     * 全量企业索引
     * 
     * @param request
     * @return
     */
    @RequestMapping("/indexer/build")
    public String build(HttpServletRequest request) throws Exception {

        String corpCode = request.getParameter("corpCode");
        String type = request.getParameter("type");
        indexerService.build(corpCode, type, false);
        return "{\"message\":\"hello build spring boot\",\"code\":200}";
    }

    /***
     * 删除企业索引
     * 
     * @param request
     * @return
     * @throws IOException
     */
    @RequestMapping("/indexer/del")
    public String del(HttpServletRequest request) throws IOException {

        String corpCode = request.getParameter("corpCode");
        String type = request.getParameter("type");
        return indexerService.delIndex(corpCode, type);
    }

    /***
     * 增量更新索引（实时）
     * 
     * @param request
     * @return
     * @throws IOException
     */
    @RequestMapping("/indexer/refresh")
    public String refresh(HttpServletRequest request) {

        List<Integer> resumeIdList = StringUtils
                .strToIntegerList(request.getParameter("ids"),
                                  StringUtils.COMMA);
        if (CollectionUtils.isEmpty(resumeIdList)) {
            return null;
        }
        if (!ConfigUtils.isNoticeUpdateEnable()) {
            return null;
        }
        String corpCode = DynamicDataSourceContextHolder.getAlias();
        logger.info("refresh resume corpCode:{}->{}", corpCode, resumeIdList);
        indexerService.refresh(resumeIdList);
        return "{\"message\":\"hello refresh spring boot\",\"code\":200}";
    }
}
