
package com.dayee.wintalent.elasticsearch.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.dayee.wintalent.elasticsearch.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.dayee.wintalent.elasticsearch.service.SearchService;

@RestController
public class SearchController {

    private static final Logger logger = LoggerFactory
            .getLogger(SearchController.class);

    @Autowired
    private SearchService       searchService;

    @RequestMapping("/smartQuery")
    public String smartQuery(HttpServletRequest request) throws IOException {

        JSONObject jsonObject = new JSONObject();
        try {
            String key = request.getParameter("key");
            String keyword = request.getParameter("keyword");
            Integer resumeType = Integer
                    .parseInt(request.getParameter("resumeType"));
            int language = Integer.parseInt(request.getParameter("language"));

            String applyStatusStr = request.getParameter("applyStatus");
            String applyStatusTypeStr = request.getParameter("applyStatusType");
            Integer applyStatus = StringUtils.hasLength(applyStatusStr,true)?
                    Integer.parseInt(applyStatusStr) : null;
            Integer applyStatusType = StringUtils.hasLength(applyStatusTypeStr,true)?
                    Integer.parseInt(applyStatusTypeStr) : null;

            List<String> resumeIdList = searchService
                    .smartQuery(key, keyword, resumeType, applyStatus, applyStatusType, language);
            jsonObject.put("code", 200);
            jsonObject.put("data", resumeIdList);
        } catch (Exception e) {
            jsonObject.put("code", 500);
            jsonObject.put("errorMsg", e.getMessage());
            logger.error(e.getMessage(), e);
        }
        return jsonObject.toString();
    }

    @RequestMapping("/keyWordQuery")
    public String keyWordQuery(HttpServletRequest request) {

        JSONObject jsonObject = new JSONObject();
        try {
            Integer keywordType = Integer
                    .parseInt(request.getParameter("keywordType"));
            String keyword = request.getParameter("keyword");
            Integer resumeType = Integer
                    .parseInt(request.getParameter("resumeType"));
            int language = Integer.parseInt(request.getParameter("language"));

            String applyStatusStr = request.getParameter("applyStatus");
            String applyStatusTypeStr = request.getParameter("applyStatusType");
            Integer applyStatus = StringUtils.hasLength(applyStatusStr,true)?
                    Integer.parseInt(applyStatusStr) : null;
            Integer applyStatusType = StringUtils.hasLength(applyStatusTypeStr,true)?
                    Integer.parseInt(applyStatusTypeStr) : null;

            List<String> resumeIdList = searchService
                    .keyWordQuery(keywordType, keyword, resumeType,
                            applyStatus, applyStatusType, language);
            jsonObject.put("code", 200);
            jsonObject.put("data", resumeIdList);
        } catch (Exception e) {
            jsonObject.put("code", 500);
            jsonObject.put("errorMsg", e.getMessage());
            logger.error(e.getMessage(), e);
        }
        return jsonObject.toString();
    }

    @RequestMapping("/checkRepeatResume")
    public String checkRepeatResume(HttpServletRequest request) {

        try {
            String resumeInfoJson = request.getParameter("resumeInfo");
            return searchService.checkRepeatResume(resumeInfoJson);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return null;
    }

    @RequestMapping("/checkRelatedResume")
    public String checkRelatedResume(HttpServletRequest request) {

        try {
            /*String resumeInfoJson = request.getParameter("resumeInfo");
            Integer keywordType = Integer
                    .parseInt(request.getParameter("keywordType"));
            return searchService.checkRelatedResume(resumeInfoJson,
                                                    keywordType);*/
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return null;
    }

    @RequestMapping("/talentPoolQuery")
    public String talentPoolQuery(HttpServletRequest request) {
        JSONObject jsonObject = new JSONObject();
        try {
            Integer curPage = Integer.parseInt(request.getParameter("curPage"));
            Integer rowSize = Integer.parseInt(request.getParameter("rowSize"));
            Integer language = Integer.parseInt(request.getParameter("language"));
            String smartTableName = request.getParameter("smartTableName");
            JSONObject searchObj = JSONObject.parseObject(request.getParameter("condition"));
            if (searchObj != null) {
                searchObj.put("smartTableName", smartTableName);
            }

            JSONObject result = searchService.talentPoolQuery(searchObj, language, curPage, rowSize);
            jsonObject.put("code", 200);
            jsonObject.put("data", result);
        } catch (Exception e) {
            String corpCode = request.getParameter("corpCode");
            jsonObject.put("code", 500);
            jsonObject.put("errorMsg", e.getMessage());
            logger.error("[{}]本次人才库查询失败！", corpCode, e);
        }

        return jsonObject.toJSONString();
    }
}
