
package com.dayee.wintalent.elasticsearch.controller.test;

import com.dayee.wintalent.elasticsearch.util.ElasticsearchUtils;
import org.apache.http.client.methods.HttpGet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.IOException;

/**
 * 测试集群健康度
 */
@Controller
public class TestClusterHealthController {

    private static final Logger logger = LoggerFactory.getLogger(TestClusterHealthController.class);

    private static final String CLUSTER_HEALTH_URL = "/_cluster/health";

    @ResponseBody
    @RequestMapping(value = "/debug/cluster/health")
    public String test() {
        String content = null;
        try {
            content = ElasticsearchUtils
                    .sendRestClientRequest(CLUSTER_HEALTH_URL, HttpGet.METHOD_NAME, "");
        } catch (IOException e) {
            content = "获取集群健康信息失败！";
            logger.error(content, e);
        }

        return content;
    }
}
