
package com.dayee.wintalent.elasticsearch.controller.test;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestRestController {

    @RequestMapping("/hello")
    public String hello() {

        return "{\"message\":\"hello spring boot\",\"code\":200}";
    }

    // @RequestMapping(value = "/", produces = "text/plain;charset=UTF-8")
    // public String index() {
    //
    // return "Elasticsearch index~~";
    // }
}
