
package com.dayee.wintalent.elasticsearch.dao;

import java.util.List;

import com.dayee.wintalent.elasticsearch.pojo.Corp;

public interface CorpDao {

    List<Corp> getCorpList();

    List<Corp> getFilterCorpList(List<Corp> corpList);

}
