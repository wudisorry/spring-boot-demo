
package com.dayee.wintalent.elasticsearch.dao;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import com.dayee.wintalent.elasticsearch.pojo.InfoClass;
import com.dayee.wintalent.elasticsearch.pojo.LuceneResumeIndexLog;
import com.dayee.wintalent.elasticsearch.pojo.ResumeVO;

public interface ResumeDao {

    int update(String sql, Collection<?> args);

    List queryForList(String sql, Object... args);

    Map<String,Object> queryForMap(String sql, Object... args);

    List<ResumeVO> getInitResumeList(String sql);

    List<LuceneResumeIndexLog> getRefreshResumeList(List<Integer> resumeIdList);

    List<InfoClass> getInfoClassList();

    List<Map<String, Object>> getFullTextList(String table,
                                              String fieldName,
                                              Collection<Integer> idList);

    Map<String, String> getDicInfoMap();

}
