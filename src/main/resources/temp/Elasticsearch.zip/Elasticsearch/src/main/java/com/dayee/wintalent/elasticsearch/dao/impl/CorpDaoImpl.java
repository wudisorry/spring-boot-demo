
package com.dayee.wintalent.elasticsearch.dao.impl;

import java.util.*;

import com.dayee.wintalent.elasticsearch.util.ConfigUtils;
import com.dayee.wintalent.elasticsearch.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.dayee.wintalent.elasticsearch.dao.CorpDao;
import com.dayee.wintalent.elasticsearch.pojo.Corp;
import org.springframework.util.CollectionUtils;

@Repository
public class CorpDaoImpl implements CorpDao {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private Environment environment;

    @Override
    public List<Corp> getCorpList() {

        List<Corp> corpList = jdbcTemplate
                .query("select f_code as corpCode,f_name_ch as corpName,F_DATABASE_USERNAME as user,F_DATABASE_PASSWORD as password,"
                                + "F_DATABASE_NAME as db, F_DATABASE_URL as host,F_USER_LUCENE_RESUME_SEARCH as enable FROM t_corp_info where "
                                + "F_ABATE_DATE>? and f_code<>?", new Object[]{new Date(), "CONSOLE"},
                        new BeanPropertyRowMapper(Corp.class));

        if (!CollectionUtils.isEmpty(corpList)) {
            for (Corp corp : corpList) {
                String url = corp.getHost();
                if (!StringUtils.hasLength(url, true)
                        && environment != null) {
                    url = environment.getProperty("spring.data" +
                            "source.url");
                    url = url.substring(0, url.lastIndexOf("/"));
                    corp.setHost(url);
                }
            }
        }

        return corpList;
    }

    @Override
    public List<Corp> getFilterCorpList(List<Corp> corpList) {
        if (CollectionUtils.isEmpty(corpList)) {
            return corpList;
        }

        boolean filterCodeEnable = ConfigUtils.isFilterCodeEnable();
        if (!filterCodeEnable) {
            return corpList;
        }

        StringBuilder sql = new StringBuilder(
                "select f_corp_code as corpCode ")
                .append("from t_statistical_resume_num ")
                .append("WHERE F_APPLY_START_DATE is null or F_APPLY_END_DATE is null ")
                .append("or F_TALENT_START_DATE is null or F_TALENT_END_DATE is null ")
                .append("or F_APPLY_REMAIN_THREAD_NUM != 0 or F_TALENT_REMAIN_THREAD_NUM != 0 ")
                .append("order by (f_apply_num+f_talent_num) DESC");
        List<Corp> subList = jdbcTemplate.query(sql.toString(),
                new BeanPropertyRowMapper(Corp.class));

        List<Corp> filterCorpList = filterCorp(subList, corpList);
        return filterCorpList;
    }

    private List<Corp> filterCorp(List<Corp> subList, List<Corp> corpList) {
        if (CollectionUtils.isEmpty(subList)) {
            return corpList;
        }

        Map<String, Corp> corpMap = new HashMap<>(corpList.size());
        for (Corp corp : corpList) {
            corpMap.put(corp.getCorpCode().toLowerCase(), corp);
        }

        List<Corp> filterList = new ArrayList<>();
        String corpCode;
        for (Corp corp : subList) {
            corpCode = corp.getCorpCode().toLowerCase();
            if (corpMap.containsKey(corpCode)) {
                filterList.add(corpMap.get(corpCode));
            }
        }

        return filterList;
    }

}
