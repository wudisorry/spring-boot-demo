
package com.dayee.wintalent.elasticsearch.dao.impl;

import java.util.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.dayee.wintalent.elasticsearch.constant.Constants;
import com.dayee.wintalent.elasticsearch.dao.ResumeDao;
import com.dayee.wintalent.elasticsearch.pojo.InfoClass;
import com.dayee.wintalent.elasticsearch.pojo.LuceneResumeIndexLog;
import com.dayee.wintalent.elasticsearch.pojo.ResumeVO;
import com.dayee.wintalent.elasticsearch.util.SqlUtils;

@Repository
public class ResumeDaoImpl implements ResumeDao {

    private static final Logger logger = LoggerFactory
            .getLogger(ResumeDaoImpl.class);

    @Autowired
    private JdbcTemplate        jdbcTemplate;

    @Override
    public int update(String sql, Collection<?> args) {

        if (CollectionUtils.isEmpty(args)) {
            return jdbcTemplate.update(sql);
        }
        return jdbcTemplate.update(sql, args.toArray());
    }

    @Override
    public List queryForList(String sql, Object... args) {

        return jdbcTemplate.queryForList(sql, args);
    }

    @Override
    public Map<String, Object> queryForMap(String sql, Object... args) {

        return jdbcTemplate.queryForMap(sql, args);
    }

    @Override
    public List<LuceneResumeIndexLog> getRefreshResumeList(List<Integer> resumeIdList) {

        List<Object> paramsList = new ArrayList<>();
        StringBuilder sql = new StringBuilder(
                "select F_ID uniqueKey,F_RESUME_ID resumeId,F_RESUME_TYPE resumeType,F_OPERATE_TYPE op,F_ADD_DATE addDate from ")
                        .append(SqlUtils.getTable("t_lucene_resume_index_log"))
                        .append(" where f_status=?");
        paramsList.add(1);
        if (resumeIdList != null) {
            sql.append(" and ").append(SqlUtils
                    .createInJunction("f_resume_id", resumeIdList.size()));
            paramsList.addAll(resumeIdList);
        }
        sql.append(" order by F_ADD_DATE asc");
        if (resumeIdList == null) {
            sql.append(" LIMIT " + Constants.BATCH_DB_QUERY_SIZE + ";");
        }
        List<LuceneResumeIndexLog> logList = jdbcTemplate
                .query(sql.toString(), paramsList.toArray(),
                       new BeanPropertyRowMapper(LuceneResumeIndexLog.class));
        // logger.error("{}->{}", sql, logList != null ? logList.size() : 0);
        return logList;
    }

    @Override
    public List<ResumeVO> getInitResumeList(String sql) {

        List<Map<String, Object>> list = jdbcTemplate.queryForList(sql);
        List<ResumeVO> resumeList = null;
        if (!CollectionUtils.isEmpty(list)) {
            resumeList = new ArrayList<>(list.size());
            for (Map<String, Object> entry : list) {
                Integer id = SqlUtils.getInteger(entry.get("F_RESUME_ID"));
                resumeList.add(new ResumeVO(id, "index"));
            }
        }
        return resumeList;
    }

    @Override
    public List<InfoClass> getInfoClassList() {

        return jdbcTemplate
                .query("select f_name_ch as name,f_table_name as tableName FROM "
                       + SqlUtils.getTable("t_corp_info_class")
                       + " where f_superior_id=? and f_status=?",
                       new Object[] { 1, 0 },
                       new BeanPropertyRowMapper(InfoClass.class));
    }

    @Override
    public List<Map<String, Object>> getFullTextList(String table,
                                                     String fieldName,
                                                     Collection<Integer> idList) {

        StringBuilder sb = new StringBuilder("select * from ")
                .append(SqlUtils.getTable(table)).append(" where ")
                .append(SqlUtils.createInJunction(fieldName, idList.size()));
        return jdbcTemplate.queryForList(sb.toString(), idList.toArray());
    }

    @Override
    public Map<String, String> getDicInfoMap() {

        List<Map<String, Object>> list = jdbcTemplate
                .queryForList("select f_code,f_name_ch from "
                              + SqlUtils.getTable("t_dic_info"));
        Map<String, String> infoMap = null;
        if (!CollectionUtils.isEmpty(list)) {
            infoMap = new LinkedHashMap<>(list.size());
            for (Map<String, Object> map : list) {
                infoMap.put((String) map.get("F_CODE"),
                            (String) map.get("F_NAME_CH"));
            }
        } else {
            infoMap = new LinkedHashMap<>(0);
        }
        return infoMap;
    }
}
