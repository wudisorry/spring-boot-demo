
package com.dayee.wintalent.elasticsearch.filter;

import java.io.IOException;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;

import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.stereotype.Component;

import com.dayee.wintalent.elasticsearch.framework.datasource.DynamicDataSourceContextHolder;

@Component
@ServletComponentScan
@WebFilter(urlPatterns = "/*", filterName = "dataSourceFilter")
public class DataSourceFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest request,
                         ServletResponse response,
                         FilterChain filterChain)
            throws IOException, ServletException {

        String corpCode = request.getParameter("corpCode");
        DynamicDataSourceContextHolder.setAlias(corpCode);
        filterChain.doFilter(request, response);
    }

    @Override
    public void destroy() {

    }
}