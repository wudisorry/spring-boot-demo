
package com.dayee.wintalent.elasticsearch.framework.datasource;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.dayee.wintalent.elasticsearch.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dayee.wintalent.elasticsearch.pojo.Corp;

public class DynamicDataSourceContextHolder {

    private static final Logger              logger            = LoggerFactory
            .getLogger(DynamicDataSourceContextHolder.class);

    private static final ThreadLocal<String> CURRENT_ALIAS     = new ThreadLocal<String>();

    private static Map<String, Corp>         corpDataSourceMap = new ConcurrentHashMap<>();

    public static void checkDataSource(Corp corp) {

        if (!corpDataSourceMap.containsKey(corp.getCorpCode())
                && StringUtils.hasLength(corp.getHost(), true)) {
            corpDataSourceMap.put(corp.getCorpCode(), corp);
        }
    }

    private static Corp getCurrentCorp() {

        String alias = getAlias();
        if (alias != null) {
            return corpDataSourceMap.get(alias);
        }
        return null;
    }

    /** only sqlUtils use */
    public static String getDataSourceDb() {

        Corp corp = getCurrentCorp();
        if (corp != null) {
            return corp.getDb();
        }
        return null;
    }

    public static String getDataSourceRouterKey() {

        Corp corp = getCurrentCorp();
        if (corp != null) {
            return corp.getHost();
        }
        return null;
    }

    /** alias --> corpCode */
    public static void setAlias(String alias) {

        CURRENT_ALIAS.set(alias);
    }

    /** return corpCode */
    public static String getAlias() {

        return CURRENT_ALIAS.get();
    }

    /** alias --> CONSOLE */
    public static void switchToConsole() {
        try {
            CURRENT_ALIAS.remove();
        } catch (Throwable e) {
        }
    }

    public static Map<String, Corp> getCorpMap(){
        return corpDataSourceMap;
    }
}
