
package com.dayee.wintalent.elasticsearch.framework.datasource;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.MutablePropertyValues;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.GenericBeanDefinition;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.EnvironmentAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.core.type.AnnotationMetadata;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.util.CollectionUtils;

import com.dayee.wintalent.elasticsearch.pojo.Corp;
import com.dayee.wintalent.elasticsearch.util.StringUtils;

// @Component
@Configuration
// @EnableTransactionManagement
// @EnableConfigurationProperties(DataSourceProperties.class)
public class DynamicDataSourceRegister implements
        // ImportBeanDefinitionRegistrar,
        EnvironmentAware {

    private Logger                  logger                  = LoggerFactory
            .getLogger(DynamicDataSourceRegister.class);

    private static final String     DATASOURCE_TYPE_DEFAULT = "com.alibaba.druid.pool.DruidDataSource";

    private DataSource              defaultDataSource;

    private Map<String, DataSource> slaveDataSources        = new HashMap<>();

    @Override
    public void setEnvironment(Environment environment) {

        initDefaultDataSource(environment);
        initslaveDataSources(environment);
    }

    private void initDefaultDataSource(Environment env) {

        // 读取主数据源
        Map<String, Object> dsMap = new HashMap<>(5);
        dsMap.put("type", env.getProperty("spring.datasource.type"));
        dsMap.put("driver",
                  env.getProperty("spring.datasource.driver-class-name"));
        dsMap.put("url", env.getProperty("spring.datasource.url"));
        dsMap.put("username", env.getProperty("spring.datasource.username"));
        dsMap.put("password", env.getProperty("spring.datasource.password"));
        defaultDataSource = buildDataSource(env, dsMap);
    }

    private void initslaveDataSources(Environment env) {

        // 读取配置文件获取更多数据源
        Map<String, Map<String, Object>> dsMap = new LinkedHashMap<>();
        JdbcTemplate template = new JdbcTemplate(defaultDataSource);
        List<Map<String, Object>> list = template
                .queryForList("select * from t_corp_info");
        if (!CollectionUtils.isEmpty(list)) {
            // 一个端口一个数据源
            for (Map<String, Object> entry : list) {
                String code = (String) entry.get("F_CODE");
                if ("console".equalsIgnoreCase(code)) {
                    continue;
                }
                // jdbc:MySQL://127.0.0.1:3339
                // jdbc:MySQL://10.27.70.33:3329/wtconsole8?useUnicode=true&characterEncoding=utf8&zeroDateTimeBehavior=convertToNull
                String url = (String) entry.get("F_DATABASE_URL");
                if (!StringUtils.hasLength(url, true)) {
                    url = env.getProperty("spring.datasource.url");
                    url = url.substring(0, url.lastIndexOf("/"));
                }
                String db = (String) entry.get("F_DATABASE_NAME");
                if (!dsMap.containsKey(url)) {
                    Map<String, Object> map = new LinkedHashMap<>();
                    String user = (String) entry.get("F_DATABASE_USERNAME");
                    String pwd = (String) entry.get("F_DATABASE_PASSWORD");
                    map.put("url", url);
                    map.put("username", user);
                    map.put("password", pwd);
                    map.put("type", DATASOURCE_TYPE_DEFAULT);
                    map.put("driver", "com.mysql.jdbc.Driver");

                    String sysUserName = (String) entry
                            .get("F_DATABASE_SYSTEM_USERNAME");
                    String sysPwd = (String) entry
                            .get("F_DATABASE_SYSTEM_PASSWORD");
                    if (!StringUtils.hasLength(sysUserName, true)
                        && !StringUtils.hasLength(sysPwd, true)) {
                        sysUserName = env
                                .getProperty("spring.datasource.username");
                        sysPwd = env.getProperty("spring.datasource.password");
                    }
                    map.put("username", sysUserName);
                    map.put("password", sysPwd);

                    dsMap.put(url, map);
                }
                DynamicDataSourceContextHolder
                        .checkDataSource(new Corp(code, db, url));
            }
        }
        for (Map.Entry<String, Map<String, Object>> entry : dsMap.entrySet()) {
            Map<String, Object> map = entry.getValue();
            // String code = (String) map.remove("code");
            // String db = (String) map.remove("db");
            String url = (String) map.get("url");
            DataSource ds = buildDataSource(env, map);
            slaveDataSources.put(url, ds);
        }
    }

    // @Override
    public void registerBeanDefinitions(AnnotationMetadata annotationMetadata,
                                        BeanDefinitionRegistry beanDefinitionRegistry) {

        Map<Object, Object> targetDataSources = new HashMap<Object, Object>();
        // 添加默认数据源
        targetDataSources.put("dataSource", this.defaultDataSource);
        // DynamicDataSourceContextHolder.dataSourceIds.add("dataSource");
        // 添加其他数据源
        targetDataSources.putAll(slaveDataSources);
        // for (String key : slaveDataSources.keySet()) {
        // DynamicDataSourceContextHolder.dataSourceIds.add(key);
        // }

        // 创建DynamicDataSource
        GenericBeanDefinition beanDefinition = new GenericBeanDefinition();
        beanDefinition.setBeanClass(DynamicDataSource.class);
        beanDefinition.setSynthetic(true);
        MutablePropertyValues mpv = beanDefinition.getPropertyValues();
        mpv.addPropertyValue("defaultTargetDataSource", defaultDataSource);
        mpv.addPropertyValue("targetDataSources", targetDataSources);
        // 注册 - BeanDefinitionRegistry
        beanDefinitionRegistry.registerBeanDefinition("dataSource",
                                                      beanDefinition);
        logger.info("Dynamic DataSource Registry");
    }

    @Bean(name = "dataSource")
    public DynamicDataSource dataSource() {

        DynamicDataSource dynamicDataSource = new DynamicDataSource();
        dynamicDataSource.setDefaultTargetDataSource(defaultDataSource);

        // 配置多数据源
        Map<Object, Object> targetDataSources = new HashMap(5);
        targetDataSources.put("dataSource", this.defaultDataSource);
        targetDataSources.putAll(slaveDataSources);
        // for (String key : slaveDataSources.keySet()) {
        // DynamicDataSourceContextHolder.dataSourceIds.add(key);
        // }
        dynamicDataSource.setTargetDataSources(targetDataSources);
        return dynamicDataSource;
    }

    private Class<? extends DataSource> getDataSourceType(Object type) {

        if (type == null) {
            type = DATASOURCE_TYPE_DEFAULT;
        }
        try {
            return (Class<? extends DataSource>) Class.forName((String) type);
        } catch (Exception e) {
            logger.error("{}", e.getMessage(), e);
            throw new IllegalArgumentException(
                    "can not resolve class with type: " + type);
        }
    }

    public DataSource buildDataSource(Environment env,
                                      Map<String, Object> dataSourceMap) {

        Object type = dataSourceMap.get("type");
        Class<? extends DataSource> dataSourceType = getDataSourceType(type);
        String driverClassName = dataSourceMap.get("driver").toString();
        String url = dataSourceMap.get("url").toString();

        String otherConfig = env.getProperty("spring.datasource.otherConfig");
        if (StringUtils.hasLength(otherConfig, true)) {
            url += otherConfig;
        } else {
            url += "?zeroDateTimeBehavior=convertToNull&useOldAliasMetadataBehavior=true&useUnicode=true&characterEncoding=utf-8";
        }
        String username = dataSourceMap.get("username").toString();
        String password = dataSourceMap.get("password").toString();
        // 自定义DataSource配置
        DataSourceBuilder factory = DataSourceBuilder.create()
                .driverClassName(driverClassName).url(url).username(username)
                .password(password).type(dataSourceType);
        return factory.build();
    }
}