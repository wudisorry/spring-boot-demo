
package com.dayee.wintalent.elasticsearch.mq;

import org.springframework.amqp.core.Queue;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author Zhanggp
 * @date 2019/8/24 17:43
 */
@ConditionalOnProperty(value = "wintalent.rabbitmqEnable", havingValue = "true")
@Configuration
public class RabbitConfig {

    public static final String routingKey = "resume";

    @Bean
    public Queue resume() {

        return new Queue(routingKey);
    }
}
