
package com.dayee.wintalent.elasticsearch.mq;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSONObject;
import com.dayee.wintalent.elasticsearch.pojo.ResumeVO;
import com.dayee.wintalent.elasticsearch.service.IndexerService;

/**
 * @author Zhanggp
 * @date 2019/8/24 19:05
 */
@ConditionalOnProperty(value = "wintalent.rabbitmqEnable", havingValue = "true")
@Component
@RabbitListener(queues = RabbitConfig.routingKey)
public class ResumeConsumer {

    private static final Logger logger = LoggerFactory
            .getLogger(ResumeConsumer.class);

    @Autowired
    private IndexerService      indexerService;

    @RabbitHandler
    public void recieved(String json) {

        long l1 = System.currentTimeMillis();
        List<ResumeVO> resumeList = JSONObject.parseArray(json, ResumeVO.class);
        long l2 = System.currentTimeMillis();

        logger.info("get message:{}->use time:{}", json.length(), l2 - l1);

        indexerService.buildResumeIndex(resumeList);
    }
}
