
package com.dayee.wintalent.elasticsearch.mq;

import java.util.Collection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSONArray;
import com.dayee.wintalent.elasticsearch.pojo.ResumeVO;

/**
 * @author Zhanggp
 * @date 2019/8/24 20:41
 */
@Component
public class ResumeProducer {

    private static final Logger logger = LoggerFactory
            .getLogger(ResumeProducer.class);

    @Autowired
    private AmqpTemplate        rabbitTemplate;

    public void resumeSend(Collection<ResumeVO> resumeList) {

        long l1 = System.currentTimeMillis();
        String message = JSONArray.toJSONString(resumeList);
        long l2 = System.currentTimeMillis();

        logger.info("send message:{}->convert time:{}", resumeList.size(),
                     l2 - l1);

        rabbitTemplate.convertAndSend(RabbitConfig.routingKey, message);
    }
}
