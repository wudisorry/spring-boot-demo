
package com.dayee.wintalent.elasticsearch.pojo;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Zhanggp
 */
public class Corp {

    private String        corpCode;

    private String        corpName;

    private int           port;

    private String        user;

    private String        password;

    private String        db;

    private String        host;

    /** 索引启用状态 */
    private Integer       enable;

    private List<IndexVo> indexVoList;

    public void addIndexVo(IndexVo vo) {

        if (indexVoList == null) {
            indexVoList = new ArrayList<>();
        }
        indexVoList.add(vo);
    }

    public Corp() {

    }

    public Corp(String corpCode, String db, String host) {

        this.corpCode = corpCode;
        this.db = db;
        this.host = host;
    }

    public void setConnectInfo(String connectInfo) {

        // System.out.println(connectInfo);
    }

    public String getCorpCode() {

        return corpCode;
    }

    public void setCorpCode(String corpCode) {

        this.corpCode = corpCode;
    }

    public int getPort() {

        return port;
    }

    public void setPort(int port) {

        this.port = port;
    }

    public String getUser() {

        return user;
    }

    public void setUser(String user) {

        this.user = user;
    }

    public String getPassword() {

        return password;
    }

    public void setPassword(String password) {

        this.password = password;
    }

    public String getDb() {

        return db;
    }

    public void setDb(String db) {

        this.db = db;
    }

    public String getHost() {

        return host;
    }

    public void setHost(String host) {

        this.host = host;
    }

    public List<IndexVo> getIndexVoList() {

        return indexVoList;
    }

    public void setIndexVoList(List<IndexVo> indexVoList) {

        this.indexVoList = indexVoList;
    }

    public String getCorpName() {

        return corpName;
    }

    public void setCorpName(String corpName) {

        this.corpName = corpName;
    }

    public Integer getEnable() {

        return enable;
    }

    public void setEnable(Integer enable) {

        this.enable = enable;
    }

    public boolean getEnableBol() {

        return enable != null && enable.equals(0);
    }

    public boolean getIndexedBol() {

        for (IndexVo vo : indexVoList) {
            if (!vo.isExsits()) {
                return false;
            }
        }
        return true;
    }
}
