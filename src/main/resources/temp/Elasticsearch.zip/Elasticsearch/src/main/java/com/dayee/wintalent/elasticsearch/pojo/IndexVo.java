
package com.dayee.wintalent.elasticsearch.pojo;

public class IndexVo {

    private String  corpCode;

    private boolean exsits;

    private String  storeSize;

    private long    docsNum;

    private String  type;

    public String getCorpCode() {

        return corpCode;
    }

    public void setCorpCode(String corpCode) {

        this.corpCode = corpCode;
    }

    public boolean isExsits() {

        return exsits;
    }

    public void setExsits(boolean exsits) {

        this.exsits = exsits;
    }

    public long getDocsNum() {

        return docsNum;
    }

    public String getStoreSize() {

        return storeSize;
    }

    public void setStoreSize(String storeSize) {

        this.storeSize = storeSize;
    }

    public void setDocsNum(long docsNum) {

        this.docsNum = docsNum;
    }

    public String getType() {

        return type;
    }

    public void setType(String type) {

        this.type = type;
    }
}
