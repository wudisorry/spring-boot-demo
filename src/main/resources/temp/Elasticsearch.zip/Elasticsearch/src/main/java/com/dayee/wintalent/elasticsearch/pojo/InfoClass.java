
package com.dayee.wintalent.elasticsearch.pojo;

import com.dayee.wintalent.elasticsearch.constant.Constants;
import com.dayee.wintalent.elasticsearch.util.StringUtils;

public class InfoClass {

    private String name;

    private String tableName;

    public boolean isPersInfo() {

        return Constants.PERS_INFO.equalsIgnoreCase(tableName);
    }

    public boolean isEduc() {

        return Constants.EDUC_EXPE.equalsIgnoreCase(tableName);
    }

    public boolean isWork() {

        return Constants.WORK_EXPE.equalsIgnoreCase(tableName);
    }

    public boolean isJobIntention() {

        return Constants.JOB_INTENTION.equalsIgnoreCase(tableName);
    }

    public boolean isLanguageAbility() {

        return Constants.LANG_ABIL.equalsIgnoreCase(tableName);
    }

    public String getKey(String lan) {

        return tableName.toLowerCase() + StringUtils.UNDERLINE
               + lan.toLowerCase();
    }

    public String getTable(String type, String lan) {

        StringBuilder sb = new StringBuilder();
        if (Constants.TYPE_CAND.equalsIgnoreCase(type)) {
            sb.append(Constants.TABLE_CAND);
        } else {
            sb.append(Constants.TABLE_APPLY);
        }
        sb.append(tableName);
        sb.append(StringUtils.UNDERLINE).append(lan);
        return sb.toString();
    }

    public String getName() {

        return name;
    }

    public void setName(String name) {

        this.name = name;
    }

    public String getTableName() {

        return tableName;
    }

    public void setTableName(String tableName) {

        this.tableName = tableName;
    }
}
