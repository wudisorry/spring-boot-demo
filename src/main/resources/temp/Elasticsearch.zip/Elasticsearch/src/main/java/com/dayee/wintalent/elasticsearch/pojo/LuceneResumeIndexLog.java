
package com.dayee.wintalent.elasticsearch.pojo;

import java.util.Date;

public class LuceneResumeIndexLog {

    public static final int RESUME_IN_TABLE_APPLY = 1;

    public static final int WEB_RESUME_TYPE_CAND  = 2;

    public static final int OP_ADD                = 1; // 新增

    public static final int OP_UPDATE             = 2; // 修改

    public static final int OP_DELETE             = 3; // 删除

    private Integer         uniqueKey;

    private Integer         resumeId;

    private Integer         resumeType;

    private Integer         op;

    private Date            addDate;

    public String getOpType() {

        if (op != null) {
            if (op.equals(OP_ADD) || op.equals(OP_UPDATE)) {
                return "index";
            } else if (op.equals(OP_DELETE)) {
                return "delete";
            }
        }
        return null;
    }

    public String getType() {

        if (isApply()) {
            return "apply";
        } else if (isCand()) {
            return "cand";
        }
        return null;
    }

    public boolean isApply() {

        return resumeType != null && resumeType == RESUME_IN_TABLE_APPLY;
    }

    public boolean isCand() {

        return resumeType != null && resumeType == WEB_RESUME_TYPE_CAND;
    }

    public Integer getUniqueKey() {

        return uniqueKey;
    }

    public void setUniqueKey(Integer uniqueKey) {

        this.uniqueKey = uniqueKey;
    }

    public Integer getResumeId() {

        return resumeId;
    }

    public void setResumeId(Integer resumeId) {

        this.resumeId = resumeId;
    }

    public Integer getResumeType() {

        return resumeType;
    }

    public void setResumeType(Integer resumeType) {

        this.resumeType = resumeType;
    }

    public Integer getOp() {

        return op;
    }

    public void setOp(Integer op) {

        this.op = op;
    }

    public Date getAddDate() {

        return addDate;
    }

    public void setAddDate(Date addDate) {

        this.addDate = addDate;
    }
}
