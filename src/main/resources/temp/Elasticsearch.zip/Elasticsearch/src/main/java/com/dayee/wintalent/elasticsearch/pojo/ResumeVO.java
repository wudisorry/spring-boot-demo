
package com.dayee.wintalent.elasticsearch.pojo;

import java.util.ArrayList;
import java.util.List;

import com.alibaba.fastjson.annotation.JSONField;
import com.dayee.wintalent.elasticsearch.pojo.resume.Resume;

/**
 * TODO
 * 添加JSONField注解的字段是临时属性，为了避免给索引中产生垃圾数据，故加了该属性；可以考虑使用组合（把resume作为ResumeVO的属性），最终索引的是Resume而不是ResumeVO
 * 
 * @author Zhanggp
 * @date 2019/8/24 21:18
 */
public class ResumeVO extends Resume {

    // 操作：新增索引、删除索引
    @JSONField(serialize = false)
    private String        op;

    @JSONField(serialize = false)
    private List<Integer> uniqueKeyList;

    @JSONField(serialize = false)
    private String        corpCode;

    // 类型：候选库、人才库
    @JSONField(serialize = false)
    private String        type;

    /**
     * 是否为线程最后一份简历
     */
    @JSONField(serialize = false)
    private boolean        isThreadLastResume;

    public ResumeVO() {

    }

    public ResumeVO(Integer resumeId, String op) {

        this.resumeId = resumeId;
        this.op = op;
    }

    public void addUniqueKey(Integer uniqueKey) {

        if (uniqueKeyList == null) {
            uniqueKeyList = new ArrayList<>();
        }
        uniqueKeyList.add(uniqueKey);
    }

    public String getOp() {

        return op;
    }

    public void setOp(String op) {

        this.op = op;
    }

    public List<Integer> getUniqueKeyList() {

        return uniqueKeyList;
    }

    public void setUniqueKeyList(List<Integer> uniqueKeyList) {

        this.uniqueKeyList = uniqueKeyList;
    }

    public String getCorpCode() {

        return corpCode;
    }

    public void setCorpCode(String corpCode) {

        this.corpCode = corpCode;
    }

    public String getType() {

        return type;
    }

    public void setType(String type) {

        this.type = type;
    }

    public boolean isThreadLastResume() {
        return isThreadLastResume;
    }

    public void setThreadLastResume(boolean threadLastResume) {
        isThreadLastResume = threadLastResume;
    }
}
