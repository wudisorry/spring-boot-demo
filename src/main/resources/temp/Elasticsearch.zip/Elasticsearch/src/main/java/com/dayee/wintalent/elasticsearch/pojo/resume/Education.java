
package com.dayee.wintalent.elasticsearch.pojo.resume;

import java.io.Serializable;
import java.util.Date;

import com.dayee.wintalent.elasticsearch.constant.Constants;

// 教育经历
public class Education implements Serializable {

    // 学校
    private String  school;

    // 学历
    private String  education;

    // 学位
    private String  degree;

    // 专业
    private String  major;

    // 开始时间
    private Date    beginDate;

    // 结束时间
    private Date    endDate;

    // 语言
    private Integer lan;

    /** 是否最高学历 */
    private boolean isHighest;

    /** 是否第一学历 */
    private boolean isFirst;

    public Education(String lang) {

        if (Constants.CH.equalsIgnoreCase(lang)) {
            lan = Constants.CHINA_LOCALE;
        } else {
            lan = Constants.ENGLISH_LOCALE;
        }
    }

    public String getSchool() {

        return school;
    }

    public void setSchool(String school) {

        this.school = school;
    }

    public String getEducation() {

        return education;
    }

    public void setEducation(String education) {

        this.education = education;
    }

    public String getDegree() {

        return degree;
    }

    public void setDegree(String degree) {

        this.degree = degree;
    }

    public String getMajor() {

        return major;
    }

    public void setMajor(String major) {

        this.major = major;
    }

    public Date getBeginDate() {

        return beginDate;
    }

    public void setBeginDate(Date beginDate) {

        this.beginDate = beginDate;
    }

    public Date getEndDate() {

        return endDate;
    }

    public void setEndDate(Date endDate) {

        this.endDate = endDate;
    }

    public Integer getLan() {

        return lan;
    }

    public void setLan(Integer lan) {

        this.lan = lan;
    }

    public boolean isHighest() {
        return isHighest;
    }

    public void setHighest(boolean highest) {
        isHighest = highest;
    }

    public boolean isFirst() {
        return isFirst;
    }

    public void setFirst(boolean first) {
        isFirst = first;
    }
}
