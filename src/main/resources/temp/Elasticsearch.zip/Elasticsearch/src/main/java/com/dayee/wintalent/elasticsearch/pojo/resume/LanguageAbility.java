
package com.dayee.wintalent.elasticsearch.pojo.resume;

import com.dayee.wintalent.elasticsearch.constant.Constants;

import java.io.Serializable;

/**
 * 语言能力信息
 *
 * @author wsk
 */
public class LanguageAbility implements Serializable {

    /** 外语种类 */
    private String languageType;

    /** 外语等级 */
    private String languageLevel;

    /** 外语拼写能力 */
    private String speakingAbility;

    /** 外语读写能力 */
    private String writeAbility;

    /** 语言*/
    private Integer lan;

    public LanguageAbility(String lang) {

        if (Constants.CH.equalsIgnoreCase(lang)) {
            lan = Constants.CHINA_LOCALE;
        } else {
            lan = Constants.ENGLISH_LOCALE;
        }
    }

    public String getLanguageType() {
        return languageType;
    }

    public void setLanguageType(String languageType) {
        this.languageType = languageType;
    }

    public String getLanguageLevel() {
        return languageLevel;
    }

    public void setLanguageLevel(String languageLevel) {
        this.languageLevel = languageLevel;
    }

    public String getSpeakingAbility() {
        return speakingAbility;
    }

    public void setSpeakingAbility(String speakingAbility) {
        this.speakingAbility = speakingAbility;
    }

    public String getWriteAbility() {
        return writeAbility;
    }

    public void setWriteAbility(String writeAbility) {
        this.writeAbility = writeAbility;
    }

    public Integer getLan() {

        return lan;
    }

    public void setLan(Integer lan) {

        this.lan = lan;
    }
}
