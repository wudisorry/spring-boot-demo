
package com.dayee.wintalent.elasticsearch.pojo.resume;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.*;

public class Resume implements Serializable {

    protected Integer                    resumeId;

    // 人员编号
    protected String                     persCode;

    // 姓名
    protected String                     name;

    // 性别
    protected String                     gender;

    // 出生日期
    protected Date                       birthday;

    // 手机
    protected String                     mobilePhone;

    // 邮箱
    protected String                     email;

    // 毕业院校
    protected String                     school;

    // 更新时间
    protected Date                       updateDate;

    // TODO 人才库简历start

    protected String                     originalId;           // 简历编号

    protected Integer                    recruitType;          // 招聘类型

    protected Integer                    isSenior;             // 是否高级

    protected Integer                    isLocked;             // 是否锁定

    protected Integer                    resumeSource;         // 简历来源

    protected Integer                    netChannelId;         // 网络渠道ID

    protected Integer                    brandId;              // 品牌ID

    protected String                     subject;              // 专业

    protected Date                       graduateDate;         // 毕业日期

    protected String                     accountPlace;         // 户口所在地

    protected String                     enName;               // 姓名

    protected String                     reason;               // 入库原因

    protected Integer                    matchDegree;          // 简历等级

    protected String                     workYears;            // 工作年限

    protected String                     education;            // 学历

    protected String                     livingPlace;          // 现居住地

    protected String                     labelId;              // 简历标签

    protected String                     postId;               // 应聘过的职位id

    protected String                     postName;             // 职位名称

    protected String                     postType;             // 职位类型

    protected String                     resumeType;           // 简历类别

    // 目标学校
    // 目标公司
    // 上家公司

    protected Date                       intoTalentPoolTime;   // 入库时间

    protected Integer                    intoTalentPoolTache;  // 入库环节

    protected Integer                    talentPoolType;       // 人才库类型（1：人才库；2：精品库；3：回流库）

    protected String                     hadEvType;            // 面试环节

    protected BigDecimal                 overallScore;         // 简历得分

    protected String                     orgId;                // 所属机构

    protected String                     externalPostName;     // 对外职位名称

    protected Date                       currentIntoCandDate;  // 最近入库时间

    protected Integer                    headhuntingId;

    protected Integer                    isDisuse;             // 是否淘汰库

    protected Integer                    isInner;              // 是否内招库

    protected Integer                    IntoTalentPoolOperater;//入库操作者

    protected String                     idNum;                 // 身份证

    protected String                     highestDegree;         // 最高学历

    protected String                     firstDegree;           // 第一学历

    protected Integer                    contactState;          // 联系状态

    protected Integer                    suitableOrImproper;    // 是否合适

    protected Integer                    signHotUser;           // 热门候选人标记者

    protected Date                       signHotDate;           // 热门候选人标记时间

    protected String                     projectId;             // 招聘项目

    protected String                     staffNo;               // 员工编号

    protected Date                       underGraduateDate;     // 本科毕业时间

    protected String                     expectWorkPlace;       // 期望工作地点

    protected String                     interviewEvaluate;     // 面试评价

    protected Integer                    innerRecruitType;      // 内推类型

    protected String                     remark;                // 备注

    protected String                     sendTo;                // 发送对象

    protected String                     careerFairId;          // 宣讲会id

    protected String                     site;                  // 站点

    protected String                     structureId;           // 人才库类别

    protected BigDecimal                 annexSize;             // 附件大小

    protected String                     sourceChannel;         // 简历渠道来源（拼接字段）

    protected String                     folderId;              // 文件夹id

    protected Integer                    showInTalentPool;      // 是否在人才库展示

    protected Integer                    showlist;              // 是否展示

    protected Integer                    isBlackuser;           // 是否黑名单用户

    protected Integer                    isHighendTalentPool;   // 是否高端人才库

    protected Integer                    resumeOwnerShip;       // 简历归属

    protected List<Integer>              applyStatus;           // 侯选库简历状态

    protected List<Integer>              applyStatusType;       // 侯选库简历状态类别

    protected String                     fullTextCh;            // 简历原件大文本中文

    protected String                     fullTextEn;            // 简历原件大文本英文

    protected String                     fullTextUpdateCh;      // 简历更新大文本中文

    protected String                     fullTextUpdateEn;      // 简历更新大文本英文

    // TODO 人才库简历 end

    protected List<Education>            eduExp;

    protected List<WorkExperience>       workExp;

    protected List<LanguageAbility>      langAbil;

    protected Map<String, StringBuilder> detail;


    public void addEdu(Education edu) {

        if (edu != null) {
            if (eduExp == null) {
                eduExp = new ArrayList<>();
            }
            eduExp.add(edu);
        }
    }

    public void addWork(WorkExperience work) {

        if (work != null) {
            if (workExp == null) {
                workExp = new ArrayList<>();
            }
            workExp.add(work);
        }
    }

    public void addLangAbil(LanguageAbility ability) {

        if (ability != null) {
            if (langAbil == null) {
                langAbil = new ArrayList<>();
            }
            langAbil.add(ability);
        }
    }

    public void addDetail(String key, Object content) {

        if (content == null) {
            return;
        }
        if (detail == null) {
            detail = new LinkedHashMap<>();
        }
        StringBuilder stringBuilder = detail.get(key);
        if (stringBuilder == null) {
            stringBuilder = new StringBuilder();
        }
        stringBuilder.append(content);
        detail.put(key, stringBuilder);
    }

    public Integer getResumeId() {

        return resumeId;
    }

    public void setResumeId(Integer resumeId) {

        this.resumeId = resumeId;
    }

    public String getName() {

        return name;
    }

    public void setName(String name) {

        this.name = name;
    }

    public String getGender() {

        return gender;
    }

    public void setGender(String gender) {

        this.gender = gender;
    }

    public String getMobilePhone() {

        return mobilePhone;
    }

    public void setMobilePhone(String mobilePhone) {

        this.mobilePhone = mobilePhone;
    }

    public String getEmail() {

        return email;
    }

    public void setEmail(String email) {

        this.email = email;
    }

    public String getSchool() {

        return school;
    }

    public void setSchool(String school) {

        this.school = school;
    }

    public List<Education> getEduExp() {

        return eduExp;
    }

    public void setEduExp(List<Education> eduExp) {

        this.eduExp = eduExp;
    }

    public List<WorkExperience> getWorkExp() {

        return workExp;
    }

    public void setWorkExp(List<WorkExperience> workExp) {

        this.workExp = workExp;
    }

    public List<LanguageAbility> getLangAbil() {
        return langAbil;
    }

    public void setLangAbil(List<LanguageAbility> langAbil) {
        this.langAbil = langAbil;
    }

    public Map<String, StringBuilder> getDetail() {

        return detail;
    }

    public void setDetail(Map<String, StringBuilder> detail) {

        this.detail = detail;
    }

    public Date getBirthday() {

        return birthday;
    }

    public void setBirthday(Date birthday) {

        this.birthday = birthday;
    }

    public String getPersCode() {

        return persCode;
    }

    public void setPersCode(String persCode) {

        this.persCode = persCode;
    }

    public Date getUpdateDate() {

        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {

        this.updateDate = updateDate;
    }

    public String getOriginalId() {
        return originalId;
    }

    public void setOriginalId(String originalId) {
        this.originalId = originalId;
    }

    public Integer getRecruitType() {

        return recruitType;
    }

    public void setRecruitType(Integer recruitType) {

        this.recruitType = recruitType;
    }

    public Integer getIsSenior() {

        return isSenior;
    }

    public void setIsSenior(Integer isSenior) {

        this.isSenior = isSenior;
    }

    public Integer getIsLocked() {

        return isLocked;
    }

    public void setIsLocked(Integer isLocked) {

        this.isLocked = isLocked;
    }

    public Integer getResumeSource() {

        return resumeSource;
    }

    public void setResumeSource(Integer resumeSource) {

        this.resumeSource = resumeSource;
    }

    public Integer getNetChannelId() {

        return netChannelId;
    }

    public void setNetChannelId(Integer netChannelId) {

        this.netChannelId = netChannelId;
    }

    public Integer getBrandId() {

        return brandId;
    }

    public void setBrandId(Integer brandId) {

        this.brandId = brandId;
    }

    public String getSubject() {

        return subject;
    }

    public void setSubject(String subject) {

        this.subject = subject;
    }

    public Date getGraduateDate() {

        return graduateDate;
    }

    public void setGraduateDate(Date graduateDate) {

        this.graduateDate = graduateDate;
    }

    public String getAccountPlace() {

        return accountPlace;
    }

    public void setAccountPlace(String accountPlace) {

        this.accountPlace = accountPlace;
    }

    public String getEnName() {

        return enName;
    }

    public void setEnName(String enName) {

        this.enName = enName;
    }

    public String getReason() {

        return reason;
    }

    public void setReason(String reason) {

        this.reason = reason;
    }

    public Integer getMatchDegree() {

        return matchDegree;
    }

    public void setMatchDegree(Integer matchDegree) {

        this.matchDegree = matchDegree;
    }

    public String getWorkYears() {

        return workYears;
    }

    public void setWorkYears(String workYears) {

        this.workYears = workYears;
    }

    public String getEducation() {

        return education;
    }

    public void setEducation(String education) {

        this.education = education;
    }

    public String getLivingPlace() {

        return livingPlace;
    }

    public void setLivingPlace(String livingPlace) {

        this.livingPlace = livingPlace;
    }

    public String getLabelId() {

        return labelId;
    }

    public void setLabelId(String labelId) {

        this.labelId = labelId;
    }

    public String getPostId() {

        return postId;
    }

    public void setPostId(String postId) {

        this.postId = postId;
    }

    public String getPostName() {

        return postName;
    }

    public void setPostName(String postName) {

        this.postName = postName;
    }

    public String getPostType() {

        return postType;
    }

    public void setPostType(String postType) {

        this.postType = postType;
    }

    public String getResumeType() {
        return resumeType;
    }

    public void setResumeType(String resumeType) {
        this.resumeType = resumeType;
    }

    public Date getIntoTalentPoolTime() {

        return intoTalentPoolTime;
    }

    public void setIntoTalentPoolTime(Date intoTalentPoolTime) {

        this.intoTalentPoolTime = intoTalentPoolTime;
    }

    public Integer getIntoTalentPoolTache() {

        return intoTalentPoolTache;
    }

    public void setIntoTalentPoolTache(Integer intoTalentPoolTache) {

        this.intoTalentPoolTache = intoTalentPoolTache;
    }

    public Integer getTalentPoolType() {

        return talentPoolType;
    }

    public void setTalentPoolType(Integer talentPoolType) {

        this.talentPoolType = talentPoolType;
    }

    public String getHadEvType() {

        return hadEvType;
    }

    public void setHadEvType(String hadEvType) {

        this.hadEvType = hadEvType;
    }

    public BigDecimal getOverallScore() {

        return overallScore;
    }

    public void setOverallScore(BigDecimal overallScore) {

        this.overallScore = overallScore;
    }

    public String getOrgId() {

        return orgId;
    }

    public void setOrgId(String orgId) {

        this.orgId = orgId;
    }

    public String getExternalPostName() {

        return externalPostName;
    }

    public void setExternalPostName(String externalPostName) {

        this.externalPostName = externalPostName;
    }

    public Date getCurrentIntoCandDate() {

        return currentIntoCandDate;
    }

    public void setCurrentIntoCandDate(Date currentIntoCandDate) {

        this.currentIntoCandDate = currentIntoCandDate;
    }

    public Integer getHeadhuntingId() {

        return headhuntingId;
    }

    public void setHeadhuntingId(Integer headhuntingId) {

        this.headhuntingId = headhuntingId;
    }

    public Integer getIsDisuse() {

        return isDisuse;
    }

    public void setIsDisuse(Integer isDisuse) {

        this.isDisuse = isDisuse;
    }

    public String getExpectWorkPlace() {
        return expectWorkPlace;
    }

    public void setExpectWorkPlace(String expectWorkPlace) {
        this.expectWorkPlace = expectWorkPlace;
    }

    public Integer getIntoTalentPoolOperater() {
        return IntoTalentPoolOperater;
    }

    public void setIntoTalentPoolOperater(Integer intoTalentPoolOperater) {
        IntoTalentPoolOperater = intoTalentPoolOperater;
    }

    public Integer getIsInner() {
        return isInner;
    }

    public void setIsInner(Integer isInner) {
        this.isInner = isInner;
    }

    public String getIdNum() {
        return idNum;
    }

    public void setIdNum(String idNum) {
        this.idNum = idNum;
    }

    public String getHighestDegree() {
        return highestDegree;
    }

    public void setHighestDegree(String highestDegree) {
        this.highestDegree = highestDegree;
    }

    public String getFirstDegree() {
        return firstDegree;
    }

    public void setFirstDegree(String firstDegree) {
        this.firstDegree = firstDegree;
    }

    public Integer getContactState() {
        return contactState;
    }

    public void setContactState(Integer contactState) {
        this.contactState = contactState;
    }

    public Integer getSuitableOrImproper() {
        return suitableOrImproper;
    }

    public void setSuitableOrImproper(Integer suitableOrImproper) {
        this.suitableOrImproper = suitableOrImproper;
    }

    public Integer getSignHotUser() {
        return signHotUser;
    }

    public void setSignHotUser(Integer signHotUser) {
        this.signHotUser = signHotUser;
    }

    public Date getSignHotDate() {
        return signHotDate;
    }

    public void setSignHotDate(Date signHotDate) {
        this.signHotDate = signHotDate;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getStaffNo() {
        return staffNo;
    }

    public void setStaffNo(String staffNo) {
        this.staffNo = staffNo;
    }

    public Date getUnderGraduateDate() {
        return underGraduateDate;
    }

    public void setUnderGraduateDate(Date underGraduateDate) {
        this.underGraduateDate = underGraduateDate;
    }

    public String getInterviewEvaluate() {
        return interviewEvaluate;
    }

    public void setInterviewEvaluate(String interviewEvaluate) {
        this.interviewEvaluate = interviewEvaluate;
    }

    public Integer getInnerRecruitType() {
        return innerRecruitType;
    }

    public void setInnerRecruitType(Integer innerRecruitType) {
        this.innerRecruitType = innerRecruitType;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getSendTo() {
        return sendTo;
    }

    public void setSendTo(String sendTo) {
        this.sendTo = sendTo;
    }

    public String getCareerFairId() {
        return careerFairId;
    }

    public void setCareerFairId(String careerFairId) {
        this.careerFairId = careerFairId;
    }

    public String getSite() {
        return site;
    }

    public void setSite(String site) {
        this.site = site;
    }

    public String getStructureId() {
        return structureId;
    }

    public void setStructureId(String structureId) {
        this.structureId = structureId;
    }

    public BigDecimal getAnnexSize() {
        return annexSize;
    }

    public void setAnnexSize(BigDecimal annexSize) {
        this.annexSize = annexSize;
    }

    public String getSourceChannel() {
        return sourceChannel;
    }

    public void setSourceChannel(String sourceChannel) {
        this.sourceChannel = sourceChannel;
    }

    public String getFolderId() {
        return folderId;
    }

    public void setFolderId(String folderId) {
        this.folderId = folderId;
    }

    public Integer getShowInTalentPool() {
        return showInTalentPool;
    }

    public void setShowInTalentPool(Integer showInTalentPool) {
        this.showInTalentPool = showInTalentPool;
    }

    public Integer getShowlist() {
        return showlist;
    }

    public void setShowlist(Integer showlist) {
        this.showlist = showlist;
    }

    public Integer getIsBlackuser() {
        return isBlackuser;
    }

    public void setIsBlackuser(Integer isBlackuser) {
        this.isBlackuser = isBlackuser;
    }

    public Integer getIsHighendTalentPool() {
        return isHighendTalentPool;
    }

    public void setIsHighendTalentPool(Integer isHighendTalentPool) {
        this.isHighendTalentPool = isHighendTalentPool;
    }

    public Integer getResumeOwnerShip() {
        return resumeOwnerShip;
    }

    public void setResumeOwnerShip(Integer resumeOwnerShip) {
        this.resumeOwnerShip = resumeOwnerShip;
    }

    public List<Integer> getApplyStatus() {
        return applyStatus;
    }

    public void setApplyStatus(List<Integer> applyStatus) {
        this.applyStatus = applyStatus;
    }

    public List<Integer> getApplyStatusType() {
        return applyStatusType;
    }

    public void setApplyStatusType(List<Integer> applyStatusType) {
        this.applyStatusType = applyStatusType;
    }

    public String getFullTextCh() {
        return fullTextCh;
    }

    public void setFullTextCh(String fullTextCh) {
        this.fullTextCh = fullTextCh;
    }

    public String getFullTextEn() {
        return fullTextEn;
    }

    public void setFullTextEn(String fullTextEn) {
        this.fullTextEn = fullTextEn;
    }

    public String getFullTextUpdateCh() {
        return fullTextUpdateCh;
    }

    public void setFullTextUpdateCh(String fullTextUpdateCh) {
        this.fullTextUpdateCh = fullTextUpdateCh;
    }

    public String getFullTextUpdateEn() {
        return fullTextUpdateEn;
    }

    public void setFullTextUpdateEn(String fullTextUpdateEn) {
        this.fullTextUpdateEn = fullTextUpdateEn;
    }
}
