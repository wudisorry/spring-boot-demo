
package com.dayee.wintalent.elasticsearch.pojo.resume;

import java.io.Serializable;
import java.util.Date;

import com.dayee.wintalent.elasticsearch.constant.Constants;

public class WorkExperience implements Serializable {

    private Date    beginDate;

    private Date    endDate;

    // 公司名称
    private String  corpName;

    // 上家公司
    private boolean isLast;

    // 语言
    private Integer lan;

    public WorkExperience(String lang) {

        if (Constants.CH.equalsIgnoreCase(lang)) {
            lan = Constants.CHINA_LOCALE;
        } else {
            lan = Constants.ENGLISH_LOCALE;
        }
    }

    public Date getBeginDate() {

        return beginDate;
    }

    public void setBeginDate(Date beginDate) {

        this.beginDate = beginDate;
    }

    public Date getEndDate() {

        return endDate;
    }

    public void setEndDate(Date endDate) {

        this.endDate = endDate;
    }

    public String getCorpName() {

        return corpName;
    }

    public void setCorpName(String corpName) {

        this.corpName = corpName;
    }

    public boolean isLast() {

        return isLast;
    }

    public void setLast(boolean last) {

        isLast = last;
    }

    public Integer getLan() {

        return lan;
    }

    public void setLan(Integer lan) {

        this.lan = lan;
    }
}
