
package com.dayee.wintalent.elasticsearch.service;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.client.methods.HttpGet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.dayee.wintalent.elasticsearch.dao.CorpDao;
import com.dayee.wintalent.elasticsearch.framework.datasource.DynamicDataSourceContextHolder;
import com.dayee.wintalent.elasticsearch.pojo.Corp;
import com.dayee.wintalent.elasticsearch.pojo.IndexVo;
import com.dayee.wintalent.elasticsearch.thread.ResumePoolManager;
import com.dayee.wintalent.elasticsearch.util.ElasticsearchUtils;
import com.dayee.wintalent.elasticsearch.util.JsonUtils;

@Service
public class CorpService {

    private static final Logger logger = LoggerFactory
            .getLogger(CorpService.class);

    @Autowired
    private CorpDao             corpDao;

    public List<Corp> refreshCorpList() {

        List<Corp> corpList = corpDao.getCorpList();
        if (!CollectionUtils.isEmpty(corpList)) {
            for (Corp corp : corpList) {
                if (corp.getEnableBol()) {
                    ResumePoolManager.checkLock(corp.getCorpCode());
                    DynamicDataSourceContextHolder.checkDataSource(corp);
                }
            }
        }
        return corpList;
    }

    public List<Corp> getCorpIndexList(List<Corp> list) {

        // List<Corp> list = corpDao.getCorpList();

        // http://localhost:9200/_stats
        Map<String, IndexVo> indexVoMap = new LinkedHashMap<>();
        try {
            // http://localhost:9200/_stats
            // String requestUrl = ConfigUtils.getIndexServerUrl() + "_stats";
            // String content = HttpClientUtils.sendRequest(requestUrl,
            // HttpGet.METHOD_NAME,
            // null, null, null);
            String content = ElasticsearchUtils
                    .sendRestClientRequest("/_stats", HttpGet.METHOD_NAME,
                                           null);
            JSONObject jsonObject = JSON.parseObject(content);
            JSONObject indices = JsonUtils.getJSONObject(jsonObject, "indices");
            for (String index : indices.keySet()) {
                IndexVo vo = new IndexVo();
                vo.setExsits(true);

                JSONObject idx = JsonUtils.getJSONObject(indices, index);
                JSONObject primaries = JsonUtils.getJSONObject(idx,
                                                               "primaries");
                JSONObject docs = JsonUtils.getJSONObject(primaries, "docs");
                vo.setDocsNum(JsonUtils.getInteger(docs, "count"));

                JSONObject store = JsonUtils.getJSONObject(primaries, "store");
                Long storeSize = store.getLong("size_in_bytes");
                if (storeSize != null) {
                    // 36174
                    if (storeSize < 1024 * 1024) {
                        vo.setStoreSize(storeSize / 1024 + "KB");
                    } else {
                        vo.setStoreSize(storeSize / 1024 / 1024 + "M");
                    }
                }
                indexVoMap.put(index, vo);
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        if (!CollectionUtils.isEmpty(list)) {
            for (Corp corp : list) {

                String corpCode = corp.getCorpCode();
                String key = corpCode.toLowerCase() + "_apply";
                IndexVo apply = indexVoMap.get(key);
                if (apply == null) {
                    apply = new IndexVo();
                    apply.setCorpCode(corpCode);
                    indexVoMap.put(key, apply);
                }
                apply.setType("apply");
                apply.setCorpCode(corpCode);
                corp.addIndexVo(apply);

                key = corpCode.toLowerCase() + "_cand";
                IndexVo cand = indexVoMap.get(key);
                if (cand == null) {
                    cand = new IndexVo();
                    cand.setCorpCode(corpCode);
                    indexVoMap.put(key, cand);
                }
                cand.setType("cand");
                cand.setCorpCode(corpCode);
                corp.addIndexVo(cand);
            }
        }
        return list;
    }

    public List<Corp> getFilterCorpList(List<Corp> corpList) {
        return corpDao.getFilterCorpList(corpList);
    }
}
