
package com.dayee.wintalent.elasticsearch.service;

import java.math.BigDecimal;
import java.util.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.dayee.wintalent.elasticsearch.constant.ChannelType;
import com.dayee.wintalent.elasticsearch.constant.Constants;
import com.dayee.wintalent.elasticsearch.dao.ResumeDao;
import com.dayee.wintalent.elasticsearch.framework.datasource.DynamicDataSourceContextHolder;
import com.dayee.wintalent.elasticsearch.pojo.InfoClass;
import com.dayee.wintalent.elasticsearch.pojo.LuceneResumeIndexLog;
import com.dayee.wintalent.elasticsearch.pojo.ResumeVO;
import com.dayee.wintalent.elasticsearch.pojo.resume.Education;
import com.dayee.wintalent.elasticsearch.pojo.resume.LanguageAbility;
import com.dayee.wintalent.elasticsearch.pojo.resume.WorkExperience;
import com.dayee.wintalent.elasticsearch.util.*;

@Service
public class ResumeService {

    private static final Logger logger = LoggerFactory
            .getLogger(ResumeService.class);

    @Autowired
    private ResumeDao           resumeDao;

    public void updateIndexLoging(Collection<Integer> uniqueKeyList) {

        if(ConfigUtils.isUpdateFieldEnable()){
            return;
        }

        if (!CollectionUtils.isEmpty(uniqueKeyList)) {
            List<Object> paramList = new ArrayList<>(uniqueKeyList.size() + 1);
            StringBuilder sql = new StringBuilder("update ")
                    .append(SqlUtils.getTable("t_lucene_resume_index_log"))
                    .append(" set F_STATUS=? where ").append(SqlUtils
                            .createInJunction("f_id", uniqueKeyList.size()));
            paramList.add(2);
            paramList.addAll(uniqueKeyList);
            resumeDao.update(sql.toString(), paramList);
        }
    }

    public void updateIndexStatus(Collection<Integer> uniqueKeyList) {
        if(ConfigUtils.isUpdateFieldEnable()){
            return;
        }

        if (!CollectionUtils.isEmpty(uniqueKeyList)) {
            List<Object> paramList = new ArrayList<>(uniqueKeyList.size() + 2);
            StringBuilder sql = new StringBuilder("update ")
                    .append(SqlUtils.getTable("t_lucene_resume_index_log"))
                    .append(" set F_INDEX_DATE=?,F_STATUS=? where ")
                    .append(SqlUtils.createInJunction("f_id",
                                                      uniqueKeyList.size()));
            paramList.add(new Date());
            paramList.add(0);
            paramList.addAll(uniqueKeyList);
            resumeDao.update(sql.toString(), paramList);
        }
    }

    public void rollbackIndexStatus() {

        List<Object> paramList = new ArrayList<>(3);
        StringBuilder sql = new StringBuilder("update ")
                .append(SqlUtils.getTable("t_lucene_resume_index_log"))
                .append(" set F_STATUS=? where ")
                .append(" f_status=? and F_ADD_DATE<=?");
        paramList.add(1);
        paramList.add(2);
        paramList.add(DateUtils.getDateBeforeMinute(new Date(), 5));
        resumeDao.update(sql.toString(), paramList);
    }

    public void rollbackIndexStatus(Collection<Integer> uniqueKeyList) {

        if (!CollectionUtils.isEmpty(uniqueKeyList)) {
            List<Object> paramList = new ArrayList<>(uniqueKeyList.size() + 1);
            StringBuilder sql = new StringBuilder("update ")
                    .append(SqlUtils.getTable("t_lucene_resume_index_log"))
                    .append(" set F_STATUS=? where ")
                    .append(SqlUtils.createInJunction("f_id",
                                                      uniqueKeyList.size()))
                    .append(" and f_status=?");
            paramList.add(1);
            paramList.addAll(uniqueKeyList);
            paramList.add(2);
            resumeDao.update(sql.toString(), paramList);
        }
    }

    public int update(String sql) {

        return resumeDao.update(sql, null);
    }

    public Map<String,Object> queryForMap(String sql, Object... args) {

        return resumeDao.queryForMap(sql, args);
    }

    public Map<String, Collection<ResumeVO>> getRefreshResumeMap(List<Integer> resumeIdList) {

        List<LuceneResumeIndexLog> logList = null;

        if (!ConfigUtils.isUpdateFieldEnable()) {
            logList = resumeDao
                    .getRefreshResumeList(resumeIdList);
        } else {
            logList = this.getRefreshResumeList(resumeIdList);
        }

        return refactorResumeMap(logList);
    }

    private List<LuceneResumeIndexLog> getRefreshResumeList(List<Integer> resumeIdList) {
        if(CollectionUtils.isEmpty(resumeIdList)){
            return null;
        }

        List<LuceneResumeIndexLog> logList = new ArrayList<>();
        for (Integer resumeId : resumeIdList) {
            LuceneResumeIndexLog log = new LuceneResumeIndexLog();
            log.setUniqueKey(-resumeId);
            log.setOp(LuceneResumeIndexLog.OP_UPDATE);
            log.setResumeId(resumeId);
            log.setResumeType(LuceneResumeIndexLog.WEB_RESUME_TYPE_CAND);
            logList.add(log);
        }

        return logList;
    }

    private Map<String, Collection<ResumeVO>> refactorResumeMap(List<LuceneResumeIndexLog> logList) {

        if (CollectionUtils.isEmpty(logList)) {
            return null;
        }
        String corpCode = DynamicDataSourceContextHolder.getAlias();
        Map<String, Map<Integer, ResumeVO>> resuemMap = new LinkedHashMap<>();
        List<Integer> applyResumeIdList = new ArrayList<>();
        List<Integer> candResumeIdList = new ArrayList<>();
        for (LuceneResumeIndexLog log : logList) {
            String type = log.getType();
            if (type == null) {
                continue;
            }
            Map<Integer, ResumeVO> map = resuemMap.get(type);
            if (map == null) {
                map = new LinkedHashMap<>();
                resuemMap.put(type, map);
            }
            Integer resumeId = log.getResumeId();
            ResumeVO resume = map.get(resumeId);
            if (resume == null) {
                resume = new ResumeVO();
                map.put(resumeId, resume);
            }
            resume.setCorpCode(corpCode);
            resume.setType(type);
            resume.setOp(log.getOpType());
            resume.setResumeId(resumeId);
            resume.addUniqueKey(log.getUniqueKey());
            if (log.isApply() && !applyResumeIdList.contains(resumeId)) {
                applyResumeIdList.add(resumeId);
            }
            if (log.isCand() && !candResumeIdList.contains(resumeId)) {
                candResumeIdList.add(resumeId);
            }
        }
        Map<String, String> dicInfoMap = resumeDao.getDicInfoMap();
        List<InfoClass> infoClasses = resumeDao.getInfoClassList();

        Map<String, Collection<ResumeVO>> resultMap = new LinkedHashMap<>();
        Map<Integer, ResumeVO> applyResumeMap = resuemMap
                .get(Constants.TYPE_APPLY);
        if (!CollectionUtils.isEmpty(applyResumeMap)) {

            updateResumeBasicInfo(applyResumeMap, applyResumeIdList,
                                  Constants.TYPE_APPLY);
            initResumeMap(applyResumeMap, applyResumeIdList, dicInfoMap,
                          infoClasses, Constants.TYPE_APPLY);
            initResumeApplyInfo(applyResumeMap, applyResumeIdList, Constants.TYPE_APPLY);
            resultMap.put(Constants.TYPE_APPLY, applyResumeMap.values());
        }

        Map<Integer, ResumeVO> candResumeMap = resuemMap
                .get(Constants.TYPE_CAND);
        if (!CollectionUtils.isEmpty(candResumeMap)) {

            updateResumeBasicInfo(candResumeMap, candResumeIdList,
                                  Constants.TYPE_CAND);
            initResumeMap(candResumeMap, candResumeIdList, dicInfoMap,
                          infoClasses, Constants.TYPE_CAND);
            if (ConfigUtils.isTalentPoolEnable()) {
                updateResumePostInfo(candResumeMap, candResumeMap.keySet(),
                                     Constants.TYPE_CAND);
                updateResumeFirstEducation(candResumeMap, Constants.TYPE_CAND);
                initResumeLabelInfo(candResumeMap, candResumeMap.keySet(),
                                    Constants.TYPE_CAND);
                initResumeOriginalInfo(candResumeMap, candResumeMap.keySet(),
                                       Constants.TYPE_CAND);
                initResumeInterviewEvaluateInfo(candResumeMap,
                                                candResumeMap.keySet(),
                                                dicInfoMap,
                                                Constants.TYPE_CAND);
                initResumeRemarkInfo(candResumeMap, candResumeMap.keySet(),
                                     Constants.TYPE_CAND);
                initResumeCareerfairInfo(candResumeMap, candResumeMap.keySet(),
                                         Constants.TYPE_CAND);
                initResumeCandApplyInfo(candResumeMap, candResumeMap.keySet(),
                                        Constants.TYPE_CAND);
                initResumeResourceInfo(candResumeMap, candResumeMap.keySet(),
                                       Constants.TYPE_CAND);
                initResumeTalentPoolCategoryInfo(candResumeMap,
                                                 candResumeMap.keySet(),
                                                 Constants.TYPE_CAND);

                initResumeFolderInfo(candResumeMap, candResumeMap.keySet(), Constants.TYPE_CAND);

                initResumeCandHeadhuntingIdInfo(candResumeMap, candResumeMap.keySet(), Constants.TYPE_CAND);
            }
            resultMap.put(Constants.TYPE_CAND, candResumeMap.values());
        }
        return resultMap;
    }

    private void updateResumeBasicInfo(Map<Integer, ResumeVO> resumeMap,
                                       Collection<Integer> resumeIdList,
                                       String type) {

        if (CollectionUtils.isEmpty(resumeMap)) {
            return;
        }

        StringBuilder sb = new StringBuilder();
        if (Constants.TYPE_CAND.equals(type)) {
            sb.append("SELECT F_ID,F_PERS_CODE,F_UPDATE_DATE, F_CURRENT_INTO_CAND_DATE,")
                    .append("F_REASON,F_RECRUIT_TYPE,F_NET_CHANNEL_ID, F_RESUME_SOURCE,F_BRAND_ID,F_IS_DISUSE,")
                    .append( "F_IS_LOCKED,F_IS_SENIOR,F_POST_TYPE,F_INTO_TALENTPOOL_TACHE,F_HAD_EV_TYPE,")
                    .append( "F_FIRST_INTO_CAND_DATE,F_OVERALL_SCORE,F_HEADHUNTING_ID,F_TALENT_POST_TYPE,")
                    .append( "F_TALENTPOOL_TYPE*1 F_TALENTPOOL_TYPE,F_ORG_ID,F_IS_INNER,F_CONTACT_STATE,")
                    .append( "F_SUITABLE_OR_IMPROPER,F_INNER_RECRUIT_TYPE,F_SEND_RESUME_RECEIVE_USER,")
                    .append( "F_RESUME_ANNEX_SIZE,F_ADD_USER,F_SHOW_IN_TALENTPOOL,F_IS_HIGHEND_TALENTPOOL,")
                    .append( "F_SHOW_LIST,F_IS_BLACKUSER,F_RESUME_OWNERSHIP FROM ")
                    .append(SqlUtils.getTable("t_" + type + "_resume_basic_info"))
                    .append(" WHERE ")
                    .append(SqlUtils.createInJunction("f_id", resumeIdList.size()));
        } else {
            sb.append("SELECT F_ID,F_PERS_CODE,F_UPDATE_DATE FROM ")
                    .append(SqlUtils
                            .getTable("t_" + type + "_resume_basic_info"))
                    .append(" WHERE ").append(SqlUtils
                            .createInJunction("f_id", resumeIdList.size()));
        }

        List<Map<String, Object>> list = resumeDao
                .queryForList(sb.toString(), resumeIdList.toArray());
        if (!CollectionUtils.isEmpty(list)) {
            for (Map<String, Object> entry : list) {
                Integer id = (Integer) entry.get("F_ID");
                if (id == null) {
                    continue;
                }

                ResumeVO resume = resumeMap.get(id);
                if (resume != null) {
                    String persCode = (String) entry.get(Constants.F_PERS_CODE);
                    Object dateObj = entry.get(Constants.F_UPDATE_DATE);
                    resume.setPersCode(persCode);
                    resume.setUpdateDate((Date) dateObj);

                    // 针对人才库新增字段
                    if (ConfigUtils.isTalentPoolEnable()) {
                        if (Constants.TYPE_CAND.equals(type)) {
                            Date currentIntoDate = (Date) entry
                                    .get(Constants.F_CURRENT_INTO_CAND_DATE);
                            String reason = (String) entry
                                    .get(Constants.F_REASON);
                            Integer recruitType = (Integer) entry
                                    .get(Constants.F_RECRUIT_TYPE);
                            Integer netChannelId = (Integer) entry
                                    .get(Constants.F_NET_CHANNEL_ID);
                            Integer resumeSource = (Integer) entry
                                    .get(Constants.F_RESUME_SOURCE);
                            Integer brandId = (Integer) entry
                                    .get(Constants.F_BRAND_ID);
                            Integer isLocked = (Integer) entry
                                    .get(Constants.F_IS_LOCKED);
                            Integer isSenior = (Integer) entry
                                    .get(Constants.F_IS_SENIOR);
                            String postType = (String) entry
                                    .get(Constants.F_POST_TYPE);
                            Integer intoTalentPoolTache = (Integer) entry
                                    .get(Constants.F_INTO_TALENTPOOL_TACHE);
                            String hadEVType = (String) entry
                                    .get(Constants.F_HAD_EV_TYPE);
                            Date intoTalentPoolTime = (Date) entry
                                    .get(Constants.F_FIRST_INTO_CAND_DATE);
                            BigDecimal overallScore = (BigDecimal) entry
                                    .get(Constants.F_OVERALL_SCORE);
                            Integer headhuntingId = (Integer) entry
                                    .get(Constants.F_HEADHUNTING_ID);
                            String resumeType = (String) entry
                                    .get(Constants.F_TALENT_POST_TYPE);
                            Long talentPoolTypeTemp = (Long) entry
                                    .get(Constants.F_TALENTPOOL_TYPE);
                            Boolean isDisuse = (Boolean) entry
                                    .get(Constants.F_IS_DISUSE);
                            Integer orgId = (Integer) entry
                                    .get(Constants.F_ORG_ID);
                            Integer isInner = (Integer) entry
                                    .get(Constants.F_IS_INNER);
                            Integer contactState = (Integer) entry
                                    .get(Constants.F_CONTACT_STATE);
                            Integer suitableOrImproper = (Integer) entry
                                    .get(Constants.F_SUITABLE_OR_IMPROPER);
                            Integer innerRecruitType = (Integer) entry
                                    .get(Constants.F_INNER_RECRUIT_TYPE);
                            String sendTo = (String) entry
                                    .get(Constants.F_SEND_RESUME_RECEIVE_USER);
                            BigDecimal annexSize = (BigDecimal) entry
                                    .get(Constants.F_RESUME_ANNEX_SIZE);
                            Integer addUser = (Integer) entry
                                    .get(Constants.F_ADD_USER);
                            Integer showInTalentPool = (Integer) entry
                                    .get(Constants.F_SHOW_IN_TALENTPOOL);
                            Integer showlist = (Integer) entry
                                    .get(Constants.F_SHOW_LIST);
                            Integer isBlackuser = (Integer) entry
                                    .get(Constants.F_IS_BLACKUSER);
                            Integer isHighendTalentPool = (Integer) entry
                                    .get(Constants.F_IS_HIGHEND_TALENTPOOL);
                            Integer resumeOwnerShip = (Integer) entry
                                    .get(Constants.F_RESUME_OWNERSHIP);


                            resume.setCurrentIntoCandDate(currentIntoDate);
                            resume.setRecruitType(recruitType);
                            resume.setNetChannelId(netChannelId);
                            resume.setResumeSource(resumeSource);
                            resume.setBrandId(brandId);
                            resume.setOverallScore(overallScore);
                            resume.setIsLocked(isLocked == null ? Constants.NO
                                                                : isLocked);
                            resume.setIsSenior(isSenior == null ? Constants.NO
                                                                : isSenior);
                            resume.setIsDisuse(isDisuse == null || isDisuse
                                    .booleanValue() ? Constants.NO
                                                    : Constants.YES);
                            resume.setIsInner(isInner == null ? Constants.NO
                                                              : isInner);
                            resume.setPostType(StringUtils
                                    .hasLength(postType, true) ? postType
                                                               : null);
                            resume.setIntoTalentPoolTache(intoTalentPoolTache);
                            resume.setHadEvType(StringUtils
                                    .hasLength(hadEVType, true) ? hadEVType
                                                                : null);
                            resume.setIntoTalentPoolTime(intoTalentPoolTime);
                            resume.setHeadhuntingId(headhuntingId);
                            resume.setContactState(contactState == null ? Constants.NO
                                                                        : contactState);
                            resume.setSuitableOrImproper(suitableOrImproper == null ? Constants.NO
                                                                                    : suitableOrImproper);
                            resume.setInnerRecruitType(innerRecruitType);
                            resume.setSendTo(sendTo);
                            resume.setAnnexSize(annexSize);
                            resume.setIntoTalentPoolOperater(addUser);

                            if (StringUtils.hasLength(reason, true)) {
                                if (reason.contains(StringUtils.COMMA)) {
                                    reason = reason
                                            .replace(StringUtils.COMMA,
                                                     StringUtils.COMMA + StringUtils.SPACE);
                                }
                                resume.setReason(reason);
                            }

                            if (StringUtils.hasLength(resumeType, true)) {
                                resumeType = resumeType
                                        .replace(StringUtils.COMMA,
                                                 StringUtils.COMMA + StringUtils.SPACE);
                                resume.setResumeType(resumeType);
                            }
                            if (talentPoolTypeTemp != null) {
                                resume.setTalentPoolType(talentPoolTypeTemp
                                        .intValue());
                            }
                            if (orgId != null) {
                                resume.setOrgId(orgId.toString());
                            }

                            resume.setShowInTalentPool(showInTalentPool == null ? Constants.YES
                                    : showInTalentPool);

                            resume.setShowlist(showlist == null ? Constants.YES
                                    : showlist);

                            resume.setIsBlackuser(isBlackuser == null ? Constants.NO
                                    : isBlackuser);

                            if (isHighendTalentPool != null) {
                                resume.setIsHighendTalentPool(isHighendTalentPool);
                            }

                            if (resumeOwnerShip != null) {
                                resume.setResumeOwnerShip(resumeOwnerShip);
                            }
                        }
                    }
                }
            }
        }
    }

    public Collection<ResumeVO> getInitResumeList(String sql,
                                                  String type,
                                                  Map<String, String> dicInfoMap,
                                                  List<InfoClass> infoClasses) {

        List<ResumeVO> resumeList = resumeDao.getInitResumeList(sql);

        if (CollectionUtils.isEmpty(resumeList)) {
            return null;
        }
        String corpCode = DynamicDataSourceContextHolder.getAlias();
        Map<Integer, ResumeVO> resumeMap = new LinkedHashMap<>();
        for (ResumeVO resume : resumeList) {
            resume.setCorpCode(corpCode);
            resume.setType(type);
            resumeMap.put(resume.getResumeId(), resume);
        }
        updateResumeBasicInfo(resumeMap, resumeMap.keySet(), type);
        if (dicInfoMap == null) {
            dicInfoMap = resumeDao.getDicInfoMap();
        }
        if (infoClasses == null) {
            infoClasses = resumeDao.getInfoClassList();
        }
        initResumeMap(resumeMap, resumeMap.keySet(), dicInfoMap, infoClasses,
                      type);

        initResumeApplyInfo(resumeMap, resumeMap.keySet(), type);

        if (ConfigUtils.isTalentPoolEnable()) {
            updateResumePostInfo(resumeMap, resumeMap.keySet(), type);
            updateResumeFirstEducation(resumeMap, type);
            initResumeLabelInfo(resumeMap, resumeMap.keySet(), type);
            initResumeOriginalInfo(resumeMap, resumeMap.keySet(), type);
            initResumeInterviewEvaluateInfo(resumeMap, resumeMap.keySet(),
                                            dicInfoMap, type);
            initResumeRemarkInfo(resumeMap, resumeMap.keySet(), type);
            initResumeCareerfairInfo(resumeMap, resumeMap.keySet(), type);
            initResumeCandApplyInfo(resumeMap, resumeMap.keySet(), type);
            initResumeResourceInfo(resumeMap, resumeMap.keySet(), type);
            initResumeTalentPoolCategoryInfo(resumeMap, resumeMap.keySet(), type);
            initResumeFolderInfo(resumeMap, resumeMap.keySet(), Constants.TYPE_CAND);
            initResumeCandHeadhuntingIdInfo(resumeMap, resumeMap.keySet(), Constants.TYPE_CAND);
        }

        return resumeMap.values();
    }

    private ResumeVO getResume(Map<Integer, ResumeVO> resumeMap,
                               Integer resumeId) {

        ResumeVO resume = resumeMap.get(resumeId);
        if (resume == null) {
            resume = new ResumeVO();
            resume.setResumeId(resumeId);
            resumeMap.put(resumeId, resume);
        }
        return resume;
    }

    private String getAESEncryptKey(String corpCode) throws Exception{
        DynamicDataSourceContextHolder.switchToConsole();
        List<Map<String,Object>> corpList = resumeDao.queryForList("SELECT * FROM T_CORP_INFO WHERE F_CODE = ?",corpCode);
        if(!CollectionUtils.isEmpty(corpList)){
            Map<String,Object> map = corpList.get(0);
            String aesKey = (String) map.get("f_aes_key");
            if(StringUtils.hasLength(aesKey)){
                DynamicDataSourceContextHolder.setAlias(corpCode);
                return ResumeEncryptUtils.decrypt(aesKey,"0eTnbJtXgjEs11bR",corpCode);
            }
        }
        DynamicDataSourceContextHolder.setAlias(corpCode);
        return null;
    }

    private void initResumeMap(Map<Integer, ResumeVO> resumeMap,
                               Collection<Integer> resumeIdList,
                               Map<String, String> dicInfoMap,
                               List<InfoClass> infoClasses,
                               String type) {

        Integer resumeId = null;
        Object content = null;
        List<Map<String, Object>> list = resumeDao
                .getFullTextList("t_ck_" + type + "_con", Constants.FID,
                                 resumeIdList);
        if (!CollectionUtils.isEmpty(list)) {
            for (Map<String, Object> entry : list) {
                resumeId = SqlUtils.getInteger(entry.get(Constants.FID));
                ResumeVO resume = getResume(resumeMap, resumeId);

                resume.setFullTextCh((String) entry.get(Constants.F_CONTENT_1));
                resume.setFullTextEn((String) entry.get(Constants.F_CONTENT_2));
                resume.setFullTextUpdateCh((String) entry.get(Constants.F_CONTENT_3));
                resume.setFullTextUpdateEn((String) entry.get(Constants.F_CONTENT_4));
            }
        }

        Education education = null;
        WorkExperience experience = null;
        LanguageAbility langAbil = null;
        String[] langs = new String[] { Constants.CH, Constants.EN };
        String aesKey = null;
        boolean isUseAes = false;
        String corpCode = DynamicDataSourceContextHolder.getAlias();
        try {
            aesKey = getAESEncryptKey(corpCode);
            if(StringUtils.hasLength(aesKey)){
                isUseAes = true;
            }
        }catch (Exception e){
            logger.error(e.getMessage());
        }
        for (InfoClass infoClass : infoClasses) {

            boolean isPersInfo = infoClass.isPersInfo();
            boolean isWork = infoClass.isWork();
            boolean isEdu = infoClass.isEduc();
            boolean isJobIntention = infoClass.isJobIntention();
            boolean isLanguageAbility = infoClass.isLanguageAbility();

            for (String lan : langs) {
                String table = infoClass.getTable(type, lan);
                String key = infoClass.getKey(lan);

                try {
                    list = resumeDao.getFullTextList(table, Constants.RESUME_ID,
                            resumeIdList);
                } catch (Exception e) {
                    logger.error(e.getMessage());
                    continue;
                }
                if (CollectionUtils.isEmpty(list)) {
                    continue;
                }

                try {
                    for (Map<String, Object> entry : list) {
                        resumeId = SqlUtils
                                .getInteger(entry.get(Constants.RESUME_ID));
                        ResumeVO resume = getResume(resumeMap, resumeId);

                        if (isPersInfo) {
                            content = getValue(dicInfoMap, entry,
                                               Constants.F_NAME);
                            if (content != null) {
                                if (lan.equals(Constants.CH)) {
                                    if(isUseAes){
                                        resume.setName(ResumeEncryptUtils.decrypt((String)content,aesKey,corpCode));
                                    }else {
                                        resume.setName((String) content);
                                    }
                                } else {
                                    if(isUseAes){
                                        resume.setEnName(ResumeEncryptUtils.decrypt((String)content,aesKey,corpCode));
                                    }else {
                                        resume.setEnName((String) content);
                                    }
                                }
                            }

                            if (resume.getGender() == null) {
                                content = getValue(dicInfoMap, entry,
                                                   Constants.F_GENDER);
                                if (content != null) {
                                    resume.setGender((String) content);
                                }
                            }

                            if (resume.getBirthday() == null) {
                                content = getValue(dicInfoMap, entry,
                                                   Constants.F_BIRTHDAY);
                                if (content != null) {
                                    resume.setBirthday((Date) content);
                                }
                            }

                            if (resume.getMobilePhone() == null) {
                                content = getValue(dicInfoMap, entry,
                                                   Constants.F_MOBILE_PHONE);
                                if (content != null) {
                                    if(isUseAes){
                                        resume.setMobilePhone(ResumeEncryptUtils.decrypt((String) content,aesKey,corpCode));
                                    }else {
                                        resume.setMobilePhone((String) content);
                                    }
                                }
                            }

                            if (resume.getEmail() == null) {
                                content = getValue(dicInfoMap, entry,
                                                   Constants.F_EMAIL);
                                if (content != null) {
                                    if(isUseAes){
                                        resume.setEmail(ResumeEncryptUtils.decrypt((String)content,aesKey,corpCode));
                                    }else {
                                        resume.setEmail((String) content);
                                    }
                                }
                            }

                            if (resume.getSchool() == null) {
                                content = getValue(dicInfoMap, entry,
                                                   Constants.F_GRADUATION_SCHOOL);
                                if (content != null) {
                                    resume.setSchool((String) content);
                                }
                            }

                            /**
                             * 针对人才库新增字段
                             */
                            if (ConfigUtils.isTalentPoolEnable()) {
                                if (Constants.TYPE_CAND.equals(type)) {
                                    if (resume.getLivingPlace() == null) {
                                        content = getValue(dicInfoMap, entry,
                                                           Constants.F_LIVING_PLACE);
                                        if (content != null) {
                                            resume.setLivingPlace((String) content);
                                        }
                                    }

                                    if (resume.getSubject() == null) {
                                        content = getValue(dicInfoMap, entry,
                                                           Constants.F_SUBJECT);
                                        if (content != null) {
                                            resume.setSubject((String) content);
                                        }
                                    }

                                    if (resume.getEducation() == null) {
                                        content = entry
                                                .get(Constants.F_EDUCATION);
                                        if (content != null) {
                                            resume.setEducation((String) content);
                                        }
                                    }

                                    if (resume.getWorkYears() == null) {
                                        content = entry
                                                .get(Constants.F_WORK_YEARS);
                                        if (content != null) {
                                            resume.setWorkYears((String) content);
                                        }
                                    }

                                    if (resume.getGraduateDate() == null) {
                                        content = getValue(dicInfoMap, entry,
                                                           Constants.F_GRADUATION_DATE);
                                        if (content != null) {
                                            resume.setGraduateDate((Date) content);
                                        }
                                    }

                                    if (resume.getAccountPlace() == null) {
                                        content = getValue(dicInfoMap, entry,
                                                           Constants.F_ACCOUNT_PLACE);
                                        if (content != null) {
                                            resume.setAccountPlace((String) content);
                                        }
                                    }

                                    if (resume.getIdNum() == null) {
                                        content = getValue(dicInfoMap, entry,
                                                           Constants.F_ID_NUM);
                                        if (content != null) {
                                            if(isUseAes){
                                                resume.setIdNum(ResumeEncryptUtils.decrypt((String)content,aesKey,corpCode));
                                            }else{
                                                resume.setIdNum((String) content);
                                            }
                                        }
                                    }

                                    if (resume.getHighestDegree() == null) {
                                        content = getValue(dicInfoMap, entry,
                                                           Constants.F_HIGHTEST_DEGREE);
                                        if (content != null) {
                                            resume.setHighestDegree((String) content);
                                        }
                                    }

                                    if (resume.getFirstDegree() == null) {
                                        content = getValue(dicInfoMap, entry,
                                                           Constants.F_FIRST_DEGREE);
                                        if (content != null) {
                                            resume.setFirstDegree((String) content);
                                        }
                                    }

                                    if (resume.getStaffNo() == null) {
                                        content = getValue(dicInfoMap, entry,
                                                           Constants.F_STAFF_NO);
                                        if (content != null) {
                                            resume.setStaffNo((String) content);
                                        }
                                    }

                                    if (resume.getUnderGraduateDate() == null) {
                                        content = getValue(dicInfoMap, entry,
                                                           Constants.F_UNDER_GRADUATION_DATE);
                                        if (content != null) {
                                            resume.setUnderGraduateDate((Date) content);
                                        }
                                    }
                                }
                            }

                        } else if (isWork) {
                            experience = new WorkExperience(lan);
                            content = getValue(dicInfoMap, entry,
                                               Constants.F_CORP_NAME);
                            if (content != null) {
                                // 限制企业名最长500，防止错误数据导致无法创建索引
                                String corpName = (String) content;
                                if(corpName.length() > 500){
                                    corpName = corpName.substring(0,500);
                                }
                                experience.setCorpName(corpName);
                            }
                            content = getValue(dicInfoMap, entry,
                                               Constants.F_BEGIN_DATE);
                            if (content != null) {
                                experience.setBeginDate((Date) content);
                            }
                            content = getValue(dicInfoMap, entry,
                                               Constants.F_END_DATE);
                            if (content != null) {
                                experience.setEndDate((Date) content);
                            }
                            content = getValue(dicInfoMap, entry,
                                               Constants.F_IS_LAST_RECORD);
                            if (content != null) {
                                Integer last = Integer
                                        .parseInt(content.toString());
                                experience
                                        .setLast(last.equals(0) ? true : false);
                            }
                            resume.addWork(experience);
                        } else if (isEdu) {
                            education = new Education(lan);
                            content = getValue(dicInfoMap, entry,
                                               Constants.F_SCHOOL);
                            if (content != null) {
                                education.setSchool((String) content);
                            }
                            content = getValue(dicInfoMap, entry,
                                               Constants.F_EDUCATION);
                            if (content != null) {
                                education.setEducation((String) content);
                            }
                            content = getValue(dicInfoMap, entry,
                                               Constants.F_SUBJECT);
                            if (content != null) {
                                education.setMajor((String) content);
                            }
                            content = getValue(dicInfoMap, entry,
                                               Constants.F_DEGREE);
                            if (content != null) {
                                education.setDegree((String) content);
                            }

                            content = getValue(dicInfoMap, entry,
                                               Constants.F_BEGIN_DATE);
                            if (content != null) {
                                education.setBeginDate((Date) content);
                            }
                            content = getValue(dicInfoMap, entry,
                                               Constants.F_END_DATE);
                            if (content != null) {
                                education.setEndDate((Date) content);
                            }

                            if (Constants.TYPE_CAND.equals(type)) {
                                content = entry
                                        .get(Constants.F_IS_HIGHTEST_EDUCATION_RECORD);
                                if (content != null) {
                                    Integer highest = Integer
                                            .parseInt(content.toString());
                                    education.setHighest(highest
                                            .equals(0) ? true : false);
                                }

                                if (Constants.EDUCATION__COLLEGE
                                        .equals(education.getEducation())) {
                                    education.setFirst(true);
                                } else {
                                    education.setFirst(false);
                                }
                            }
                            resume.addEdu(education);
                        } else if (isJobIntention) {
                            if (Constants.TYPE_CAND.equals(type)) {
                                content = getValue(dicInfoMap, entry,
                                                   Constants.F_WORK_PLACE);
                                if (content != null) {
                                    if (resume.getExpectWorkPlace() != null
                                        && !content.equals(resume
                                                .getExpectWorkPlace())) {
                                        resume.setExpectWorkPlace(resume
                                                .getExpectWorkPlace()
                                                                  + StringUtils.COMMA
                                                                  + content);
                                    } else {
                                        resume.setExpectWorkPlace((String) content);
                                    }
                                }
                            }
                        } else if (isLanguageAbility) {
                            if (Constants.TYPE_CAND.equals(type)) {
                                langAbil = new LanguageAbility(lan);

                                content = getValue(dicInfoMap, entry,
                                                   Constants.F_LANGUAGE_TYPE);
                                if (content != null) {
                                    langAbil.setLanguageType((String) content);
                                }

                                content = getValue(dicInfoMap, entry,
                                                   Constants.F_LANGUAGE_LEVEL);
                                if (content != null) {
                                    langAbil.setLanguageLevel((String) content);
                                }

                                content = getValue(dicInfoMap, entry,
                                                   Constants.F_SPEAKING_ABILITY);
                                if (content != null) {
                                    langAbil.setSpeakingAbility((String) content);
                                }

                                content = getValue(dicInfoMap, entry,
                                                   Constants.F_WRITE_ABILITY);
                                if (content != null) {
                                    langAbil.setWriteAbility((String) content);
                                }

                                resume.addLangAbil(langAbil);
                            }
                        }
                        resume.addDetail(key,
                                         entry.get(Constants.TEXT_CONTENT));
                    }
                } catch (Exception e) {
                    logger.error(e.getMessage(), e);
                }
            }
        }
    }

    /**
     * 侯选库简历信息
     *
     * @param resumeMap
     * @param resumeIdList
     */
    private void initResumeApplyInfo(Map<Integer, ResumeVO> resumeMap,
                                     Collection<Integer> resumeIdList,
                                     String type) {

        if (CollectionUtils.isEmpty(resumeMap) ||
                !Constants.TYPE_APPLY.equals(type)) {
            return;
        }

        Map<Integer, Map<String, List<Integer>>> map = new HashMap<>(resumeIdList.size());

        StringBuilder sql = new StringBuilder(
                "SELECT F_RESUME_ID, F_APPLY_STATUS, F_APPLY_STATUS_TYPE FROM ")
                .append(SqlUtils.getTable("t_apply_info"))
                .append(" WHERE ")
                .append(SqlUtils.createInJunction(Constants.RESUME_ID, resumeIdList.size()));
        List<Map<String, Object>> list = resumeDao
                .queryForList(sql.toString(), resumeIdList.toArray());
        if (CollectionUtils.isEmpty(list)) {
            return;
        }

        for (Map<String, Object> entry : list) {
            Integer resumeId = (Integer) entry.get(Constants.RESUME_ID);
            Integer applyStatus = (Integer) entry.get(Constants.F_APPLY_STATUS);
            Integer applyStatusType = (Integer) entry.get(Constants.F_APPLY_STATUS_TYPE);

            if (applyStatus == null && applyStatusType == null) {
                continue;
            }

            Map<String, List<Integer>> statusMap = map.get(resumeId);
            if (statusMap == null) {
                statusMap = new HashMap<>(2);

            }

            if (applyStatus != null) {
                List<Integer> applyStatusList = statusMap.get(Constants.F_APPLY_STATUS);
                if (applyStatusList == null) {
                    applyStatusList = new ArrayList<>();
                    statusMap.put(Constants.F_APPLY_STATUS, applyStatusList);
                }
                applyStatusList.add(applyStatus);
            }

            if (applyStatusType != null) {
                List<Integer> applyStatusTypeList = statusMap.get(Constants.F_APPLY_STATUS_TYPE);
                if (applyStatusTypeList == null) {
                    applyStatusTypeList = new ArrayList<>();
                    statusMap.put(Constants.F_APPLY_STATUS_TYPE, applyStatusTypeList);
                }
                applyStatusTypeList.add(applyStatusType);
            }
            map.put(resumeId, statusMap);
        }

        for (Integer resumeId : map.keySet()) {
            ResumeVO resume = resumeMap.get(resumeId);
            if (resume != null) {
                Map<String, List<Integer>> statusMap = map.get(resumeId);
                if (CollectionUtils.isEmpty(statusMap)) {
                    continue;
                }
                List<Integer> applyStatusList = statusMap.get(Constants.F_APPLY_STATUS);
                if (applyStatusList != null) {
                    resume.setApplyStatus(applyStatusList);
                }
                List<Integer> applyStatusTypeList = statusMap.get(Constants.F_APPLY_STATUS_TYPE);
                if (applyStatusTypeList != null) {
                    resume.setApplyStatusType(applyStatusTypeList);
                }
            }
        }
    }

    private Object getValue(Map<String, String> dicInfoMap,
                            Map<String, Object> entry,
                            String key) {

        Object obj = entry.get(key);
        if (obj == null) {
            return obj;
        }
        if (obj instanceof String) {
            String content = (String) obj;
            StringBuffer sb = new StringBuffer();
            String[] array = content.split(StringUtils.COMMA);
            for (String con : array) {
                if (con.startsWith(Constants.RESUME_VALUE_NULL_START_STR)) {
                    sb.append(con.substring(2)).append(StringUtils.COMMA);
                } else if (con.startsWith("0/")) {
                    String t = dicInfoMap.get(con);
                    if (StringUtils.hasLength(t, true)) {
                        sb.append(t).append(",");
                    }
                } else {
                    sb.append(con).append(",");
                }
            }
            if (StringUtils.hasLength(sb, true)) {

                return sb.substring(0, sb.length() - 1);
            }
        } else if (obj instanceof Date) {
            // 至今
            if (Constants.SO_FAR.equals(obj.toString())
                || Constants.SO_FAR_1.equals(obj.toString())) {
            }
            return obj;
        }
        return obj;
    }

    private void initResumeLabelInfo(Map<Integer, ResumeVO> resumeMap,
                                     Collection<Integer> resumeIdList,
                                     String type) {

        if (CollectionUtils.isEmpty(resumeMap)
            || Constants.TYPE_APPLY.equals(type)) {
            return;
        }

        StringBuilder sb = new StringBuilder(
                "SELECT F_APPLY_ID,F_LABEL_ID,F_ADD_USER,F_ADD_DATE FROM ")
                        .append(SqlUtils.getTable("t_" + type + "_label_relat"))
                        .append(" WHERE ")
                        .append(SqlUtils.createInJunction(Constants.F_APPLY_ID,
                                                          resumeIdList.size()));
        List<Map<String, Object>> list = resumeDao
                .queryForList(sb.toString(), resumeIdList.toArray());
        Map<Integer, Set<Integer>> labelIdMap = new HashMap<>();
        Map<Integer, Map<String, Object>> signHotUserMap = new HashMap<>();

        if (!CollectionUtils.isEmpty(list)) {
            for (Map<String, Object> entry : list) {
                Integer resumeId = (Integer) entry.get(Constants.F_APPLY_ID);
                Integer labelId = (Integer) entry.get(Constants.F_LABEL_ID);

                Set<Integer> labelIdSet = labelIdMap.get(resumeId);
                if (labelIdSet == null) {
                    labelIdSet = new HashSet<>();
                    labelIdMap.put(resumeId, labelIdSet);
                }
                labelIdSet.add(labelId);

                if (Constants.LABEL_HOT_CANDIDATES.equals(labelId)) {
                    signHotUserMap.put(resumeId, entry);
                }
            }

            Iterator it = labelIdMap.keySet().iterator();
            StringBuilder labelIdSb = new StringBuilder();
            while (it.hasNext()) {
                Integer resumeId = (Integer) it.next();
                Set<Integer> labelIdSet = labelIdMap.get(resumeId);
                StringUtils.joinCollectionValueToStr(labelIdSet, labelIdSb);

                ResumeVO resume = resumeMap.get(resumeId);
                if (resume != null) {
                    resume.setLabelId(labelIdSb.toString());
                }

                labelIdSb.setLength(0);
            }

            for (Integer resumeId : signHotUserMap.keySet()) {
                ResumeVO resume = resumeMap.get(resumeId);
                if (resume != null) {
                    Integer userId = (Integer) signHotUserMap.get(resumeId)
                            .get(Constants.F_ADD_USER);
                    if (userId != null) {
                        resume.setSignHotUser(userId);
                    }
                    Date addDate = (Date) signHotUserMap.get(resumeId)
                            .get(Constants.F_ADD_DATE);
                    if (addDate != null) {
                        resume.setSignHotDate(addDate);
                    }
                }
            }
        }
    }

    private void updateResumePostInfo(Map<Integer, ResumeVO> resumeMap,
                                      Collection<Integer> resumeIdList,
                                      String type) {

        if (CollectionUtils.isEmpty(resumeMap)
            || Constants.TYPE_APPLY.equals(type)) {
            return;
        }

        StringBuilder sb = new StringBuilder("SELECT cai.F_RESUME_ID, cai.F_POST_ID, ")
                .append("cpi.F_POST_TYPE, cai.F_POST_NAME, cpi.F_NAME_CH, ")
                .append("cpi.F_NAME_EN, F_EXTERNAL_NAME_CH,cpi.F_EXTERNAL_NAME_EN, ")
                .append("cpi.F_ORG_ID, cpi.F_PROJECT_ID FROM ")
                .append(SqlUtils.getTable("t_" + type + "_apply_info cai "))
                .append("LEFT JOIN ")
                .append(SqlUtils.getTable("t_corp_post_info"))
                .append(" cpi ON cpi.F_ID = cai.F_POST_ID ")
                .append(" WHERE ")
                .append(SqlUtils.createInJunction("cai.F_RESUME_ID",
                        resumeIdList.size()));
        List<Map<String, Object>> list = resumeDao
                .queryForList(sb.toString(), resumeIdList.toArray());

        if (!CollectionUtils.isEmpty(list)) {
            Map<Integer, Map<String, Set<String>>> infoMap = new HashMap<>(
                    2000);
            /**
             * postName=POST_NAME 和 F_NAME_CH 和 F_NAME_EN,逗号分割
             * externalName=F_EXTERNAL_NAME_CH 和 F_EXTERNAL_NAME_EN,逗号分割
             */
            for (Map<String, Object> entry : list) {
                Integer resumeId = (Integer) entry.get(Constants.RESUME_ID);
                Integer postId = (Integer) entry.get(Constants.F_POST_ID);
                String postType = (String) entry.get(Constants.F_POST_TYPE);
                String postName = (String) entry.get(Constants.F_POST_NAME);
                String postNameCH = (String) entry.get(Constants.F_NAME_CH);
                String postNameEN = (String) entry.get(Constants.F_NAME_EN);
                String externalNameCH = (String) entry
                        .get(Constants.F_EXTERNAL_NAME_CH);
                String externalNameEN = (String) entry
                        .get(Constants.F_EXTERNAL_NAME_EN);
                Integer orgId = (Integer) entry.get(Constants.F_ORG_ID);
                orgId = orgId == null ? Constants.DEFAULT_ORG_ID : orgId;
                Integer projectId = (Integer) entry.get(Constants.F_PROJECT_ID);

                if (resumeId == null || postId == null) {
                    continue;
                }

                Map<String, Set<String>> postMap = infoMap.get(resumeId);
                if (postMap == null) {
                    postMap = new HashMap<>();
                    infoMap.put(resumeId, postMap);
                }

                /**
                 * 添加并去重
                 */
                addPostInfoSet(Constants.F_POST_ID,
                               postMap.get(Constants.F_POST_ID), postMap,
                               postId.toString());
                addPostInfoSet(Constants.F_POST_TYPE,
                               postMap.get(Constants.F_POST_TYPE), postMap,
                               postType);
                addPostInfoSet(Constants.F_POST_NAME,
                               postMap.get(Constants.F_POST_NAME), postMap,
                               postName);
                addPostInfoSet(Constants.F_POST_NAME,
                               postMap.get(Constants.F_POST_NAME), postMap,
                               postNameCH);
                addPostInfoSet(Constants.F_POST_NAME,
                               postMap.get(Constants.F_POST_NAME), postMap,
                               postNameEN);
                addPostInfoSet(Constants.F_EXTERNAL_NAME,
                               postMap.get(Constants.F_EXTERNAL_NAME), postMap,
                               externalNameCH);
                addPostInfoSet(Constants.F_EXTERNAL_NAME,
                               postMap.get(Constants.F_EXTERNAL_NAME), postMap,
                               externalNameEN);
                addPostInfoSet(Constants.F_ORG_ID,
                               postMap.get(Constants.F_ORG_ID), postMap,
                               orgId.toString());
                if (projectId != null) {
                    addPostInfoSet(Constants.F_PROJECT_ID,
                                   postMap.get(Constants.F_PROJECT_ID), postMap,
                                   projectId.toString());
                }
            }

            // 获取所有组织机构，放入orgMap
            StringBuilder sqlBuilder = new StringBuilder(
                    "SELECT F_ID uniqueKey,F_CODE code,F_TYPE type FROM ")
                            .append(SqlUtils.getTable("t_corp_org_info"));
            List<Map<String, Object>> orgList = resumeDao
                    .queryForList(sqlBuilder.toString());
            Map<String, Map<String, Object>> orgMap = new HashMap<>(
                    orgList.size());
            for (Map map : orgList) {
                String uniqueKey = map.get("uniqueKey").toString();
                orgMap.put(uniqueKey, map);
            }

            StringBuilder postIdSb = new StringBuilder();
            StringBuilder postNameSb = new StringBuilder();
            StringBuilder postTypeSb = new StringBuilder();
            StringBuilder externalNameSb = new StringBuilder();
            StringBuilder projectSb = new StringBuilder();
            StringBuilder orgIdSb = new StringBuilder();

            Iterator it = infoMap.keySet().iterator();
            while (it.hasNext()) {
                Integer resumeId = (Integer) it.next();

                ResumeVO resume = resumeMap.get(resumeId);
                Map<String, Set<String>> postMap = infoMap.get(resumeId);

                addPostInfoSet(Constants.F_POST_TYPE,
                               postMap.get(Constants.F_POST_TYPE), postMap,
                               resume.getPostType());
                addPostInfoSet(Constants.F_POST_NAME,
                               postMap.get(Constants.F_POST_NAME), postMap,
                               resume.getPostName());
                addPostInfoSet(Constants.F_EXTERNAL_NAME,
                               postMap.get(Constants.F_EXTERNAL_NAME), postMap,
                               resume.getExternalPostName());
                addPostInfoSet(Constants.F_ORG_ID,
                               postMap.get(Constants.F_ORG_ID), postMap,
                               resume.getOrgId());

                buildPostInfoString(Constants.F_POST_ID, postMap, postIdSb);
                buildPostInfoString(Constants.F_POST_NAME, postMap, postNameSb);
                buildPostInfoString(Constants.F_POST_TYPE, postMap, postTypeSb);
                buildPostInfoString(Constants.F_EXTERNAL_NAME, postMap,
                                    externalNameSb);
                buildPostInfoString(Constants.F_PROJECT_ID, postMap, projectSb);
                buildOrgIdString(postMap.get(Constants.F_ORG_ID), orgMap,
                                 orgIdSb);

                if (resume != null) {
                    resume.setPostId(postIdSb.length() > 0 ? postIdSb.toString()
                                                           : null);
                    resume.setPostName(postNameSb.length() > 0 ?
                            (postNameSb.length() <=500 ? postNameSb.toString()
                                    : postNameSb.toString().substring(0,500))
                            : null);
                    resume.setPostType(postTypeSb.length() > 0 ? postTypeSb
                            .toString() : null);
                    resume.setExternalPostName(externalNameSb
                            .length() > 0 ?
                            (externalNameSb.length() <=500 ? externalNameSb.toString() :
                                    externalNameSb.toString().substring(0,500))
                            : null);
                    resume.setProjectId(projectSb.length() > 0 ? projectSb
                            .toString() : null);
                    resume.setOrgId(orgIdSb.length() > 0 ? orgIdSb.toString()
                                                         : null);
                }

                postIdSb.setLength(0);
                postNameSb.setLength(0);
                postTypeSb.setLength(0);
                externalNameSb.setLength(0);
                projectSb.setLength(0);
                orgIdSb.setLength(0);
            }
        }
    }

    private void addPostInfoSet(String key,
                                Set<String> set,
                                Map<String, Set<String>> postMap,
                                String value) {

        if (StringUtils.hasLength(value, true)) {
            if (set == null) {
                set = new HashSet<>();
                postMap.put(key, set);
            }

            set.add(value);
        }
    }

    private void buildPostInfoString(String key,
                                     Map<String, Set<String>> postMap,
                                     StringBuilder sb) {

        Set<String> set = postMap.get(key);
        if (set == null) {
            return;
        }
        StringUtils.joinCollectionValueToStr(set, sb);
    }

    private void buildOrgIdString(Set<String> orgIdSet,
                                  Map<String, Map<String, Object>> orgMap,
                                  StringBuilder sb) {

        if (orgIdSet == null) {
            return;
        }
        String companyId = null;
        for (String orgId : orgIdSet) {
            companyId = getCompanyId(orgId, orgMap);
            if (StringUtils.hasLength(companyId)) {
                if (sb.length() > 0) {
                    sb.append(StringUtils.COMMA);
                    sb.append(StringUtils.SPACE);
                }
                sb.append(companyId);
            }
        }
    }

    private String getCompanyId(String orgId,
                                Map<String, Map<String, Object>> orgMap) {

        String companyId = StringUtils.EMPTY;
        if (orgId != null) {
            Map<String, Object> org = orgMap.get(orgId);
            if (org == null) {
                return companyId;
            }
            String code = (String) org.get("code");
            if (!StringUtils.hasLength(code, true)) {
                return companyId;
            }

            String[] codeAry = code.split(StringUtils.DIAGONAL);
            int length = codeAry.length;
            if (length >= 2) {
                for (int i = length - 1; i >= 0; i--) {
                    String codeId = codeAry[i];
                    if (!StringUtils.hasLength(codeId, true)) {
                        continue;
                    }

                    Map orgTemp = orgMap.get(codeId);
                    if (orgTemp != null) {
                        Integer type = Integer
                                .parseInt(orgTemp.get("type").toString());
                        Integer uniqueKey = Integer
                                .parseInt(orgTemp.get("uniqueKey").toString());
                        if (isCompanyOrg(uniqueKey, type)) {
                            companyId = uniqueKey.toString();
                            break;
                        }
                    }
                }
            }
        }

        return companyId;
    }

    private boolean isCompanyOrg(Integer uniqueKey, Integer type) {

        if (Constants.DEFAULT_ORG_ID.equals(uniqueKey)) {
            return true;
        } else {
            return type == null ? false
                                : Constants.ORG_TYPE_COMPANY.equals(type);
        }
    }

    /**
     * 简历编号
     *
     * @param resumeMap
     * @param resumeIdList
     * @param type
     */
    private void initResumeOriginalInfo(Map<Integer, ResumeVO> resumeMap,
                                        Collection<Integer> resumeIdList,
                                        String type) {

        if (CollectionUtils.isEmpty(resumeMap)
            || Constants.TYPE_APPLY.equals(type)) {
            return;
        }

        // T_CAND_RESUME_ORIGINAL_ID
        StringBuilder sb = new StringBuilder(
                "SELECT F_RESUME_ID, F_ORIGINAL_ID FROM ")
                        .append(SqlUtils.getTable("T_CAND_RESUME_ORIGINAL_ID"))
                        .append(" WHERE ")
                        .append(SqlUtils.createInJunction("F_RESUME_ID", resumeIdList.size()))
                        .append(" AND F_ORIGINAL_ID IS NOT NULL AND F_ORIGINAL_ID !=''");
        List<Map<String, Object>> list = resumeDao
                .queryForList(sb.toString(), resumeIdList.toArray());
        if (!CollectionUtils.isEmpty(list)) {

            Map<Integer, Set<String>> originalIdMap = new HashMap<>(
                    resumeIdList.size());

            for (Map<String, Object> entry : list) {
                Integer resumeId = (Integer) entry.get(Constants.RESUME_ID);
                String originalId = (String) entry.get(Constants.F_ORIGINAL_ID);

                Set<String> originalIdSet = originalIdMap.get(resumeId);
                if (originalIdSet == null) {
                    originalIdSet = new HashSet<>();
                    originalIdMap.put(resumeId, originalIdSet);
                }
                originalIdSet.add(originalId);
            }

            StringBuilder originalIdSb = new StringBuilder();
            for (Integer resumeId : originalIdMap.keySet()) {
                ResumeVO resume = resumeMap.get(resumeId);
                if (resume != null) {
                    StringUtils.joinCollectionValueToStr(
                                                         originalIdMap
                                                                 .get(resumeId),
                                                         originalIdSb);
                    resume.setOriginalId(originalIdSb.toString());
                    originalIdSb.setLength(0);
                }
            }
        }
    }

    /**
     * 第一学位
     *
     * @param resumeMap
     * @param type
     */
    private void updateResumeFirstEducation(Map<Integer, ResumeVO> resumeMap,
                                            String type) {

        if (CollectionUtils.isEmpty(resumeMap)
            || Constants.TYPE_APPLY.equals(type)) {
            return;
        }

        Iterator<ResumeVO> it = resumeMap.values().iterator();
        while (it.hasNext()) {
            ResumeVO resumeVO = it.next();
            List<Education> educations = resumeVO.getEduExp();
            if (!CollectionUtils.isEmpty(educations)) {
                boolean hasCHFirst = false;
                boolean hasENFirst = false;

                List<Integer> indexCHList = null;
                List<Integer> indexENList = null;
                for (int i = 0; i < educations.size(); i++) {

                    Education e = educations.get(i);
                    int lan = e.getLan();

                    if (e.isFirst()) {
                        if (lan == 1) {
                            hasCHFirst = true;
                        } else {
                            hasENFirst = true;
                        }
                    }

                    String education = e.getEducation();
                    if (StringUtils.hasLength(education, true)
                        && Constants.EDUCATION_BACHELOR.equals(education)) {
                        if (e.getLan() == 1) {
                            if (indexCHList == null) {
                                indexCHList = new ArrayList<>();
                            }
                            indexCHList.add(i);
                        } else {
                            if (indexENList == null) {
                                indexENList = new ArrayList<>();
                            }
                            indexENList.add(i);
                        }
                    }
                }

                if (!hasCHFirst && indexCHList != null) {
                    for (int index : indexCHList) {
                        educations.get(index).setFirst(true);
                    }
                }
                if (!hasENFirst && indexENList != null) {
                    for (int index : indexENList) {
                        educations.get(index).setFirst(true);
                    }
                }
            }
        }
    }

    /**
     * 面试评价
     *
     * @param resumeMap
     * @param resumeIdList
     * @param dicInfoMap
     * @param type
     */
    private void initResumeInterviewEvaluateInfo(Map<Integer, ResumeVO> resumeMap,
                                                 Collection<Integer> resumeIdList,
                                                 Map<String, String> dicInfoMap,
                                                 String type) {

        if (CollectionUtils.isEmpty(resumeMap)
            || Constants.TYPE_APPLY.equals(type)) {
            return;
        }

        Map<Integer, StringBuilder> evaluateMap = new HashMap<>(
                resumeIdList.size());

        // t_cand_interivew_simple_evaluate
        StringBuilder sql = new StringBuilder(
                "SELECT F_RESUME_ID, F_EVALUATE_VALUE FROM ")
                        .append(SqlUtils
                                .getTable("t_cand_interivew_simple_evaluate"))
                        .append(" WHERE ")
                        .append(SqlUtils.createInJunction(Constants.RESUME_ID, resumeIdList.size()))
                        .append(" AND F_EVALUATE_VALUE IS NOT NULL AND F_EVALUATE_VALUE != ''");
        List<Map<String, Object>> list = resumeDao
                .queryForList(sql.toString(), resumeIdList.toArray());
        if (!CollectionUtils.isEmpty(list)) {
            for (Map<String, Object> entry : list) {
                Integer resumeId = (Integer) entry.get(Constants.RESUME_ID);
                String evaluateValue = (String) getValue(dicInfoMap, entry,
                                                         Constants.F_EVALUATE_VALUE);

                StringBuilder sb = evaluateMap.get(resumeId);
                if (sb == null) {
                    sb = new StringBuilder();
                    evaluateMap.put(resumeId, sb);
                }
                if (sb.length() > 0) {
                    sb.append(StringUtils.SEMICOLON).append(StringUtils.SPACE);
                }
                sb.append(evaluateValue);
            }
        }

        // t_cand_interview_evaluate
        StringBuilder sql2 = new StringBuilder(
                "SELECT apply.F_RESUME_ID,e.F_ITEM_VALUE FROM ")
                        .append(SqlUtils.getTable("t_cand_interview_evaluate"))
                        .append(" e LEFT JOIN ")
                        .append(SqlUtils.getTable("t_cand_interview_plan_info"))
                        .append(" plan on plan.F_ID = e.F_PLAN_ID LEFT JOIN ")
                        .append(SqlUtils.getTable("t_cand_apply_info"))
                        .append(" apply on apply.f_id = plan.F_APPLY_ID WHERE ")
                        .append(SqlUtils.createInJunction("apply."
                                                          + Constants.RESUME_ID,
                                                          resumeIdList.size()))
                        .append(" AND e.F_ITEM_VALUE IS NOT NULL AND e.F_ITEM_VALUE != ''");
        List<Map<String, Object>> list2 = resumeDao
                .queryForList(sql2.toString(), resumeIdList.toArray());
        if (!CollectionUtils.isEmpty(list2)) {
            for (Map<String, Object> entry : list2) {
                Integer resumeId = (Integer) entry.get(Constants.RESUME_ID);
                String evaluateValue = (String) getValue(dicInfoMap, entry,
                                                         Constants.F_ITEM_VALUE);

                StringBuilder sb = evaluateMap.get(resumeId);
                if (sb == null) {
                    sb = new StringBuilder();
                    evaluateMap.put(resumeId, sb);
                }
                if (sb.length() > 0) {
                    sb.append(StringUtils.SEMICOLON).append(StringUtils.SPACE);
                }
                sb.append(evaluateValue);
            }
        }

        for (Integer resumeId : evaluateMap.keySet()) {
            ResumeVO resume = resumeMap.get(resumeId);
            if (resume != null) {
                resume.setInterviewEvaluate(evaluateMap.get(resumeId)
                        .toString());
            }
        }
    }

    /**
     * 备注
     *
     * @param resumeMap
     * @param resumeIdList
     * @param type
     */
    private void initResumeRemarkInfo(Map<Integer, ResumeVO> resumeMap,
                                      Collection<Integer> resumeIdList,
                                      String type) {

        if (CollectionUtils.isEmpty(resumeMap)
            || Constants.TYPE_APPLY.equals(type)) {
            return;
        }

        Map<Integer, StringBuilder> remarkMap = new HashMap<>(
                resumeIdList.size());

        // t_cand_remark_info
        StringBuilder sql = new StringBuilder(
                "SELECT F_RESUME_ID, F_REMARK FROM ")
                        .append(SqlUtils.getTable("t_cand_remark_info"))
                        .append(" WHERE ")
                        .append(SqlUtils.createInJunction(Constants.RESUME_ID, resumeIdList.size()))
                        .append(" AND F_REMARK IS NOT NULL AND F_REMARK != ''");
        List<Map<String, Object>> list = resumeDao
                .queryForList(sql.toString(), resumeIdList.toArray());
        if (!CollectionUtils.isEmpty(list)) {
            for (Map<String, Object> entry : list) {
                Integer resumeId = (Integer) entry.get(Constants.RESUME_ID);
                String remark = (String) entry.get(Constants.F_REMARK);

                StringBuilder sb = remarkMap.get(resumeId);
                if (sb == null) {
                    sb = new StringBuilder();
                    remarkMap.put(resumeId, sb);
                }
                if (sb.length() > 0) {
                    sb.append(StringUtils.SEMICOLON).append(StringUtils.SPACE);
                }
                sb.append(remark);
            }
        }

        for (Integer resumeId : remarkMap.keySet()) {
            ResumeVO resume = resumeMap.get(resumeId);
            if (resume != null) {
                resume.setRemark(remarkMap.get(resumeId).toString());
            }
        }
    }

    /**
     * 宣讲会
     * TODO
     * @param resumeMap
     * @param resumeIdList
     * @param type
     */
    private void initResumeCareerfairInfo(Map<Integer, ResumeVO> resumeMap,
                                          Collection<Integer> resumeIdList,
                                          String type) {

        if (CollectionUtils.isEmpty(resumeMap)
            || Constants.TYPE_APPLY.equals(type)) {
            return;
        }

        Map<Integer, Set<Integer>> careerfairIdMap = new HashMap<>(
                resumeIdList.size());

        StringBuilder sql = new StringBuilder(
                "SELECT cpi.F_RESUME_ID, co.F_CAREERFAIR_ID FROM ")
                        .append(SqlUtils.getTable("T_CAREERFAIR_OPENID"))
                        .append(" co LEFT JOIN ")
                        .append(SqlUtils.getTable("T_CAND_PERS_INFO_CH"))
                        .append(" cpi ON cpi.F_NAME = co.F_NAME AND cpi.F_MOBILE_PHONE = co.F_PHONE LEFT JOIN ")
                        .append(SqlUtils.getTable("t_cand_apply_info"))
                        .append(" cai ON CAI.F_RESUME_ID = CPI.F_RESUME_ID WHERE ")
                        .append(SqlUtils.createInJunction("cpi." + Constants.RESUME_ID,resumeIdList.size()))
                        .append(" AND cpi.F_RESUME_ID IS NOT NULL AND cai.F_RESUME_ID IS NOT NULL AND co.F_CAREERFAIR_ID IS NOT NULL ")
                        .append(" GROUP BY cpi.F_RESUME_ID");
        List<Map<String, Object>> list = resumeDao
                .queryForList(sql.toString(), resumeIdList.toArray());
        if (!CollectionUtils.isEmpty(list)) {
            for (Map<String, Object> entry : list) {

                Integer resumeId = (Integer) entry.get(Constants.RESUME_ID);
                Integer careerfairId = (Integer) entry
                        .get(Constants.F_CAREERFAIR_ID);

                Set<Integer> set = careerfairIdMap.get(resumeId);
                if (set == null) {
                    set = new HashSet<>();
                    careerfairIdMap.put(resumeId, set);
                }
                set.add(careerfairId);
            }
        }

        StringBuilder sb = new StringBuilder();
        for (Integer resumeId : careerfairIdMap.keySet()) {
            ResumeVO resume = resumeMap.get(resumeId);
            if (resume != null) {
                StringUtils
                        .joinCollectionValueToStr(careerfairIdMap.get(resumeId),
                                                  sb);
                resume.setCareerFairId(sb.length() > 0 ? sb.toString() : null);
            }
            sb.setLength(0);
        }
    }

    /**
     * 站点
     *
     * @param resumeMap
     * @param resumeIdList
     * @param type
     */
    private void initResumeCandApplyInfo(Map<Integer, ResumeVO> resumeMap,
                                         Collection<Integer> resumeIdList,
                                         String type) {

        if (CollectionUtils.isEmpty(resumeMap)
            || Constants.TYPE_APPLY.equals(type)) {
            return;
        }

        Map<Integer, Set<Integer>> map = new HashMap<>(resumeIdList.size());

        StringBuilder sql = new StringBuilder(
                "SELECT F_RESUME_ID, F_SITE FROM ")
                        .append(SqlUtils.getTable("t_cand_apply_info"))
                        .append(" WHERE ")
                        .append(SqlUtils.createInJunction(Constants.RESUME_ID, resumeIdList.size()))
                        .append(" AND F_SITE IS NOT NULL");
        List<Map<String, Object>> list = resumeDao
                .queryForList(sql.toString(), resumeIdList.toArray());
        if (!CollectionUtils.isEmpty(list)) {
            for (Map<String, Object> entry : list) {
                Integer resumeId = (Integer) entry.get(Constants.RESUME_ID);
                Integer site = (Integer) entry.get(Constants.F_SITE);

                if (site == null) {
                    continue;
                }

                Set<Integer> set = map.get(resumeId);
                if (set == null) {
                    set = new HashSet<>();
                    map.put(resumeId, set);
                }
                set.add(site);
            }
        }

        StringBuilder sb = new StringBuilder();
        for (Integer resumeId : map.keySet()) {
            ResumeVO resume = resumeMap.get(resumeId);
            if (resume != null) {
                StringUtils.joinCollectionValueToStr(map.get(resumeId), sb);
                resume.setSite(sb.length() > 0 ? sb.toString() : null);
            }
            sb.setLength(0);
        }
    }

    /**
     * 猎头id
     *
     * @param resumeMap
     * @param resumeIdList
     * @param type
     */
    private void initResumeCandHeadhuntingIdInfo(Map<Integer, ResumeVO> resumeMap,
                                                 Collection<Integer> resumeIdList,
                                                 String type) {

        if (CollectionUtils.isEmpty(resumeMap)
                || Constants.TYPE_APPLY.equals(type)) {
            return;
        }

        Map<Integer, Integer> map = new HashMap<>(resumeIdList.size());

        StringBuilder sql = new StringBuilder(
                "SELECT F_RESUME_ID, F_HEADHUNTING_ID FROM ")
                .append(SqlUtils.getTable("t_cand_apply_info"))
                .append(" WHERE ")
                .append(SqlUtils.createInJunction(Constants.RESUME_ID, resumeIdList.size()))
                .append(" AND F_HEADHUNTING_ID IS NOT NULL");
        List<Map<String, Object>> list = resumeDao
                .queryForList(sql.toString(), resumeIdList.toArray());
        if (!CollectionUtils.isEmpty(list)) {
            for (Map<String, Object> entry : list) {
                Integer resumeId = (Integer) entry.get(Constants.RESUME_ID);
                Integer headhuntingId = (Integer) entry.get(Constants.F_HEADHUNTING_ID);

                map.put(resumeId, headhuntingId);
            }
        }

        for (Integer resumeId : map.keySet()) {
            ResumeVO resume = resumeMap.get(resumeId);
            if (resume != null && resume.getHeadhuntingId() == null) {
                resume.setHeadhuntingId(map.get(resumeId));
            }
        }
    }

    /**
     * 简历来源
     *
     * @param resumeMap
     * @param resumeIdList
     * @param type
     */
    private void initResumeResourceInfo(Map<Integer, ResumeVO> resumeMap,
                                        Collection<Integer> resumeIdList,
                                        String type) {

        if (CollectionUtils.isEmpty(resumeMap)
            || Constants.TYPE_APPLY.equals(type)) {
            return;
        }

        Map<Integer, Set<String>> map = new HashMap<>(resumeIdList.size());

        StringBuilder sql = new StringBuilder(
                "SELECT F_RESUME_ID,F_RESUME_SOURCE,F_NET_CHANNEL_ID,F_BRAND_ID,F_WEB_USER_ID FROM ")
                        .append(SqlUtils.getTable("t_cand_apply_info"))
                        .append(" WHERE ")
                        .append(SqlUtils.createInJunction(Constants.RESUME_ID, resumeIdList.size()))
                        .append(" AND F_RESUME_SOURCE IS NOT NULL");
        List<Map<String, Object>> list = resumeDao
                .queryForList(sql.toString(), resumeIdList.toArray());
        if (!CollectionUtils.isEmpty(list)) {

            StringBuilder sql2 = new StringBuilder(
                    "SELECT F_SEARCH_CHANNEL_SOHU FROM ")
                            .append(SqlUtils.getTable("T_CORP_BASIC_INFO"))
                            .append(" WHERE F_ID = 1");
            Map<String, Object> sohuMap = resumeDao
                    .queryForMap(sql2.toString());
            boolean searchChannelSohu = sohuMap
                    .get("F_SEARCH_CHANNEL_SOHU") != null
                                        && Integer.parseInt(sohuMap
                                                .get("F_SEARCH_CHANNEL_SOHU")
                                                .toString()) == Constants.YES ? true
                                                                              : false;
            for (Map<String, Object> entry : list) {
                Integer resumeId = (Integer) entry.get(Constants.RESUME_ID);
                Integer resumeSource = (Integer) entry
                        .get(Constants.F_RESUME_SOURCE);

                Set<String> set = map.get(resumeId);
                if (set == null) {
                    set = new HashSet<>();
                    map.put(resumeId, set);
                }

                String sourceChannel = resumeSource.toString();

                if (resumeSource == ChannelType.WXJXB
                    || resumeSource == ChannelType.JXBAPP
                    || resumeSource == ChannelType.INNER_RECOMMEND
                    || resumeSource == ChannelType.OUTER_RECOMMEND
                    || resumeSource == ChannelType.XJR) {
                    // 内外推：15,16,20,25,34
                    set.add(sourceChannel);
                } else if (resumeSource == ChannelType.AGENT) {
                    // 中介
                    Integer huntingId = (Integer) entry
                            .get(Constants.F_HEADHUNTING_ID);
                    if (huntingId != null) {
                        sourceChannel += StringUtils.UNDERLINE + huntingId;
                    }
                    set.add(sourceChannel);

                } else if (resumeSource == ChannelType.WEB) {
                    // 前台品牌
                    Integer netChannelId = (Integer) entry
                            .get(Constants.F_NET_CHANNEL_ID);
                    if (netChannelId != null) {
                        sourceChannel += StringUtils.UNDERLINE + netChannelId;
                    }

                    Integer brandId = (Integer) entry.get(Constants.F_BRAND_ID);
                    if (brandId != null) {
                        sourceChannel += StringUtils.UNDERLINE + brandId;
                    }

                    set.add(sourceChannel);

                } else if (resumeSource == ChannelType.INNER_RECOMMEND) {
                    // 内部推荐PC端
                    Integer webUserId = (Integer) entry
                            .get(Constants.F_WEB_USER_ID);
                    if (webUserId != null) {
                        sourceChannel += StringUtils.UNDERLINE + webUserId;
                    }

                    set.add(sourceChannel);
                } else {
                    Integer netChannelId = (Integer) entry
                            .get(Constants.F_NET_CHANNEL_ID);
                    if (netChannelId != null) {
                        if (resumeSource == ChannelType.NET
                            && searchChannelSohu) {
                            // 搜狐网络渠道
                            StringBuilder sql3 = new StringBuilder(
                                    "SELECT F_ID FROM ")
                                            .append(SqlUtils
                                                    .getTable("T_CHANNEL_NET"))
                                            .append(" WHERE F_CHANNLE_DIC = ? AND F_STATUS = ?");
                            List<Map<String, Object>> chanelList = resumeDao
                                    .queryForList(sql3.toString(), netChannelId,
                                                  Constants.YES);
                            if (!CollectionUtils.isEmpty(chanelList)) {
                                for (Map chanel : chanelList) {
                                    Integer chanelId = Integer.parseInt(chanel
                                            .get("F_ID").toString());
                                    set.add(sourceChannel
                                            + StringUtils.UNDERLINE
                                            + chanelId);
                                }
                                continue;
                            }
                        }

                        if (netChannelId != 160001) {
                            sourceChannel += StringUtils.UNDERLINE
                                             + netChannelId;
                        }
                    }

                    set.add(sourceChannel);
                }
            }

            StringBuilder sb = new StringBuilder();

            for (Integer resumeId : map.keySet()) {
                Set<String> set = map.get(resumeId);
                if (set == null || set.size() == 0) {
                    continue;
                }

                ResumeVO resume = resumeMap.get(resumeId);
                if (resume != null) {
                    StringUtils.joinCollectionValueToStr(set, sb);
                    resume.setSourceChannel(sb.length() > 0 ? sb.toString()
                                                            : null);
                }

                sb.setLength(0);
            }
        }
    }

    /**
     * 人才库类别
     *
     * @param resumeMap
     * @param resumeIdList
     * @param type
     */
    private void initResumeTalentPoolCategoryInfo(Map<Integer, ResumeVO> resumeMap,
                                                  Collection<Integer> resumeIdList,
                                                  String type) {

        if (CollectionUtils.isEmpty(resumeMap)
            || Constants.TYPE_APPLY.equals(type)) {
            return;
        }

        Map<Integer, Set<Integer>> map = new HashMap<>(resumeIdList.size());

        StringBuilder sql = new StringBuilder(
                "SELECT F_RESUME_ID, F_STRUCTURE_ID FROM ")
                        .append(SqlUtils.getTable("t_cand_own_structure"))
                        .append(" WHERE ")
                        .append(SqlUtils.createInJunction(Constants.RESUME_ID, resumeIdList.size()))
                        .append(" AND F_STRUCTURE_ID IS NOT NULL");
        List<Map<String, Object>> list = resumeDao
                .queryForList(sql.toString(), resumeIdList.toArray());
        if (!CollectionUtils.isEmpty(list)) {
            for (Map<String, Object> entry : list) {
                Integer resumeId = (Integer) entry.get(Constants.RESUME_ID);
                Integer structureId = (Integer) entry
                        .get(Constants.F_STRUCTURE_ID);

                Set<Integer> set = map.get(resumeId);
                if (set == null) {
                    set = new HashSet<>();
                    map.put(resumeId, set);
                }
                set.add(structureId);
            }
        }

        StringBuilder sb = new StringBuilder();
        for (Integer resumeId : map.keySet()) {
            ResumeVO resume = resumeMap.get(resumeId);
            if (resume != null) {
                StringUtils.joinCollectionValueToStr(map.get(resumeId), sb);
                resume.setStructureId(sb.length() > 0 ? sb.toString() : null);
            }

            sb.setLength(0);
        }
    }

    /**
     * 文件夹
     *
     * @param resumeMap
     * @param resumeIdList
     * @param type
     */
    private void initResumeFolderInfo(Map<Integer, ResumeVO> resumeMap,
                                      Collection<Integer> resumeIdList,
                                      String type) {
        if (CollectionUtils.isEmpty(resumeMap) || Constants.TYPE_APPLY.equals(type)) {
            return;
        }

        StringBuilder sb = new StringBuilder(
                "SELECT F_RESUME_ID, F_FOLDER_ID FROM ")
                .append(SqlUtils.getTable("t_cand_folders_relat"))
                .append(" WHERE ")
                .append(SqlUtils.createInJunction(Constants.RESUME_ID, resumeIdList.size()));
        List<Map<String, Object>> list = resumeDao
                .queryForList(sb.toString(), resumeIdList.toArray());
        Map<Integer, Set<Integer>> folerIdMap = new HashMap<>();

        if (!CollectionUtils.isEmpty(list)) {
            for (Map<String, Object> entry : list) {
                Integer resumeId = (Integer) entry.get(Constants.RESUME_ID);
                Integer folerId = (Integer) entry.get(Constants.F_FOLDER_ID);

                Set<Integer> folerIdSet = folerIdMap.get(resumeId);
                if (folerIdSet == null) {
                    folerIdSet = new HashSet<>();
                    folerIdMap.put(resumeId, folerIdSet);
                }
                folerIdSet.add(folerId);
            }

            Iterator it = folerIdMap.keySet().iterator();
            StringBuilder folderIdSb = new StringBuilder();
            while (it.hasNext()) {
                Integer resumeId = (Integer) it.next();
                Set<Integer> folerIdSet = folerIdMap.get(resumeId);
                StringUtils.joinCollectionValueToStr(folerIdSet, folderIdSb);

                ResumeVO resume = resumeMap.get(resumeId);
                if (resume != null) {
                    resume.setFolderId(folderIdSb.toString());
                }

                folderIdSb.setLength(0);
            }
        }
    }

}
