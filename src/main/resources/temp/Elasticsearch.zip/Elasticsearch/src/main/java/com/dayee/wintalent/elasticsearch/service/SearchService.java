
package com.dayee.wintalent.elasticsearch.service;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.http.client.methods.HttpPost;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.dayee.wintalent.elasticsearch.constant.ChannelType;
import com.dayee.wintalent.elasticsearch.constant.Constants;
import com.dayee.wintalent.elasticsearch.constant.SearchConstants;
import com.dayee.wintalent.elasticsearch.framework.datasource.DynamicDataSourceContextHolder;
import com.dayee.wintalent.elasticsearch.util.*;

@Service
public class SearchService {

    private static final Logger   logger                             = LoggerFactory
            .getLogger(SearchService.class);

    public static final String    OR_KEYWORD_PATTERN_REGEX           = "\\s|,|，";

    public static final String    KEYWORD_PATTERN_REGEX              = "\\+|\\-";

    public static final Pattern   SENTENCE_PATTERN                   = Pattern
            .compile("\"|“|”");

    public static final Pattern   OR_KEYWORD_PATTERN                 = Pattern
            .compile(OR_KEYWORD_PATTERN_REGEX);

    public static final Pattern   KEYWORD_PATTERN                    = Pattern
            .compile(KEYWORD_PATTERN_REGEX);

    public static final String    KEYWORD_NEED_BOTH_HAVE             = "+";

    public static final String    KEYWORD_EXCEPT                     = "-";

    public static final int       KEYWORD_TYPE_LAST_COMPANY          = 1;

    public static final int       KEYWORD_TYPE_TARGET_COMPANY        = 2;

    public static final int       KEYWORD_TYPE_TARGET_SCHOOL         = 3;

    public static final int       KEYWORD_TYPE_POST                  = 4;

    public static final int       KEYWORD_TYPE_NAME                  = 5;

    public static final int       KEYWORD_TYPE_RESUME                = 6;

    public static final int       KEYWORD_TYPE_INTERVIEW             = 7;

    public static final int       KEYWORD_TYPE_REMARK                = 8;

    public static final int       KEYWORD_TYPE_SMART                 = 9;

    public static final int       KEYWORD_TYPE_RELATED_COMPANY       = 10;

    public static final int       KEYWORD_TYPE_RELATED_SCHOOL        = 11;

    public static final int       FIELD_TYPE_FIRST_DEGREE            = 12;

    public static final int       FIELD_TYPE_FIRST_SCHOOL            = 13;

    public static final int       FIELD_TYPE_HIGHTEST_DEGREE         = 14;

    public static final int       FIELD_TYPE_HIGHTEST_SCHOOL         = 15;

    public static final int       FIELD_TYPE_LANGUAGE_LEVEL          = 16;

    public static final int       FIELD_TYPE_SPEAKING_SKILLS         = 17;

    public static final int       FIELD_TYPE_WRITING_SKILLS          = 18;

    public static final int       FIELD_TYPE_SENIOR_RESUME_TYPE_NULL = 19;

    private static final String   SOURCE_TALENT_QUERY_FIELDS        = "{\"includes\":[\"resumeId\",\"brandId\",\"accountPlace\",\"livingPlace\",\"birthday\",\"workYears\",\"postType\",\"postName\",\"subject\",\"education\",\"graduateDate\",\"school\",\"email\",\"gender\",\"mobilePhone\",\"name\",\"netChannelId\",\"reason\",\"resumeSource\",\"persCode\",\"resumeType\",\"intoTalentPoolTime\",\"currentIntoCandDate\",\"intoTalentPoolTache\",\"talentPoolType\",\"updateDate\",\"isLocked\",\"isDisuse\",\"isSenior\",\"isBlackUser\",\"isInner\",\"headhuntingId\",\"hadEvType\",\"innerRecruitType\",\"recruitType\",\"overallScore\",\"suitableOrImproper\"]}";

    private static final String   SOURCE_RESUME_ID                   = "{\"includes\":[\"resumeId\"]}";

    private static final String[] TALENT_POOL_NEED_FIELDS_ARRAY      = new String[] {
            SearchConstants.RESUME_ID, SearchConstants.BRAND_ID,
            SearchConstants.ACCOUNT_PLACE, SearchConstants.LIVING_PLACE,
            SearchConstants.BIRTHDAY, SearchConstants.WORK_YEARS,
            SearchConstants.POST_TYPE, SearchConstants.POST_NAME,
            SearchConstants.SUBJECT, SearchConstants.EDUCATION,
            SearchConstants.GRADUATE_DATE, SearchConstants.SCHOOL,
            SearchConstants.EMAIL, SearchConstants.GENDER,
            SearchConstants.MOBILE_PHONE, SearchConstants.NAME,
            SearchConstants.NET_CHANNEL_ID, SearchConstants.REASON,
            SearchConstants.RESUME_SOURCE, SearchConstants.PERS_CODE,
            SearchConstants.RESUME_TYPE, SearchConstants.INTO_TALENT_POOL_TIME,
            SearchConstants.CURRENT_INTO_CAND_DATE,
            SearchConstants.INTO_TALENT_POOL_TACHE,
            SearchConstants.TALENTPOOL_TYPE, SearchConstants.UPDATE_DATE,
            SearchConstants.IS_LOCKED, SearchConstants.IS_DISUSE,
            SearchConstants.IS_SENIOR, SearchConstants.IS_BLACKUSER,
            SearchConstants.IS_INNER, SearchConstants.HEAD_HUNTING_ID,
            SearchConstants.HAD_EV_TYPE, SearchConstants.INNER_RECRUIT_TYPE,
            SearchConstants.RECRUIT_TYPE, SearchConstants.OVERALLSCORE,
            SearchConstants.SUITABLE_OR_IMPROPER, SearchConstants.RESUME_OWNER_SHIP
    };

    /***
     * 智能关键字查询start
     *
     * @param key
     *            信息集key
     * @param keyword
     *            关键字
     * @param resumeType
     *            简历类型
     * @param language
     *            简历语言
     * @return
     * @throws Exception
     */
    public List<String> smartQuery(String key,
                                   String keyword,
                                   Integer resumeType,
                                   Integer applyStatus,
                                   Integer applyStatusType,
                                   int language) {

        if (!StringUtils.hasLength(key, true)) {
            return null;
        }
        key = key.toLowerCase();
        JSONObject jsonObject = createQuery(KEYWORD_TYPE_SMART, key, keyword,
                                            applyStatus, applyStatusType,
                                            language);
        if (jsonObject == null) {
            return null;
        }
        return queryResumeIdList(resumeType, jsonObject, KEYWORD_TYPE_SMART);
    }
    // 智能关键字查询end

    /** 候选人 简历全文、上家公司、 目标公司、 目标学校 查询 start */
    public List<String> keyWordQuery(Integer keywordType,
                                     String keyword,
                                     Integer resumeType,
                                     Integer applyStatus,
                                     Integer applyStatusType,
                                     int language)
            throws Exception {

        String field = null;
        // field = "pers_info";
        // keywordType = KEYWORD_TYPE_SMART;

        JSONObject jsonObject = createQuery(keywordType, field, keyword,
                                            applyStatus, applyStatusType,
                                            language);
        if (jsonObject == null) {
            return null;
        }
        return queryResumeIdList(resumeType, jsonObject, null);
    }

    private JSONObject createQuery(Integer keywordType,
                                   String field,
                                   String keyword,
                                   Integer applyStatus,
                                   Integer applyStatusType,
                                   int language) {

        if (!StringUtils.hasLength(keyword, true)) {
            return null;
        }
        keyword = StringUtils.trim(keyword);
        JSONObject jsonObject = new JSONObject();
        Matcher m3 = SENTENCE_PATTERN.matcher(keyword);
        if (m3.find()) { // 精准查询
            int b = m3.start();
            int e = keyword.length();
            if (m3.find()) {
                e = m3.start();
            }
            keyword = keyword.substring(b + 1, e);
            if (StringUtils.hasLength(keyword)) {
                jsonObject = JSON.parseObject("{\"filter\":["
                                              + addQuery(keyword, keywordType,
                                                         field, language)
                                              + "]}");
            } else {
                return null;
            }
        } else {
            // must must_not should
            Matcher matcher = KEYWORD_PATTERN.matcher(keyword);
            String[] array = keyword.split(KEYWORD_PATTERN_REGEX);
            int length = array.length - 1;
            // must except group
            Map<String, List<String>> opMap = new LinkedHashMap<>();
            for (int i = 0; i <= length; i++) {
                String kw = array[i];
                if (StringUtils.hasLength(kw, true)) {
                    String op = KEYWORD_NEED_BOTH_HAVE;
                    if (i != 0 && matcher.find()) {
                        op = matcher.group();
                    }
                    List<String> list = opMap.get(op);
                    if (list == null) {
                        list = new ArrayList<>();
                        opMap.put(op, list);
                    }
                    if (!list.contains(kw)) {
                        list.add(kw);
                    }
                }
            }
            for (Map.Entry<String, List<String>> entry : opMap.entrySet()) {
                List<String> list = entry.getValue();
                if (CollectionUtils.isEmpty(list)) {
                    continue;
                }
                JSONArray jsonArray = new JSONArray();
                for (String kw : list) {
                    // 去重
                    String[] kwArray = kw.split(OR_KEYWORD_PATTERN_REGEX);
                    if (kwArray.length > 1) {
                        List<String> kwList = new ArrayList<String>();
                        JSONObject bool = new JSONObject();
                        JSONArray array1 = new JSONArray();
                        for (String s : kwArray) {
                            if (kwList.contains(s)) {
                                continue;
                            }
                            kwList.add(s);
                            array1.add(addQuery(s, keywordType, field,
                                                language));
                        }
                        bool.put("should", array1);

                        JSONObject bol = new JSONObject();
                        bol.put("bool", bool);
                        jsonArray.add(bol);
                    } else {
                        jsonArray.add(addQuery(kw, keywordType, field,
                                               language));
                    }
                }
                String op = entry.getKey();
                if (KEYWORD_NEED_BOTH_HAVE.equals(op)) {
                    jsonObject.put("filter", jsonArray);
                } else {
                    jsonObject.put("must_not", jsonArray);
                }
            }
        }

        if (jsonObject.size() > 0) {
            JSONObject statusObject = null;
            if (applyStatus != null) {
                JSONObject statusTerm = new JSONObject();
                statusTerm.put("applyStatus", applyStatus);

                statusObject = new JSONObject();
                statusObject.put("term", statusTerm);
            }

            JSONObject statusTypeObject = null;
            if (applyStatusType != null) {
                JSONObject statusTerm = new JSONObject();
                statusTerm.put("applyStatusType", applyStatus);

                statusTypeObject = new JSONObject();
                statusTypeObject.put("term", statusTerm);
            }

            JSONArray filter = null;
            if (jsonObject.getJSONArray(SearchConstants.FILTER) != null) {
                filter = jsonObject.getJSONArray(SearchConstants.FILTER);
            } else {
                filter = new JSONArray();
            }
            if (statusObject != null) {
                filter.add(statusObject);
            }
            if (statusTypeObject != null) {
                filter.add(statusTypeObject);
            }
            if (filter.size() > 0) {
                jsonObject.put(SearchConstants.FILTER, filter);
            }
        }

        return jsonObject;
    }

    private JSONObject addQuery(String kw,
                                Integer keywordType,
                                String key,
                                Integer language) {

        String queryJson = null;
        String lanStr = language == Constants.CHINA_LOCALE ? Constants.CH
                                                           : Constants.EN;
        if (keywordType == KEYWORD_TYPE_RESUME
            || keywordType == KEYWORD_TYPE_SMART) {
            // https://www.elastic.co/guide/en/elasticsearch/reference/current/query-dsl-multi-match-query.html#type-best-fields
//            String field = "detail.*_" + lanStr;
//            if (keywordType == KEYWORD_TYPE_SMART) {
//                field = "detail." + key + "_" + lanStr;
//            }
//            queryJson = "{\"multi_match\":{\"query\":\"" + kw
//                        + "\",\"type\":\"phrase\",\"fields\":\""
//                        + field
//                        + "\"}}";

            if (keywordType == KEYWORD_TYPE_RESUME) {
                lanStr = language == Constants.CHINA_LOCALE ? "Ch" : "En";
                String field1 = "fullText" + lanStr;
                String field2 = "fullTextUpdate" + lanStr;
                queryJson = "{\"bool\":{\"should\":[{\"match_phrase\":{\"" +
                        field1 + "\":\"" + kw + "\"}},{\"match_phrase\":{\"" + field2 + "\":\"" + kw + "\"}}]}}";
            } else {
                String field = "detail." + key + "_" + lanStr;
                queryJson = "{\"nested\":{\"path\":\"detail\",\"query\":{\"match_phrase\":{\"" +
                        field + "\":\"" + kw + "\"}}}}";
            }
        } else {
            String path = null, field = null, otherCond = null;
            if (keywordType == KEYWORD_TYPE_LAST_COMPANY) {
                otherCond = ",{\"match\":{\"workExp.last\":true}}";
                path = "workExp";
                field = "workExp.corpName";
            } else if (keywordType == KEYWORD_TYPE_TARGET_COMPANY) {
                path = "workExp";
                field = "workExp.corpName";
            } else if (keywordType == KEYWORD_TYPE_TARGET_SCHOOL) {
                path = "eduExp";
                field = "eduExp.school";
            }
            if (StringUtils.hasLength(otherCond, true)) {
                otherCond += ",{\"match\":{\"" + path
                             + ".lan\":"
                             + language
                             + "}}";
            } else {
                otherCond = ",{\"match\":{\"" + path
                            + ".lan\":"
                            + language
                            + "}}";
            }
            queryJson = "{\"nested\":{\"path\":\"" + path
                        + "\",\"query\":{\"bool\":{\"must\":[{\"match_phrase\":{\""
                        + field
                        + "\":\""
                        + kw
                        + "\"}}"
                        + otherCond
                        + "]}}}}";
        }
        return JSON.parseObject(queryJson);
    }

    private List<String> queryResumeIdList(Integer resumeType,
                                           JSONObject jsonObject,
                                           Integer queryType) {

        List<String> resumeIdList = new ArrayList<>();

        String idx = resumeType
                .equals(Constants.RESUME_TYPE_APPLY) ? Constants.TYPE_APPLY
                                                     : Constants.TYPE_CAND;
        JSONArray source = new JSONArray();
        source.add("resumeId");

        String scroll_id = null, scrollTime = "1m", content = null;
        Integer size = Constants.BATCH_ES_QUERY_SIZE, page = 1, totalPage = 1;

        String corp = DynamicDataSourceContextHolder.getAlias();
        boolean limit = queryType != null
                        && queryType.equals(KEYWORD_TYPE_SMART)
                        && resumeType.equals(Constants.TYPE_CAND)
                        && ("jahwa".equalsIgnoreCase(corp)
                            || "globalegrow".equalsIgnoreCase(corp)
                            || "CFLD".equalsIgnoreCase(corp)
                            || "Guazi".equalsIgnoreCase(corp)
                            || "risesun".equalsIgnoreCase(corp)
                            || "Hanergy".equalsIgnoreCase(corp)
                            || "cifi".equalsIgnoreCase(corp)
                            || "GoerTek".equalsIgnoreCase(corp)
                            || "minth".equalsIgnoreCase(corp)
                            || "xincheng".equalsIgnoreCase(corp)
                            || "shimaogroup".equalsIgnoreCase(corp));
        if (limit) {
            size = 2900;
        }
        do {
            JSONObject queryCondition = createQueryCondition(jsonObject,
                                                             (page - 1) * size,
                                                             size, source,
                                                             null);
            if (StringUtils.hasLength(scroll_id, true)) {
                // use scroll api for get more data or all data ；defalut query
                // from+size must less than 10000
                content = queryByScrollApi(queryCondition, scroll_id,
                                           scrollTime);
            } else {
                content = query(queryCondition, idx, "scroll=" + scrollTime,
                                false);
            }
            if (!StringUtils.hasLength(content, true)) {
                return resumeIdList;
            }
            JSONObject result = JSONObject.parseObject(content);
            JSONObject hit = JsonUtils.getJSONObject(result, "hits");
            if (hit == null) {
                return resumeIdList;
            }
            scroll_id = JsonUtils.getString(result, "_scroll_id");
            Integer total = JsonUtils.getInteger(hit, "total");
            totalPage = total == null ? 1 : (total + size - 1) / size;
            JSONArray hits = JsonUtils.getJSONArray(hit, "hits");
            if (!CollectionUtils.isEmpty(hits)) {
                Iterator it = hits.iterator();
                while (it.hasNext()) {
                    JSONObject record = (JSONObject) it.next();
                    JSONObject obj = JsonUtils.getJSONObject(record, "_source");
                    String resumeId = JsonUtils.getString(obj, "resumeId");
                    if (StringUtils.hasLength(resumeId, true)
                        && !resumeIdList.contains(resumeId)) {
                        resumeIdList.add(resumeId);
                    }
                }
            } else {
                break;
            }
            if (limit) {
                return resumeIdList;
            }
            page++;
        } while (page <= totalPage);

        return resumeIdList;
    }

    // 候选人关键字查询 end

    // 查询相关简历 start
    // http://pm.dayee.com/issues/24532
    public String checkRelatedResume(String resumeInfoJson, Integer keywordType)
            throws IOException {

        JSONArray must = new JSONArray();
        JSONObject resume = JSON.parseObject(resumeInfoJson);

        boolean isFilter = false;
        // 教育经历
        if (keywordType.equals(KEYWORD_TYPE_RELATED_SCHOOL)) {
            JSONObject eduExp = createNestedQuery(JsonUtils
                    .getJSONArray(resume, "eduExp"), null, "eduExp", false);
            if (eduExp != null) {
                must.add(eduExp);
            } else {
                isFilter = true;
            }
        }

        // 工作经历
        if (keywordType.equals(KEYWORD_TYPE_RELATED_COMPANY)) {
            JSONObject workExp = createNestedQuery(JsonUtils
                    .getJSONArray(resume, "workExp"), null, "workExp", false);
            if (workExp != null) {
                must.add(workExp);
            } else {
                isFilter = true;
            }
        }

        JSONObject mustBool = new JSONObject();
        mustBool.put("must", must);

        String sourceStr = "{\"excludes\": [ \"detail\" ]}";
        JSONObject source = JSONObject.parseObject(sourceStr);

        if (isFilter) {
            String corpCode = DynamicDataSourceContextHolder.getAlias();
            logger.warn("{}\tsend parms {}\n is filter by resume info is not correct",
                         corpCode, mustBool.toString());
            return null;
        } else {
            return query(mustBool, null, null, source, "*", null);
        }
    }
    // 查询相关简历 end

    // TOOD 考虑使用template； 查询疑似重复的简历 start
    // http://pm.dayee.com/issues/23647
    public String checkRepeatResume(String resumeInfoJson) {

        JSONArray must = new JSONArray();
        JSONObject resume = JSON.parseObject(resumeInfoJson);

        JSONObject basicInfo = JsonUtils.getJSONObject(resume, "resumeInfo");
        // 性别
        String gender = JsonUtils.getString(basicInfo, "gender");
        if (StringUtils.hasLength(gender, true)) {
            must.add(createExactQuery1("gender", gender));
        }
        // 出生日期
        Date birthday = JsonUtils.getDate(basicInfo, "birthday");
        if (birthday != null) {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(birthday);
            int year = calendar.get(Calendar.YEAR);

            Date startDate = DateUtils.getDateOfStartYear(year - 2);
            Date endDate = DateUtils.getDateOfEndYear(year + 2);

            // TODO lg -> lge
            must.add(addRangeQuery("birthday", startDate.getTime(),
                                   endDate.getTime()));
            // must.add(JSONObject.parse("{\"range\":{\"birthday\":{\"gte\":"
            // + startDate.getTime()
            // + ",\"lt\":"
            // + endDate.getTime()
            // + "}}}"));
        }
        boolean isFilter = false;
        // 教育经历
        List<String> schools = new ArrayList<>();
        JSONObject eduExp = createNestedQuery(JsonUtils
                .getJSONArray(resume, "eduExp"), schools, "eduExp", true);
        if (eduExp != null) {
            must.add(eduExp);
        } else {
            isFilter = true;
        }

        // 工作经历
        List<String> companys = new ArrayList<>();
        JSONObject workExp = createNestedQuery(JsonUtils
                .getJSONArray(resume, "workExp"), companys, "workExp", true);
        if (workExp != null) {
            must.add(workExp);
        } else {
            isFilter = true;
        }

        JSONObject mustBool = new JSONObject();
        mustBool.put(SearchConstants.MUST, must);

        // "_source": {"excludes": [ "detail.*" ]}
        String sourceStr = "{\"excludes\": [ \"detail\",\"fullTextCh\",\"fullTextEn\",\"fullTextUpdateCh\",\"fullTextUpdateEn\" ]}";
        JSONObject source = JSONObject.parseObject(sourceStr);
        if (isFilter) {
            String corpCode = DynamicDataSourceContextHolder.getAlias();
            logger.warn("{}\tsend parms {}\n is filter by resume info is not correct -> {}",
                         corpCode, mustBool.toString(), resumeInfoJson);
            return null;
        } else {
            String content = query(mustBool, null, null, source, "*", null);
            if (!StringUtils.hasLength(content, true)
                || !ConfigUtils.isCheckRepeatUseLike()) {
                return content;
            }
            JSONObject result = JSONObject.parseObject(content);
            JSONObject hit = JsonUtils.getJSONObject(result, "hits");
            if (hit == null) {
                return content;
            }
            boolean flag = false;
            JSONArray hits = JsonUtils.getJSONArray(hit, "hits");
            Iterator it = hits.iterator();
            while (it.hasNext()) {
                JSONObject record = (JSONObject) it.next();
                JSONObject obj = JsonUtils.getJSONObject(record, "_source");
                boolean schoolMatched = false, compayMatched = false;
                Iterator it1 = null;
                JSONArray array = JsonUtils.getJSONArray(obj, "eduExp");
                if (array != null) {
                    it1 = array.iterator();
                    while (it1.hasNext()) {
                        JSONObject edu = (JSONObject) it1.next();
                        String school = JsonUtils.getString(edu, "school");
                        if (NameUtils.isSameSchool(schools, school)) {
                            schoolMatched = true;
                            break;
                        }
                    }
                }
                array = JsonUtils.getJSONArray(obj, "workExp");
                if (array != null) {
                    it1 = array.iterator();
                    while (it1.hasNext()) {
                        JSONObject work = (JSONObject) it1.next();
                        String company = JsonUtils.getString(work, "corpName");
                        if (NameUtils.isSameCompany(companys, company)) {
                            compayMatched = true;
                            break;
                        }
                    }
                }
                if (schoolMatched && compayMatched) {

                } else {
                    flag = true;
                    it.remove();
                }
            }
            if (!flag) {
                return content;
            }
            hit.put("hits", hits);
            result.put("hits", hit);
            if (logger.isInfoEnabled()) {
                logger.info("{}\tafter filter response {}",
                            DynamicDataSourceContextHolder.getAlias(), result);
            }
            return result.toJSONString();
        }
    }

    private JSONObject createNestedQuery(JSONArray jsonArray,
                                         List<String> names,
                                         String path,
                                         boolean isRepeat) {

        if (jsonArray == null) {
            return null;
        }
        JSONArray workCondArray = new JSONArray();
        Iterator it = jsonArray.iterator();
        while (it.hasNext()) {
            JSONArray condition = new JSONArray();
            JSONObject record = (JSONObject) it.next();

            if ("eduExp".equals(path)) {
                String education = JsonUtils.getString(record, "education");
                String school = JsonUtils.getString(record, "school");
                if (!StringUtils.hasLength(school, true)) {
                    continue;
                }
                if (isRepeat) {
                    if (!StringUtils.hasLength(education, true)) {
                        continue;
                    }
                    condition.add(createExactQuery("eduExp.education",
                                                   education));
                    school = StringUtils.trim(school);
                    if (names != null) {
                        names.add(school);
                    }
                    if (ConfigUtils.isCheckRepeatUseLike()) {
                        school = NameUtils.getSchoolName(school);
                        condition.add(createQuery(SearchConstants.MATCH_PHRASE,
                                                  "eduExp.school", school));
                    } else {
                        condition
                                .add(createExactQuery("eduExp.school", school));
                    }
                } else {
                    condition.add(createExactQuery("eduExp.school", school));
                }
            } else if ("workExp".equals(path)) {
                String corpName = JsonUtils.getString(record, "corpName");
                if (StringUtils.hasLength(corpName, true)) {
                    corpName = StringUtils.trim(corpName);
                    if (names != null) {
                        names.add(corpName);
                    }
                    if (isRepeat && ConfigUtils.isCheckRepeatUseLike()) {
                        corpName = NameUtils.getCompanyName(corpName);
                        condition
                                .add(createQuery(SearchConstants.MATCH_PHRASE,
                                                 "workExp.corpName", corpName));
                    } else {
                        condition.add(createExactQuery("workExp.corpName",
                                                       corpName));
                    }
                } else {
                    continue;
                }
            }

            if (isRepeat) {
                Date date = JsonUtils.getDate(record, "beginDate");
                if (date != null) {
                    Calendar calendar = Calendar.getInstance();
                    calendar.setTime(date);
                    int year = calendar.get(Calendar.YEAR);

                    Date startDate = DateUtils.getDateOfStartYear(year);
                    Date endDate = DateUtils.getDateOfEndYear(year);
                    // TODO lt -> lte
                    condition.add(addRangeQuery(path + ".beginDate",
                                                startDate.getTime(),
                                                endDate.getTime()));
                }
            }

            if (condition.size() > 0) {
                JSONObject must = new JSONObject();
                must.put(SearchConstants.MUST, condition);

                JSONObject bool = new JSONObject();
                bool.put(SearchConstants.BOOL, must);

                workCondArray.add(bool);
            }
        }
        if (workCondArray.size() <= 0) {
            return null;
        }

        JSONObject should = new JSONObject();
        should.put(SearchConstants.SHOULD, workCondArray);

        JSONObject bool = new JSONObject();
        bool.put(SearchConstants.BOOL, should);

        JSONObject nested = new JSONObject();
        nested.put("path", path);
        nested.put("query", bool);

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("nested", nested);

        return jsonObject;
    }

    private JSONObject createExactQuery(String field, String kw) {

        return createExactQuery1(field + "." + SearchConstants.RAW, kw);
    }

    private JSONObject createExactQuery1(String field, String kw) {

        return createQuery(SearchConstants.TERM, field, kw);
    }

    private JSONObject createQuery(String type, String field, String kw) {

        JSONObject jsonObject = new JSONObject();
        jsonObject.put(field, kw);

        JSONObject term = new JSONObject();
        term.put(type, jsonObject);
        // return "{\"term\":{\"" + field + "\":\"" + kw + "\"}}";
        return term;
    }

    // 查询疑似重复的简历 end

    private JSONObject createQueryCondition(JSONObject jsonObject,
                                            Integer from,
                                            Integer size,
                                            Object source,
                                            JSONArray orderArr) {

        JSONObject bool = new JSONObject();
        bool.put("bool", jsonObject);

        JSONObject query = new JSONObject();
        query.put("query", bool);
        query.put("from", from == null ? 0 : from);
        query.put("size", size == null ? Constants.BATCH_ES_QUERY_SIZE : size);

        if (orderArr != null && orderArr.size() > 0) {
            query.put("sort", orderArr);
        }

        if (source != null) {
            query.put("_source", source);
        }
        return query;
    }

    private String query(JSONObject jsonObject,
                         Integer from,
                         Integer size,
                         Object source,
                         String index,
                         String queryString) {

        JSONObject query = createQueryCondition(jsonObject, from, size, source,
                                                null);

        return query(query, index, queryString, false);
    }

    private String query(JSONObject query,
                         String index,
                         String queryString,
                         boolean isQueryResumeInfo) {

        String corpCode = DynamicDataSourceContextHolder.getAlias();
        String indexer = IndexerUtils.getIndexerName(corpCode, index);
        try {
            String requestUri = "/" + indexer + "/resume/_search";
            if (StringUtils.hasLength(queryString, true)) {
                requestUri += "?" + queryString;
            }
            String content = ElasticsearchUtils
                    .sendRestClientRequest(requestUri, HttpPost.METHOD_NAME,
                                           query.toString());
            if (isQueryResumeInfo) {
                logger.info("[{}] send query parms-->{}", corpCode, query);
            } else {
                logger.info("{}\tsend parms {}\n response {}", corpCode, query,
                            content);
            }
            return content;
        } catch (Exception e) {
            logger.error("{}\tsend parms {}\n error {}", corpCode, query,
                         e.getMessage(), e);
        }
        return null;
    }

    /** http://localhost:9200/_search/scroll */
    private String queryByScrollApi(JSONObject queryCondition,
                                    String scroll_id,
                                    String scrollTime) {

        String corpCode = DynamicDataSourceContextHolder.getAlias();
        JSONObject query = new JSONObject();
        query.put("scroll", scrollTime);
        query.put("scroll_id", scroll_id);
        try {
            String requestUri = "/_search/scroll";
            String content = ElasticsearchUtils
                    .sendRestClientRequest(requestUri, HttpPost.METHOD_NAME,
                                           query.toString());
            logger.info("{}\tsend parms {}\nsend scroll parms {}\n response {}",
                        corpCode, queryCondition, query, content);
            return content;
        } catch (Exception e) {
            logger.info("{}\tsend parms {}\nsend scroll parms {}\n error {}",
                        corpCode, queryCondition, query, e.getMessage(), e);
        }
        return null;
    }

    /***
     * 人才库 各条件查询
     *
     * @param condition
     *            查询字段
     * @param language
     *            简历语言
     * @param curPage
     *            页码
     * @param rowSize
     *            每页条数
     * @return
     * @throws Exception
     */
    public JSONObject talentPoolQuery(JSONObject condition,
                                      Integer language,
                                      Integer curPage,
                                      Integer rowSize) {

        long beginTime = System.currentTimeMillis();

        language = language == null ? 1 : language;
        curPage = curPage == null ? 0 : curPage;
        rowSize = rowSize == null ? 0 : rowSize;
        rowSize = rowSize > SearchConstants.MAX_RESUME_ROW_SIZE ? SearchConstants.MAX_RESUME_ROW_SIZE
                                                                : rowSize;

        int from = (curPage - 1) * rowSize;

        if ((from + rowSize) > SearchConstants.INDEX_MAX_RESULT_WINDOW) {
            from = SearchConstants.INDEX_MAX_RESULT_WINDOW - rowSize;
        }

        String source = rowSize > 0 ? SOURCE_TALENT_QUERY_FIELDS
                                    : SOURCE_RESUME_ID;


        JSONObject conditionQuery = createConditionQuery(condition, language);
        if(conditionQuery == null || conditionQuery.size() == 0){
            JSONObject resultObj = new JSONObject();
            resultObj.put("total", 0);
            resultObj.put("pageCount", 0);
            resultObj.put("curPage", 0);
            resultObj.put("resumeList", new JSONArray());
            return resultObj;
        }
        JSONArray orderArr = createOrderCondition(condition);
        JSONObject result = queryResumeInfo(Constants.TYPE_CAND, conditionQuery,
                                            orderArr, source,
                                            TALENT_POOL_NEED_FIELDS_ARRAY,
                                            from, rowSize);
        result.put("curPage", curPage);

        long endTime = System.currentTimeMillis();
        double useTime = endTime - beginTime;
        String threadFlag = condition.getString(SearchConstants.THREAD_FLAG);
        threadFlag = StringUtils
                .hasLength(threadFlag, true) ? threadFlag
                                             : String.valueOf(Thread
                                                     .currentThread().getId());
        logger.info("\n[{}][Thread:{}]---ES查询结束,耗时:{}ms,返回结果数:{}",
                    DynamicDataSourceContextHolder.getAlias(), threadFlag,
                    useTime, result.get("total"));
        if (useTime > 3000) {
            logger.error("\n[{}]---ES查询结束,耗时:{}ms,返回结果数:{}",
                    DynamicDataSourceContextHolder.getAlias(), useTime, result.get("total"));
        } else {
            logger.info("\n[{}]---ES查询结束,耗时:{}ms,返回结果数:{}",
                    DynamicDataSourceContextHolder.getAlias(), useTime, result.get("total"));
        }

        return result;
    }

    /**
     * 查询简历信息
     *
     * @param idx
     *            索引
     * @param conditionQuery
     *            查询语句
     * @param source
     *            需要字段
     * @param needFieldsArr
     *            返回字段数组
     * @param from
     *            查询起始
     * @param rowSize
     *            展示条数
     * @return
     */
    private JSONObject queryResumeInfo(String idx,
                                       JSONObject conditionQuery,
                                       JSONArray orderArr,
                                       String source,
                                       String[] needFieldsArr,
                                       int from,
                                       int rowSize) {

        Integer total, pageCount = 0;

        JSONArray resumeArr = new JSONArray();

        JSONObject query = new JSONObject();
        query.put("query", conditionQuery);
        query.put("from", from);
        query.put("size", rowSize);

        if (orderArr != null && orderArr.size() > 0) {
            query.put("sort", orderArr);
        }

        if (source != null) {
            query.put("_source", JSONObject.parseObject(source));
        }

        String content = query(query, idx, null, true);
        if (!StringUtils.hasLength(content, true)) {
            return null;
        }
        JSONObject result = JSONObject.parseObject(content);

        JSONObject hit = JsonUtils.getJSONObject(result, "hits");
        if (hit == null) {
            return null;
        }

        total = JsonUtils.getInteger(hit, "total");
        total = total == null ? 0 : total;

        if (rowSize != 0) {
            if (total % rowSize == 0) {
                pageCount = total / rowSize;
            } else {
                pageCount = total / rowSize + 1;
            }
        }

        JSONArray hits = JsonUtils.getJSONArray(hit, "hits");
        if (!CollectionUtils.isEmpty(hits)) {
            Set<String> idSet = new HashSet<>();
            Iterator it = hits.iterator();

            while (it.hasNext()) {
                JSONObject record = (JSONObject) it.next();
                JSONObject obj = JsonUtils.getJSONObject(record, "_source");
                String resumeId = JsonUtils
                        .getString(obj, SearchConstants.RESUME_ID);
                JSONObject resumeObj = new JSONObject();
                if (StringUtils.hasLength(resumeId, true)
                    && !idSet.contains(resumeId)) {
                    idSet.add(resumeId);

                    for (String fieldName : needFieldsArr) {
                        Object value = obj.get(fieldName);
                        if (value != null) {
                            resumeObj.put(fieldName, obj.get(fieldName));
                        }
                    }

                    resumeArr.add(resumeObj);
                }
            }
        }

        JSONObject resultObj = new JSONObject();
        resultObj.put("total", total);
        resultObj.put("pageCount", pageCount);
        resultObj.put("resumeList", resumeArr);

        return resultObj;
    }

    /**
     * 创建查询语句
     *
     * @param condition
     * @param language
     * @return
     */
    private JSONObject createConditionQuery(JSONObject condition,
                                            int language) {

        if (condition == null) {
            return null;
        }
        JSONObject boolObj = new JSONObject();
        JSONArray mustArr = new JSONArray();
        JSONArray filterArr = new JSONArray();

        boolean isLookRepeat = condition.getBooleanValue(SearchConstants.IS_LOOK_REPEAT);
        if (isLookRepeat) {
            String repeateResumeIdsStr = condition.getString(SearchConstants.REPEATE_RESUME_IDS_STR);
            if (null == repeateResumeIdsStr || repeateResumeIdsStr.length() == 0) {
                return null;
            } else {
                String[] arr = repeateResumeIdsStr.split(StringUtils.COMMA);
                filterArr.add(addShouldQuery(SearchConstants.RESUME_ID, arr, null,
                        SearchConstants.TERM, language));
                boolObj.put(SearchConstants.FILTER, filterArr);
                JSONObject bool = new JSONObject();
                bool.put(SearchConstants.BOOL, boolObj);
                return bool;
            }
        }

        /**
         * ------filter
         */

        // 是否全库搜索
        boolean isAllSearch = condition.getBooleanValue(SearchConstants.IS_ALL_SEARCH);

        Map<String,String> filterTermMap = new HashMap<>(16);

        // 高级库、内招库、黑名单
        initSearchPurviewQuery(filterTermMap, isAllSearch, condition);

        // 锁定状态
        Integer isLocked = condition.getInteger(SearchConstants.IS_LOCKED_PARAM);
        if (isLocked != null) {
            filterTermMap.put(SearchConstants.IS_LOCKED, isLocked.toString());
        }

        // 联系状态
        String contactState = condition.getString(SearchConstants.CONTACT_STATE);
        if (StringUtils.hasLength(contactState, true)) {
            filterTermMap.put(SearchConstants.CONTACT_STATE, contactState);
        }

        // 招聘类型
        Integer recruitType = condition.getInteger(SearchConstants.RECRUIT_TYPE);
        if (recruitType != null) {
            filterTermMap.put(SearchConstants.RECRUIT_TYPE, recruitType.toString());
        }

        // 性别
        String gender = condition.getString(SearchConstants.GENDER);
        if (StringUtils.hasLength(gender, true)) {
            filterTermMap.put(SearchConstants.GENDER, gender);
        }

        // 是否合适
        String suitableOrImproper = condition
                .getString(SearchConstants.SUITABLE_OR_IMPROPER);
        if (StringUtils.hasLength(suitableOrImproper, true)) {
            filterTermMap.put(SearchConstants.SUITABLE_OR_IMPROPER, suitableOrImproper);
        }

        // 宣讲会
        Integer careerFairId = condition
                .getInteger(SearchConstants.CAREER_FAIRID);
        if (careerFairId != null) {
            filterTermMap.put(SearchConstants.CAREER_FAIRID, careerFairId.toString());
        }

        Integer isHighendTalentPool = condition
                .getInteger(SearchConstants.F_IS_HIGHEND_TALENTPOOL);
        if (isHighendTalentPool != null) {
            if (isHighendTalentPool == -1) {
                mustArr.add(addNotExistsFieldQuery(SearchConstants.F_IS_HIGHEND_TALENTPOOL));
            } else {
                filterTermMap.put(SearchConstants.F_IS_HIGHEND_TALENTPOOL,
                        isHighendTalentPool.toString());
            }
        }

        if(filterTermMap.size() > 0){
            for(String key : filterTermMap.keySet()){
                JSONObject obj = new JSONObject();
                obj.put(key,filterTermMap.get(key));

                JSONObject term = new JSONObject();
                term.put(SearchConstants.TERM,obj);

                filterArr.add(term);
            }
        }

        // 入库时间
        Date intoTalentPoolBeginDate = condition
                .getDate(SearchConstants.INTO_TALENT_POOL_BEGIN_DATE);
        Date intoTalentPoolEndDate = condition
                .getDate(SearchConstants.INTO_TALENT_POOL_ENG_DATE);
        if (intoTalentPoolBeginDate != null || intoTalentPoolEndDate != null) {
            filterArr.add(addDateRangeQuery(SearchConstants.INTO_TALENT_POOL_TIME,
                    intoTalentPoolBeginDate,
                    intoTalentPoolEndDate, true));
        }

        // 最近入库时间
        Date currentIntoCandBeginDate = condition
                .getDate(SearchConstants.CURRENT_INTO_CAND_BEGIN_DATE);
        Date currentIntoCandEndDate = condition
                .getDate(SearchConstants.CURRENT_INTO_CAND_ENG_DATE);
        if (currentIntoCandBeginDate != null || currentIntoCandEndDate != null) {
            filterArr.add(addDateRangeQuery(SearchConstants.CURRENT_INTO_CAND_DATE,
                    currentIntoCandBeginDate,
                    currentIntoCandEndDate, true));
        }

        // 更新时间
        Date updateResumeBeginDate = condition
                .getDate(SearchConstants.UPDATE_RESUME_BEGIN_DATE);
        Date updateResumeEndDate = condition
                .getDate(SearchConstants.UPDATE_RESUME_END_DATE);
        if (updateResumeBeginDate != null || updateResumeEndDate != null) {
            filterArr.add(addDateRangeQuery(SearchConstants.UPDATE_DATE,
                    updateResumeBeginDate,
                    updateResumeEndDate, true));
        }

        // 毕业时间
        Date finalGraduationBeginDate = condition
                .getDate(SearchConstants.FINAL_GRADUATION_BEGIN_DATE);
        Date finalGraduationEndDate = condition
                .getDate(SearchConstants.FINAL_GRADUATION_END_DATE);
        if (finalGraduationBeginDate != null
                || finalGraduationEndDate != null) {
            filterArr.add(addDateRangeQuery(SearchConstants.GRADUATE_DATE,
                    finalGraduationBeginDate,
                    finalGraduationEndDate, true));
        }

        // 本科毕业时间
        Date underGraduationBeginDate = condition
                .getDate(SearchConstants.UNDER_GRADUATION_BEGIN_DATE);
        Date underGraduationEndDate = condition
                .getDate(SearchConstants.UNDERE_GRADUATION_END_DATE);
        if (underGraduationBeginDate != null
                || underGraduationEndDate != null) {
            filterArr.add(addDateRangeQuery(SearchConstants.UNDER_GRADUATE_DATE,
                    underGraduationBeginDate,
                    underGraduationEndDate, true));
        }

        // 简历得分
        BigDecimal minOverAllScore = condition
                .getBigDecimal(SearchConstants.MIN_OVER_ALL_SCORE);
        BigDecimal maxOverAllScore = condition
                .getBigDecimal(SearchConstants.MAX_OVER_ALL_SCORE);
        if (minOverAllScore != null || maxOverAllScore != null) {
            if (minOverAllScore == null) {
                minOverAllScore = new BigDecimal(0);
            }
            if (maxOverAllScore == null) {
                maxOverAllScore = new BigDecimal(100);
            }

            filterArr.add(addRangeQuery(SearchConstants.OVERALLSCORE,
                    minOverAllScore, maxOverAllScore));
        }

        // 年龄
        Integer minAge = condition.getInteger(SearchConstants.MIN_AGE);
        Integer maxAge = condition.getInteger(SearchConstants.MAX_AGE);
        if (minAge != null || maxAge != null) {
            Long minDateMills = null;
            Long maxDateMills = null;
            if (minAge != null) {
                Calendar c = Calendar.getInstance();
                c.add(Calendar.YEAR, -(minAge));
                c.set(Calendar.HOUR_OF_DAY, 0);
                c.set(Calendar.MINUTE, 0);
                c.set(Calendar.SECOND, 0);
                c.set(Calendar.MILLISECOND, 0);
                minDateMills = c.getTimeInMillis();
            }

            if (maxAge != null) {
                maxAge += 1;
                Calendar c = Calendar.getInstance();
                c.add(Calendar.YEAR, -(maxAge));
                c.set(Calendar.HOUR_OF_DAY, 24);
                c.set(Calendar.MINUTE, 0);
                c.set(Calendar.SECOND, 0);
                c.set(Calendar.MILLISECOND, 0);
                maxDateMills = c.getTimeInMillis();
            }

            filterArr.add(addRangeQuery(SearchConstants.BIRTHDAY, maxDateMills,
                                        minDateMills));
        }

        if (filterArr.size() > 0) {
            boolObj.put(SearchConstants.FILTER, filterArr);
        }

        /**
         * ------must
         */

        // 姓名
        String name = condition.getString(SearchConstants.NAME);
        if (StringUtils.hasLength(name, true)) {
            if (language == 1) {
                mustArr.add(addCommonFieldQuery(SearchConstants.NAME, name,
                                                language));
            } else {
                mustArr.add(addCommonFieldQuery(SearchConstants.NAME_EN, name,
                                                language));
            }
        }

        // 简历编号
        String originalId = condition
                .getString(SearchConstants.ORIGINAL_ID_PARAM);
        if (StringUtils.hasLength(originalId, true)) {
            mustArr.add(addCommonFieldQuery(SearchConstants.ORIGINAL_ID,
                                            originalId, language));
        }

        // 职位类别（搜索区域）
        String postType = condition.getString(SearchConstants.POST_TYPE);
        if (StringUtils.hasLength(postType, true)) {
            String[] arr = postType.split(StringUtils.COMMA);
            mustArr.add(addShouldQuery(SearchConstants.POST_TYPE, arr, null,
                                       SearchConstants.MATCH_PHRASE, language));
        }

        // 职位类别（左侧树）
        String talentPoolPostType = condition
                .getString(SearchConstants.TALENT_POOL_POST_TYPE);
        if (StringUtils.hasLength(talentPoolPostType, true)) {
            if (Constants.TALENT_POOL_POST_NO_TYPE_CODE
                    .equals(talentPoolPostType)) {
                List<String> list = (List<String>) condition
                        .get(SearchConstants.TALENT_POST_TYPE);
                if (!CollectionUtils.isEmpty(list)) {
                    mustArr.add(addMustNotQuery(SearchConstants.POST_TYPE, list
                            .toArray(new String[list.size()]), null, language));
                }
            } else {
                String[] arr = talentPoolPostType.split(StringUtils.COMMA);
                mustArr.add(addShouldQuery(SearchConstants.POST_TYPE, arr, null,
                                           SearchConstants.MATCH_PHRASE,
                                           language));
            }
        }

        // 简历类别(左侧树)
        String talentPoolResumeType = condition
                .getString(SearchConstants.TALENT_POOL_RESUME_TYPE);
        if (StringUtils.hasLength(talentPoolResumeType, true)) {
            if ((talentPoolResumeType
                    .contains(Constants.TALENT_POOL_RESUME_NO_TYPE_CODE))) {
                List<String> list = (List<String>) condition
                        .get(SearchConstants.ALL_TALENT_POOL_RESUME_TYPE);
                if (!CollectionUtils.isEmpty(list)) {
                    mustArr.add(addMustNotQuery(SearchConstants.RESUME_TYPE,
                                                list.toArray(new String[list
                                                        .size()]),
                                                null, language));
                }
            } else {
                String[] arr = talentPoolResumeType.split(StringUtils.COMMA);
                mustArr.add(addShouldQuery(SearchConstants.RESUME_TYPE, arr,
                                           null, SearchConstants.MATCH_PHRASE,
                                           language));
            }
        }

        // 简历类别(搜索区)
        String resumeType = condition.getString(SearchConstants.RESUME_TYPE);
        if (StringUtils.hasLength(resumeType, true)) {
            String[] arr = resumeType.split(StringUtils.COMMA);
            mustArr.add(addShouldQuery(SearchConstants.RESUME_TYPE, arr, null,
                                       SearchConstants.MATCH_PHRASE, language));
        }

        // 高级人才库简历类别(搜索区)
        String seniorResumeType = condition
                .getString(SearchConstants.SENIOR_RESUME_TYPE);
        if (StringUtils.hasLength(seniorResumeType, true)) {
            String[] arr = seniorResumeType.split(StringUtils.COMMA);
            Integer keywordType = null;
            for (String type : arr) {
                if ("0/150020/%".equals(type)) {
                    keywordType = FIELD_TYPE_SENIOR_RESUME_TYPE_NULL;
                    break;
                }
            }
            mustArr.add(addShouldQuery(SearchConstants.RESUME_TYPE, arr,
                                       keywordType, null, language));
        }

        // 人才库类别
        String structureId = condition
                .getString(SearchConstants.STRUCTURE_ID_PARAM);
        if (StringUtils.hasLength(structureId, true)) {
            String[] arr = structureId.split(StringUtils.COMMA);
            mustArr.add(addShouldQuery(SearchConstants.STRUCTURE_ID, arr, null,
                                       SearchConstants.MATCH_PHRASE, language));
        }

        // 文件夹
        String folderId = condition.getString(SearchConstants.FOLDER_ID);
        if (StringUtils.hasLength(folderId, true)) {
            if (!folderId.contains(StringUtils.SHORT_LINE)) {
                mustArr.add(addShouldQuery(SearchConstants.FOLDER_ID,
                                           folderId.split(StringUtils.COMMA),
                                           null, SearchConstants.MATCH_PHRASE,
                                           language));
            } else {
                folderId = folderId.replace(StringUtils.SHORT_LINE,
                                            StringUtils.EMPTY);
                String[] arr = folderId.split(StringUtils.COMMA);

                mustArr.add(addMustNotQuery(SearchConstants.FOLDER_ID, arr,
                                            null, language));
            }
        }

        // 机构权限
        JSONArray orgIdList = condition
                .getJSONArray(SearchConstants.ORG_ID_PARAM);
        if (!CollectionUtils.isEmpty(orgIdList)) {
            String[] arr = new String[orgIdList.size()];
            for (int i = 0; i < arr.length; i++) {
                arr[i] = orgIdList.get(i).toString();
            }

            JSONObject tempBool = addShouldQuery(SearchConstants.ORG_ID, arr,
                                                 null,
                                                 SearchConstants.MATCH_PHRASE,
                                                 language);

            String ordIds = condition.getString(SearchConstants.ORG_ID_CHOOSE);
            // 未选中目标机构时，自己是入库操作者，也可以查看
            if (!StringUtils.hasLength(ordIds)) {
                Integer userId = condition.getInteger(SearchConstants.USER_ID);
                if (userId != null && userId != Constants.SUPER_ID) {
                    JSONArray array = tempBool
                            .getJSONObject(SearchConstants.BOOL)
                            .getJSONArray(SearchConstants.SHOULD);
                    array.add(addFieldQuery(SearchConstants.INTO_TALENT_POOL_OPERATER,
                                            userId.toString(), null, null,
                                            language));
                }
            }

            mustArr.add(tempBool);
        }

        // 招聘项目
        String projectIdStr = condition
                .getString(SearchConstants.PROJECT_ID_PARAM);
        if (StringUtils.hasLength(projectIdStr, true)) {
            String[] arr = projectIdStr.trim().split(StringUtils.COMMA);
            mustArr.add(addShouldQuery(SearchConstants.PROJECT_ID, arr, null,
                                       null, language));
        }

        // 职位（勾选）
        String postId = condition.getString(SearchConstants.POST_ID_PARAM);
        if (StringUtils.hasLength(postId, true)) {
            mustArr.add(addShouldQuery(SearchConstants.POST_ID,
                                       postId.split(StringUtils.COMMA), null,
                                       SearchConstants.MATCH_PHRASE, language));
        }

        // 应聘职位（文本）
        String postName = condition.getString(SearchConstants.POST_NAME_PARAM);
        if (StringUtils.hasLength(postName, true)) {
            mustArr.add(addShouldQuery(SearchConstants.POST_NAME,
                                       postName.split(StringUtils.COMMA), null,
                                       null, language));
        }

        // 对外职位名称
        String externalPostName = condition
                .getString(SearchConstants.EXTERNAL_POST_NAME_PARAM);
        if (StringUtils.hasLength(externalPostName, true)) {
            mustArr.add(addShouldQuery(SearchConstants.EXTERNAL_POST_NAME,
                                       externalPostName
                                               .split(StringUtils.COMMA),
                                       null, null, language));
        }

        // 期望工作地点
        String expectWorkPlace = condition
                .getString(SearchConstants.EXPECT_WORK_PLACE);
        if (StringUtils.hasLength(expectWorkPlace, true)) {
            mustArr.add(addShouldQuery(SearchConstants.EXPECT_WORK_PLACE,
                                       expectWorkPlace.split(StringUtils.COMMA),
                                       null, SearchConstants.MATCH_PHRASE,
                                       language));
        }

        // 简历标签三种情况：同时包含/包含其一/不含任一。只能处理t_cand_label_relat表里的标签
        String labelIdStr = condition.getString(SearchConstants.LABEL_ID_PARAM);
        Integer labelQueryType = condition
                .getInteger(SearchConstants.LABEL_QUERY_TYPE);

        if (StringUtils.hasLength(labelIdStr, true) && labelQueryType != null) {
            String[] arr = labelIdStr.split(StringUtils.COMMA);
            if (labelQueryType == 0) {
                // MUST
                mustArr.add(addMustQuery(SearchConstants.LABEL_ID, arr, null,
                                         language));
            } else if (labelQueryType == 1) {
                // SHOULD
                mustArr.add(addShouldQuery(SearchConstants.LABEL_ID, arr, null,
                                           SearchConstants.MATCH_PHRASE,
                                           language));
            } else if (labelQueryType == 2) {
                // MUST_NOT
                mustArr.add(addMustNotQuery(SearchConstants.LABEL_ID, arr, null,
                                            language));
            }
        }

        // 专业
        String subject = condition.getString(SearchConstants.SUBJECT);
        if (StringUtils.hasLength(subject, true)) {
            String[] arr = subject.trim().split(StringUtils.COMMA);
            mustArr.add(addShouldQuery(SearchConstants.SUBJECT, arr, null,
                    SearchConstants.MATCH_PHRASE, language));
        }

        // 学历区间
        String education = condition.getString(SearchConstants.EDUCATION);
        if (StringUtils.hasLength(education, true)) {
            String[] arr = education.trim().split(StringUtils.COMMA);
            mustArr.add(addShouldQuery(SearchConstants.EDUCATION, arr, null,
                                       SearchConstants.MATCH_PHRASE, language));
        }

        // 第一学历 "eg:本科-->eduExp.education=本科,并且eduExp.education!=大专"
        String firstDegree = condition.getString(SearchConstants.FIRST_DEGREE);
        if (StringUtils.hasLength(firstDegree, true)) {
            mustArr.add(addNestedQuery(firstDegree, FIELD_TYPE_FIRST_DEGREE,
                                       language));
        }

        // 第一学历毕业院校 "eg:本科-->符合eduExp.education=本科并且不包含大专的eduExp.school"
        String firstDegreeSchool = condition
                .getString(SearchConstants.FIRST_DEGREE_SCHOOL);
        if (StringUtils.hasLength(firstDegreeSchool, true)) {
            mustArr.add(addNestedQuery(firstDegreeSchool,
                                       FIELD_TYPE_FIRST_SCHOOL, language));
        }

        // 最高学历
        String highestDegree = condition
                .getString(SearchConstants.HIGHEST_DEGREE);
        if (StringUtils.hasLength(highestDegree, true)) {
            mustArr.add(addCommonFieldQuery(SearchConstants.HIGHEST_DEGREE,
                                            highestDegree, language));

            JSONArray shouldArr = new JSONArray();
            shouldArr.add(addCommonFieldQuery(SearchConstants.HIGHEST_DEGREE,
                                              highestDegree, language));
            shouldArr.add(addNestedQuery(highestDegree,
                                         FIELD_TYPE_HIGHTEST_DEGREE, language));

            JSONObject shouldObj = new JSONObject();
            shouldObj.put(SearchConstants.SHOULD, shouldArr);

            JSONObject tempBool = new JSONObject();
            tempBool.put(SearchConstants.BOOL, shouldObj);

            mustArr.add(tempBool);
        }

        // 最高学历毕业院校
        String hightestDegreeSchool = condition
                .getString(SearchConstants.HIGHTEST_DEGREE_SCHOOL);
        if (StringUtils.hasLength(hightestDegreeSchool, true)) {
            mustArr.add(addNestedQuery(hightestDegreeSchool,
                                       FIELD_TYPE_HIGHTEST_SCHOOL, language));
        }

        // 毕业院校
        String graduateSchool = condition.getString(SearchConstants.SCHOOL);
        if (StringUtils.hasLength(graduateSchool, true)) {
            mustArr.add(addShouldQuery(SearchConstants.SCHOOL,
                                       graduateSchool.split(StringUtils.COMMA),
                                       null, SearchConstants.MATCH_PHRASE,
                                       language));
        }

        // 目标学校
        String targetSchool = condition
                .getString(SearchConstants.TARGET_SCHOOL_PARAM);
        if (StringUtils.hasLength(targetSchool, true)) {
            mustArr.add(addFieldQuery(SearchConstants.SCHOOL, targetSchool,
                                      KEYWORD_TYPE_TARGET_SCHOOL, null,
                                      language));
        }

        // 上家公司名
        String lastCorpName = condition
                .getString(SearchConstants.LAST_CORP_NAME);
        if (StringUtils.hasLength(lastCorpName, true)) {
            mustArr.add(addFieldQuery(SearchConstants.CORP_NAME, lastCorpName,
                                      KEYWORD_TYPE_LAST_COMPANY, null,
                                      language));
        }

        // 目标公司
        String targetCompany = condition
                .getString(SearchConstants.TARGET_COMPANY);
        if (StringUtils.hasLength(targetCompany, true)) {
            mustArr.add(addFieldQuery(SearchConstants.CORP_NAME, targetCompany,
                                      KEYWORD_TYPE_TARGET_COMPANY, null,
                                      language));
        }

        // 现居住地
        String livingPlace = condition.getString(SearchConstants.LIVING_PLACE);
        if (StringUtils.hasLength(livingPlace, true)) {
            mustArr.add(addShouldQuery(SearchConstants.LIVING_PLACE,
                                       livingPlace.split(StringUtils.COMMA),
                                       null, SearchConstants.MATCH_PHRASE,
                                       language));
        }

        // 工作年限
        String workYears = condition.getString(SearchConstants.WORK_YEARS);
        if (StringUtils.hasLength(workYears, true)) {
            // 区间
            String[] arr = workYears.trim().split(StringUtils.COMMA);
            mustArr.add(addShouldQuery(SearchConstants.WORK_YEARS, arr, null,
                                       SearchConstants.MATCH_PHRASE, language));
        }

        Integer brandId = condition.getInteger(SearchConstants.BRAND_ID);
        if (brandId != null && brandId == 160002) {
            recruitType = 8;
            brandId = null;
        }

        // 内推类型
        if (recruitType == null
            || recruitType.equals(Constants.RECRUIT_TYPE_INNER_RECOMMEND)) {
            Integer innerRecruitType = condition
                    .getInteger(SearchConstants.INNER_RECRUIT_TYPE_PARAM);
            if (innerRecruitType != null) {
                if (Constants.INNER_RECOMMEND_SOCIAL.equals(innerRecruitType)) {
                    mustArr.add(addCommonFieldQuery(SearchConstants.RECRUIT_TYPE,
                                                    Constants.RECRUIT_TYPE_INNER_RECOMMEND
                                                            .toString(),
                                                    language));

                    JSONArray shouldArr = new JSONArray();
                    shouldArr
                            .add(addNotExistsFieldQuery(SearchConstants.INNER_RECRUIT_TYPE));
                    shouldArr
                            .add(addCommonFieldQuery(SearchConstants.INNER_RECRUIT_TYPE,
                                                     innerRecruitType
                                                             .toString(),
                                                     language));
                    JSONObject shouldObj = new JSONObject();
                    shouldObj.put(SearchConstants.SHOULD, shouldArr);

                    JSONObject tempBool = new JSONObject();
                    tempBool.put(SearchConstants.BOOL, shouldObj);

                    mustArr.add(tempBool);
                } else {
                    mustArr.add(addCommonFieldQuery(SearchConstants.RECRUIT_TYPE,
                                                    Constants.RECRUIT_TYPE_INNER_RECOMMEND
                                                            .toString(),
                                                    language));
                    mustArr.add(addCommonFieldQuery(SearchConstants.INNER_RECRUIT_TYPE,
                                                    innerRecruitType.toString(),
                                                    language));
                }
            }
        }

        // 人员ID
        String persCode = condition.getString(SearchConstants.PERS_CODE_PARAM);
        if (StringUtils.hasLength(persCode, true)) {
            String[] arr = persCode.trim().split(OR_KEYWORD_PATTERN_REGEX);
            mustArr.add(addWildcardQuery(SearchConstants.PERS_CODE, arr, null,
                                         language));
        }

        /**
         * WildcardQuery
         */

        // 员工编号
        String staffNo = condition.getString(SearchConstants.STAFF_NO);
        if (StringUtils.hasLength(staffNo, true)) {
            String[] arr = staffNo.trim().split(StringUtils.COMMA);
            mustArr.add(addWildcardQuery(SearchConstants.STAFF_NO + ".raw", arr,
                                         null, language));
        }

        // 电子邮箱
        String email = condition.getString(SearchConstants.EMAIL);
        if (StringUtils.hasLength(email, true)) {
            mustArr.add(addShouldQuery(SearchConstants.EMAIL,
                                       email.split(StringUtils.COMMA), null,
                                       null, language));
        }

        // 手机号
        String mobilePhone = condition
                .getString(SearchConstants.MOBILE_PHONE_PARAM);
        if (StringUtils.hasLength(mobilePhone, true)) {
            mustArr.add(addWildcardQuery(SearchConstants.MOBILE_PHONE,
                                         mobilePhone.split(OR_KEYWORD_PATTERN_REGEX),
                                         null, language));
        }

        // 手机号（全库搜索）
        mobilePhone = condition.getString(SearchConstants.MOBILE_PHONE);
        if (StringUtils.hasLength(mobilePhone, true)) {
            mustArr.add(addWildcardQuery(SearchConstants.MOBILE_PHONE,
                                         mobilePhone.split(OR_KEYWORD_PATTERN_REGEX),
                                         null, language));
        }

        // 身份证
        String idNum = condition.getString(SearchConstants.ID_NUM_PARAM);
        if (StringUtils.hasLength(idNum, true)) {
            mustArr.add(addWildcardQuery(SearchConstants.ID_NUM,
                                         idNum.split(StringUtils.COMMA), null,
                                         language));
        }

        // 标记人
        String signHotUserIds = condition
                .getString(SearchConstants.SIGN_HOT_USER_PARAM);
        if (StringUtils.hasLength(signHotUserIds, true)) {
            mustArr.add(addShouldQuery(SearchConstants.SIGN_HOT_USER,
                                       signHotUserIds.split(StringUtils.COMMA),
                                       null, null, language));
        }

        // 标记时间
        Date signHotBeginTime = condition
                .getDate(SearchConstants.SIGN_HOT_BEGIN_TIME);
        Date signHotEndTime = condition
                .getDate(SearchConstants.SIGN_HOT_END_TIME);
        if (signHotBeginTime != null || signHotEndTime != null) {
            mustArr.add(addDateRangeQuery(SearchConstants.SIGN_HOT_DATE,
                                          signHotBeginTime, signHotEndTime,
                                          false));
        }

        // 备注
        String remark = condition.getString(SearchConstants.REMARK_PARAM);
        if (StringUtils.hasLength(remark, true)) {
            mustArr.add(addCommonFieldQuery(SearchConstants.REMARK, remark,
                                            language));
        }

        // 发送对象
        String sendTo = condition.getString(SearchConstants.SEND_TO);
        if (StringUtils.hasLength(sendTo, true)) {
            mustArr.add(addShouldQuery(SearchConstants.SEND_TO,
                                       sendTo.split(StringUtils.COMMA), null,
                                       null, language));
        }

        // 站点
        String site = condition.getString(SearchConstants.SITE_PARAM);
        if (StringUtils.hasLength(site, true)) {
            mustArr.add(addShouldQuery(SearchConstants.SITE,
                                       site.split(StringUtils.COMMA), null,
                                       null, language));
        }

        // 外语等级
        String languageLevel = condition
                .getString(SearchConstants.LANGUAGE_LEVEL);
        if (StringUtils.hasLength(languageLevel, true)) {
            mustArr.add(addNestedQuery(languageLevel, FIELD_TYPE_LANGUAGE_LEVEL,
                                       language));
        }

        // 外语听说能力
        String speakingSkills = condition
                .getString(SearchConstants.SPEAKING_SKILLS);
        if (StringUtils.hasLength(speakingSkills, true)) {
            mustArr.add(addNestedQuery(speakingSkills,
                                       FIELD_TYPE_SPEAKING_SKILLS, language));
        }

        // 外语读写能力
        String writeSkills = condition.getString(SearchConstants.WRITE_SKILLS);
        if (StringUtils.hasLength(writeSkills, true)) {
            mustArr.add(addNestedQuery(writeSkills, FIELD_TYPE_WRITING_SKILLS,
                                       language));
        }

        // 简历全文
        String fullText = condition.getString(SearchConstants.FULL_TEXT_PARAM);
        if (StringUtils.hasLength(fullText, true)) {
            mustArr.add(addKeywordQuery(SearchConstants.FULL_TEXT, fullText,
                                        KEYWORD_TYPE_RESUME, language));
        }

        // 智能关键字
        String smart = condition.getString(SearchConstants.KEYWORD_SMART);
        if (StringUtils.hasLength(smart, true)) {
            String smartTableName = condition.getString(SearchConstants.KEYWORD_SMART_TABLE);
            smartTableName = StringUtils.hasLength(smartTableName, true) ?
                                        smartTableName : SearchConstants.FULL_TEXT;
            mustArr.add(addKeywordQuery(smartTableName, smart,
                                        KEYWORD_TYPE_SMART, language));
        }

        JSONObject keywordMap = condition.getJSONObject(SearchConstants.KEYWORD_MAP);
        if (keywordMap != null) {
            // 按目标公司
            String targetCompanyCategory = (String) keywordMap
                    .get(KEYWORD_TYPE_TARGET_COMPANY);
            if (StringUtils.hasLength(targetCompanyCategory, true)
                    && !targetCompanyCategory.equals(targetCompany)) {
                mustArr.add(addKeywordQuery(SearchConstants.CORP_NAME,
                                            targetCompanyCategory,
                                            KEYWORD_TYPE_TARGET_COMPANY,
                                            language));
            }

            // 按简历关键字
            String targetKeywordCategory = (String) keywordMap
                    .get(KEYWORD_TYPE_RESUME);
            if (StringUtils.hasLength(targetKeywordCategory, true)
                    && !targetKeywordCategory.equals(fullText)) {
                mustArr.add(addKeywordQuery(SearchConstants.FULL_TEXT,
                                            targetKeywordCategory,
                                            KEYWORD_TYPE_SMART, language));
            }
        }

        // 入库原因
        String reason = condition.getString(SearchConstants.REASON_PARAM);
        if (StringUtils.hasLength(reason, true)) {
            String[] arr = reason.split(StringUtils.COMMA);
            mustArr.add(addShouldQuery(SearchConstants.REASON, arr, null,
                                       SearchConstants.MATCH_PHRASE, language));
        }

        // 简历来源
        Integer resumeSource = condition
                .getInteger(SearchConstants.RESUME_SOURCE);
        if (resumeSource != null) {
            mustArr.add(addResumeSourceQuery(condition, resumeSource, brandId,
                                             language));
        }

        // 入库环节
        boolean intoTalentPoolTacheuBool = condition
                .getBooleanValue(SearchConstants.INTO_TALENT_POOL_TACHEU_BOOL);
        String talentPoolIntoTalentPoolTache = condition
                .getString(SearchConstants.TALENT_POOL_INTO_TALENT_POOL_TACHE);
        if (intoTalentPoolTacheuBool
                || StringUtils.hasLength(talentPoolIntoTalentPoolTache, true)) {
            JSONObject intoTalentPoolTacheObj = addIntoTalentPoolTacheQuery(condition,
                                                                            language);
            if (intoTalentPoolTacheObj != null) {
                mustArr.add(intoTalentPoolTacheObj);
            }
        }

        // 入库操作者
        String intoTalentPooloperater = condition
                .getString(SearchConstants.INTO_TALENT_POOL_OPERATER_PARAM);
        if (StringUtils.hasLength(intoTalentPooloperater, true)) {
            mustArr.add(addShouldQuery(SearchConstants.INTO_TALENT_POOL_OPERATER,
                                       intoTalentPooloperater
                                               .split(StringUtils.COMMA),
                                       null, null, language));
        }

        // 面试评价
        String interviewEvaluate = condition
                .getString(SearchConstants.INTERVIEW_EVALUATE_PARAM);
        if (StringUtils.hasLength(interviewEvaluate, true)) {
            mustArr.add(addCommonFieldQuery(SearchConstants.INTERVIEW_EVALUATE,
                                            interviewEvaluate, language));
        }

        // 搜狐定制人才库类型（1：人才库 2：精品库 3：回流库）
        Integer talentPoolType = condition
                .getInteger(SearchConstants.TALENTPOOL_TYPE);
        if (talentPoolType != null) {
            String corp = DynamicDataSourceContextHolder.getAlias();
            if (SearchConstants.SOHO.equals(corp)) {
                if (talentPoolType != 1) {
                    mustArr.add(addQuery(recruitType + "", null,
                                         SearchConstants.TALENTPOOL_TYPE,
                                         language));
                } else {
                    String[] arr = { "2", "3" };
                    mustArr.add(addMustNotQuery(SearchConstants.TALENTPOOL_TYPE,
                                                arr, null, language));
                }
            }
        }

        if (mustArr.size() > 0) {
            boolObj.put(SearchConstants.MUST, mustArr);
        }

        JSONObject bool = new JSONObject();
        bool.put(SearchConstants.BOOL, boolObj);
        return bool;
    }

    /**
     * 日期范围
     *
     * @param key
     * @param beginDate
     * @param endDate
     * @param isAddDay
     * @return
     */
    private JSONObject addDateRangeQuery(String key,
                                         Date beginDate,
                                         Date endDate,
                                         boolean isAddDay) {

        Long beginDateMills = null;
        Long endDateMills = null;

        if (beginDate != null) {
            beginDateMills = beginDate.getTime();
        }
        if (endDate != null) {
            endDateMills = endDate.getTime();
            if (isAddDay) {
                endDateMills += 86400000;
            }
        }

        return addRangeQuery(key, beginDateMills, endDateMills);
    }

    /**
     * 范围查询
     *
     * @param key
     * @param rangeFrom
     * @param rangeTo
     * @return
     */
    private JSONObject addRangeQuery(String key,
                                     Object rangeFrom,
                                     Object rangeTo) {

        JSONObject valueObj = new JSONObject();

        if (rangeFrom != null) {
            valueObj.put(SearchConstants.GTE, rangeFrom);
        }

        if (rangeTo != null) {
            valueObj.put(SearchConstants.LTE, rangeTo);
        }

        JSONObject rangeObj = new JSONObject();
        rangeObj.put(key, valueObj);

        JSONObject range = new JSONObject();
        range.put(SearchConstants.RANGER, rangeObj);

        return range;
    }

    /**
     * 存在多值的查询
     *
     * @param key
     * @param arr
     * @param keywordType
     * @param matchType
     * @param language
     * @return
     */
    private JSONObject addShouldQuery(String key,
                                      String[] arr,
                                      Integer keywordType,
                                      String matchType,
                                      int language) {

        return addMultiValuesQuery(key, arr, keywordType,
                                   SearchConstants.SHOULD, matchType, language);
    }

    /**
     * 模糊查询 eg:name=%abc%
     *
     * @param key
     * @param arr
     * @param keywordType
     * @param language
     * @return
     */
    private JSONObject addWildcardQuery(String key,
                                        String[] arr,
                                        Integer keywordType,
                                        Integer language) {

        return addMultiValuesQuery(key, arr, keywordType,
                                   SearchConstants.SHOULD,
                                   SearchConstants.WILDCARD, language);
    }

    /**
     * 字段值后缀模糊查询 eg:name=abc或者abc_*，下划线区分，防止搜到abcd
     *
     * @param key
     * @param value
     * @param language
     * @return
     */
    private JSONObject addSuffixFuzzyQuery(String key,
                                           String value,
                                           Integer language) {

        JSONObject bool = new JSONObject();
        JSONObject shouldObj = new JSONObject();

        JSONArray shouldArr = new JSONArray();
        shouldArr.add(addCommonFieldQuery(key, value, language));
        value = value + StringUtils.UNDERLINE + StringUtils.ASTERISK;
        shouldArr.add(addFieldQuery(key, value, null, SearchConstants.WILDCARD,
                                    language));
        shouldObj.put(SearchConstants.SHOULD, shouldArr);
        bool.put(SearchConstants.BOOL, shouldObj);

        return bool;
    }

    private JSONObject addMustQuery(String key,
                                    String[] arr,
                                    Integer keywordType,
                                    int language) {

        return addMultiValuesQuery(key, arr, keywordType, SearchConstants.MUST,
                                   null, language);
    }

    private JSONObject addMustNotQuery(String key,
                                       String[] arr,
                                       Integer keywordType,
                                       int language) {

        return addMultiValuesQuery(key, arr, keywordType,
                                   SearchConstants.MUST_NOT, null, language);
    }

    private JSONObject addNotExistsFieldQuery(String key) {

        String queryJson = "{\"bool\":{\"must_not\":[{\"exists\":{\"field\":\""
                           + key
                           + "\"}}]}}";
        return JSONObject.parseObject(queryJson);
    }

    /**
     * 创建包含多个值限定关系的字段查询
     *
     * @param key         es中对应的字段
     * @param arr         字段值数组
     * @param keywordType 字段类型
     * @param op          逻辑关系，must/must_not/should
     * @param keywordType 匹配类型，match_phrase/wildcard/range
     * @param language    环境
     * @return
     */
    private JSONObject addMultiValuesQuery(String key,
                                           String[] arr,
                                           Integer keywordType,
                                           String op,
                                           String matchType,
                                           int language) {

        JSONObject jsonObject = new JSONObject();

        JSONObject bool = new JSONObject();
        JSONArray array = new JSONArray();
        if (arr.length > 1) {
            List<String> kwList = new ArrayList<>();
            for (String kw : arr) {
                kw = kw.trim();
                if (kwList.contains(kw)) {
                    // 去重
                    continue;
                }
                kwList.add(kw);
                if (SearchConstants.WILDCARD.equals(matchType)) {
                    kw = StringUtils.ASTERISK + kw + StringUtils.ASTERISK;
                }
                array.add(addFieldQuery(key, kw, keywordType, matchType,
                                        language));
            }

            if (keywordType != null
                && keywordType == FIELD_TYPE_SENIOR_RESUME_TYPE_NULL) {
                array.add(addNotExistsFieldQuery(key));
            }
            bool.put(op, array);
            jsonObject.put(SearchConstants.BOOL, bool);
        } else {
            arr[0] = arr[0].trim();
            if (SearchConstants.WILDCARD.equals(matchType)) {
                arr[0] = StringUtils.ASTERISK + arr[0] + StringUtils.ASTERISK;
            }

            array.add(addFieldQuery(key, arr[0], keywordType, matchType,
                                    language));
            bool.put(op, array);
            jsonObject.put(SearchConstants.BOOL, bool);
        }

        return jsonObject;
    }

    private JSONObject addCommonFieldQuery(String key,
                                           String value,
                                           int language) {

        return addFieldQuery(key, value, null, null, language);
    }

    /**
     * 字段查询
     *
     * @param key         es中对应的字段
     * @param value       字段值
     * @param keywordType 字段类型
     * @param matchType   匹配类型，match_phrase/wildcard/range
     * @param language
     * @return
     */
    private JSONObject addFieldQuery(String key,
                                     String value,
                                     Integer keywordType,
                                     String matchType,
                                     int language) {

        value = value.trim();
        String queryJson;
        matchType = matchType == null ? SearchConstants.MATCH_PHRASE
                                      : matchType;
        if (keywordType == null) {
            queryJson = "{\"" + matchType
                        + "\": {\""
                        + key
                        + "\": \""
                        + value
                        + "\"}}";
        } else if (keywordType == KEYWORD_TYPE_RESUME
                   || keywordType == KEYWORD_TYPE_SMART) {
            String lanStr = language == Constants.CHINA_LOCALE ? "Ch"
                                                               : "En";
            String field1 = key + lanStr;
            String field2 = key + "Update" + lanStr;

//            queryJson = "{\"multi_match\":{\"query\":\"" + value
//                        + "\",\"type\":\"phrase\",\"fields\":\""
//                        + field
//                        + "\"}}";
            queryJson = "{\"bool\":{\"should\":[{\"match_phrase\":{\"" +
                    field1 + "\":\"" + value + "\"}},{\"match_phrase\":{\"" + field2 + "\":\"" + value + "\"}}]}}";
        } else {
            return addNestedQuery(value, keywordType, language);
        }

        try {
            return JSON.parseObject(queryJson);
        } catch (Exception e) {
            logger.error("[]解析json失败：-->{}",
                    DynamicDataSourceContextHolder.getAlias(), queryJson, e);
            throw e;
        }

//        return JSON.parseObject(queryJson);
    }

    /**
     * 嵌套查询
     *
     * @param value
     * @param keywordType
     * @param language
     * @return
     */
    private JSONObject addNestedQuery(String value,
                                      Integer keywordType,
                                      int language) {

        value = value.trim();
        String path = null, field = null, otherCond = null, queryJson;

        if (keywordType == KEYWORD_TYPE_LAST_COMPANY) {
            otherCond = ",{\"match\":{\"workExp.last\":true}}";
            path = "workExp";
            field = "workExp.corpName";
        } else if (keywordType == KEYWORD_TYPE_TARGET_COMPANY) {
            path = "workExp";
            field = "workExp.corpName";
        } else if (keywordType == KEYWORD_TYPE_TARGET_SCHOOL) {
            path = "eduExp";
            field = "eduExp.school";
        } else if (keywordType == FIELD_TYPE_FIRST_DEGREE) {
            otherCond = ",{\"match\":{\"eduExp.first\":true}}";
            path = "eduExp";
            field = "eduExp.education";
        } else if (keywordType == FIELD_TYPE_FIRST_SCHOOL) {
            otherCond = ",{\"match\":{\"eduExp.first\":true}}";
            path = "eduExp";
            field = "eduExp.school.raw";
        } else if (keywordType == FIELD_TYPE_HIGHTEST_DEGREE) {
            otherCond = ",{\"match\":{\"eduExp.highest\":true}}";
            path = "eduExp";
            field = "eduExp.education";
        } else if (keywordType == FIELD_TYPE_HIGHTEST_SCHOOL) {
            otherCond = ",{\"match\":{\"eduExp.highest\":true}}";
            path = "eduExp";
            field = "eduExp.school.raw";
        } else if (keywordType == FIELD_TYPE_LANGUAGE_LEVEL) {
            path = "langAbil";
            field = "langAbil.languageLevel";
        } else if (keywordType == FIELD_TYPE_SPEAKING_SKILLS) {
            path = "langAbil";
            field = "langAbil.speakingAbility";
        } else if (keywordType == FIELD_TYPE_WRITING_SKILLS) {
            path = "langAbil";
            field = "langAbil.writeSkills";
        }

        if (StringUtils.hasLength(otherCond, true)) {
            otherCond += ",{\"match\":{\"" + path + ".lan\":" + language + "}}";
        } else {
            otherCond = ",{\"match\":{\"" + path + ".lan\":" + language + "}}";
        }

        if (value.contains(StringUtils.COMMA)) {
            queryJson = "{\"nested\":{\"path\":\"" + path
                        + "\",\"query\":{\"bool\":{\"must\":[{ \"bool\" : { \"should\" : [";
            String[] arr = value.split(StringUtils.COMMA);
            for (String str : arr) {
                if (str.contains(StringUtils.UNDERLINE)
                    && (keywordType == FIELD_TYPE_SPEAKING_SKILLS
                        || keywordType == FIELD_TYPE_WRITING_SKILLS)) {
                    String[] arr2 = value.split(StringUtils.UNDERLINE);
                    queryJson += "{\"match_phrase\":{\"languageType\":\""
                                 + arr2[0]
                                 + "\"},";
                    queryJson += "{\"match_phrase\":{\"" + field
                                 + "\":\""
                                 + arr2[1]
                                 + "\"}}";
                } else {
                    queryJson += "{\"match_phrase\":{\"" + field
                                 + "\":\""
                                 + str
                                 + "\"}}";
                }
            }

            queryJson += "]}}" + otherCond + "]}}}}";
        } else {
            queryJson = "{\"nested\":{\"path\":\"" + path
                        + "\",\"query\":{\"bool\":{\"must\":[{\"match_phrase\":{\""
                        + field
                        + "\":\""
                        + value
                        + "\"}}"
                        + otherCond
                        + "]}}}}";
        }

        return JSONObject.parseObject(queryJson);
    }

    /**
     * 企业人才库、高级人才库、内招库、淘汰库、黑名单
     *
     * @param filterTermMap
     * @param isAllSearch
     * @param condition
     */
    private void initSearchPurviewQuery(Map<String, String> filterTermMap,
                                        boolean isAllSearch,
                                        JSONObject condition) {

        if (isAllSearch) {
            // 高级人才库
            Integer isSeniorPurview = condition
                    .getInteger(SearchConstants.IS_SENIOR_TALENT_POOL_PURVIEW);
            if (isSeniorPurview != null
                && isSeniorPurview.equals(Constants.YES)) {
                Integer isCorpTalentPurview = condition
                        .getInteger(SearchConstants.IS_CORP_TALENT_PURVIEW);
                // 全库搜索，有高级库权限，没有企业库权限，则限制为高级库
                if (isCorpTalentPurview == null
                    || isCorpTalentPurview.equals(Constants.NO)) {
                    filterTermMap.put(SearchConstants.IS_SENIOR,
                                      SearchConstants.YES);
                }
            } else {
                if (!condition
                        .getBooleanValue(SearchConstants.IS_SMART_RECOMMEND_RESUME_PAGE)) {
                    filterTermMap.put(SearchConstants.IS_SENIOR,
                                      SearchConstants.NO);
                }
            }

            // 内招人才库
            Integer isInner = condition.getInteger(SearchConstants.IS_INNER);
            if (null != isInner) {
                filterTermMap.put(SearchConstants.IS_INNER,
                                  String.valueOf(isInner));
            }
        } else {
            if (!condition.getBooleanValue(SearchConstants.IS_FROM_STRUCTURE)) {
                // 是否高级人才库
                Integer isSenior = condition
                        .getInteger(SearchConstants.IS_SENIOR);
                if (null != isSenior && isSenior.equals(Constants.YES)) {
                    filterTermMap.put(SearchConstants.IS_SENIOR,
                                      SearchConstants.YES);
                } else {
                    if (!condition
                            .getBooleanValue(SearchConstants.IS_SMART_RECOMMEND_RESUME_PAGE)) {
                        filterTermMap.put(SearchConstants.IS_SENIOR,
                                          SearchConstants.NO);
                    }
                }

                // 是否内招人才库
                Integer isInner = condition
                        .getInteger(SearchConstants.IS_INNER);
                if (null != isInner && isInner.equals(Constants.YES)) {
                    filterTermMap.put(SearchConstants.IS_INNER,SearchConstants.YES);
                } else {
                    if (!condition
                            .getBooleanValue(SearchConstants.IS_SMART_RECOMMEND_RESUME_PAGE)) {
                        filterTermMap.put(SearchConstants.IS_INNER,SearchConstants.NO);
                    }
                }
            }
        }

        // 淘汰库
        boolean isDisuse = condition.getBooleanValue(SearchConstants.IS_DISUSE);
        String isDisuseStr = isDisuse ? SearchConstants.YES
                                      : SearchConstants.NO;
        if (!isAllSearch) {
            filterTermMap.put(SearchConstants.IS_DISUSE, isDisuseStr);
//            filterTermMap.put(SearchConstants.IS_BLACKUSER, SearchConstants.NO);
        }

        // 展示历史
        String corpCode = DynamicDataSourceContextHolder.getAlias();
        if (SearchConstants.MIDEA.equals(corpCode)) {
            filterTermMap.put(SearchConstants.SHOWLIST, SearchConstants.YES);
        }

        Integer userId = condition.getInteger(SearchConstants.USER_ID);
        if (userId != null && userId != Constants.SUPER_ID) {
            // 人才库展示
            filterTermMap.put(SearchConstants.F_SHOW_IN_TALENTPOOL,
                              SearchConstants.YES);
        }
    }

    /**
     * 入库环节
     *
     * @param condition
     * @param language
     * @return
     */
    private JSONObject addIntoTalentPoolTacheQuery(JSONObject condition,
                                                   int language) {

        JSONArray tacheArr = null;
        List<List<String>> intoTalentPoolTacheList = null;
        List<String> hadEvTypeList = null;
        boolean isMustNot = false;
        boolean isApplyTalentPool = false;

        String intoTalentPoolTache = condition
                .getString(SearchConstants.INTO_TALENT_POOL_TACHE);
        String talentPoolIntoTalentPoolTache = condition
                .getString(SearchConstants.TALENT_POOL_INTO_TALENT_POOL_TACHE);
        if (!StringUtils.hasLength(intoTalentPoolTache)) {
            intoTalentPoolTache = condition
                    .getString(SearchConstants.TALENT_POOL_INTO_TALENT_POOL_TACHE);
            if (StringUtils.hasLength(intoTalentPoolTache)) {
                if (intoTalentPoolTache.equals("0,1")) {
                    isApplyTalentPool = true;
                }
                if(intoTalentPoolTache.contains(StringUtils.SHORT_LINE)){
                    intoTalentPoolTache = intoTalentPoolTache.replaceAll(
                            StringUtils.SHORT_LINE, StringUtils.EMPTY);
                    isMustNot = true;
                }
            }
        } else if (StringUtils.hasLength(talentPoolIntoTalentPoolTache)) {
            String[] tacheArray1 = intoTalentPoolTache.split(StringUtils.COMMA);
            String[] tacheArray2 = talentPoolIntoTalentPoolTache.split(StringUtils.COMMA);

            Set<String> set1 = new HashSet<>(Arrays.asList(tacheArray1));
            Set<String> set2 = new HashSet<>(Arrays.asList(tacheArray2));

            set2.retainAll(set1);

            if (set2.size() == 0) {
                intoTalentPoolTache = SearchConstants.INTO_TALENT_POOL_TACHE_STORE;
            } else {
                intoTalentPoolTache = StringUtils.collectionToDelimitedString(set2,
                        StringUtils.COMMA);
            }
        }

        String hadEvType = condition.getString(SearchConstants.HAD_EV_TYPE);
        if (StringUtils.hasLength(intoTalentPoolTache)) {
            intoTalentPoolTacheList = new ArrayList();

            // 除面试环节以外的筛选代码集合
            List<String> tacheList = new ArrayList<>();
            // 面试环节相关的筛选代码集合
            List<String> interviewTacheList = new ArrayList<>();

            String[] tacheArray = intoTalentPoolTache.split(StringUtils.COMMA);
            for (String tache : tacheArray) {
                if (StringUtils.hasLength(tache)) {
                    if (tache.contains(StringUtils.DIAGONAL)) {
                        if (!interviewTacheList
                                .contains(Constants.APPLY_STATUS_UNEVALUATED
                                        .toString())) {
                            interviewTacheList
                                    .add(Constants.APPLY_STATUS_UNEVALUATED
                                            .toString());
                        }

                        if (hadEvTypeList == null) {
                            hadEvTypeList = new ArrayList<>();
                        }
                        hadEvTypeList.add(tache);
                        hadEvType += tache + StringUtils.COMMA;
                    } else {
                        tacheList.add(tache);
                    }
                }
            }
            if (tacheList.contains(Constants.APPLY_STATUS_EVALUATED.toString())
                    || StringUtils.hasLength(hadEvType)) {
                interviewTacheList
                        .add(Constants.APPLY_STATUS_UNSCHEDULED.toString());
            }

            intoTalentPoolTacheList.add(tacheList);
            intoTalentPoolTacheList.add(interviewTacheList);
        }

        List<String> tacheList1 = null;
        List<String> tacheList2 = null;
        if (!CollectionUtils.isEmpty(intoTalentPoolTacheList)) {
            // 包含非面试相关的入库环节
            tacheList1 = intoTalentPoolTacheList.get(0);
            // 包含面试相关的入库环节（7、9）
            tacheList2 = intoTalentPoolTacheList.get(1);

            if (!CollectionUtils.isEmpty(tacheList1)) {
                String[] arr = tacheList1.toArray(new String[tacheList1.size()]);
                JSONObject noEvTypeTacheObj = null;
                if (!isMustNot) {
                    noEvTypeTacheObj = addShouldQuery(SearchConstants.INTO_TALENT_POOL_TACHE,
                            arr, null,
                            SearchConstants.MATCH_PHRASE,
                            language);
                } else {
                    noEvTypeTacheObj = addMustNotQuery(SearchConstants.INTO_TALENT_POOL_TACHE,
                            arr, null, language);
                    JSONObject obj = addNotExistsFieldQuery(SearchConstants.INTO_TALENT_POOL_TACHE);
                    noEvTypeTacheObj.getJSONObject(SearchConstants.BOOL)
                            .getJSONArray(SearchConstants.MUST_NOT).add(obj);
                }

                if (isApplyTalentPool) {
                    JSONObject obj = addNotExistsFieldQuery(SearchConstants.INTO_TALENT_POOL_TACHE);
                    noEvTypeTacheObj.getJSONObject(SearchConstants.BOOL)
                            .getJSONArray(SearchConstants.SHOULD).add(obj);
                }

                tacheArr = new JSONArray();
                tacheArr.add(noEvTypeTacheObj);
            }
        }

        /**
         * 自定义的面试类型（初试、复试、终面等）
         */
        if (!CollectionUtils.isEmpty(hadEvTypeList)
            && !CollectionUtils.isEmpty(tacheList2)) {
            String[] arr = hadEvTypeList.toArray(new String[hadEvTypeList.size()]);
            JSONObject evTypeObj = addShouldQuery(SearchConstants.HAD_EV_TYPE,
                                                  arr, null,
                                                  SearchConstants.MATCH_PHRASE,
                                                  language);

            String[] arr2 = tacheList2.toArray(new String[tacheList2.size()]);
            JSONObject tache2Obj = addShouldQuery(SearchConstants.INTO_TALENT_POOL_TACHE,
                                                  arr2, null,
                                                  SearchConstants.MATCH_PHRASE,
                                                  language);

            JSONArray evTypeTacheArr = new JSONArray();
            evTypeTacheArr.add(evTypeObj);
            evTypeTacheArr.add(tache2Obj);

            JSONObject must = new JSONObject();
            must.put(SearchConstants.MUST, evTypeTacheArr);
            JSONObject bool = new JSONObject();
            bool.put(SearchConstants.BOOL, must);

            if (tacheArr == null) {
                tacheArr = new JSONArray();
            }
            tacheArr.add(bool);
        }

        JSONObject bool = null;
        if (tacheArr != null) {
            JSONObject should = new JSONObject();
            should.put(SearchConstants.SHOULD, tacheArr);

            bool = new JSONObject();
            bool.put(SearchConstants.BOOL, should);
        }

        return bool;
    }

    /**
     * 关键字
     *
     * @param field
     * @param keyword
     * @param keywordType
     * @param language
     * @return
     */
    private JSONObject addKeywordQuery(String field,
                                       String keyword,
                                       Integer keywordType,
                                       int language) {

        JSONObject result = new JSONObject();

        keyword = StringUtils.trim(keyword);

        Matcher m3 = SENTENCE_PATTERN.matcher(keyword);
        if (m3.find()) {
            /**
             * 双引号，精准查询
             */
            int b = m3.start();
            int e = keyword.length();
            if (m3.find()) {
                e = m3.start();
            }
            keyword = keyword.substring(b + 1, e);
            if (StringUtils.hasLength(keyword)) {
                JSONObject jsonObject = addFieldQuery(field, keyword,
                                                      keywordType, null,
                                                      language);
                JSONObject bool = new JSONObject();
                bool.put(SearchConstants.SHOULD, jsonObject);
                result.put(SearchConstants.BOOL, bool);
            }
        } else {
            // must must_not should 张三,李四+王五-赵六
            String[] orArray = keyword.split(OR_KEYWORD_PATTERN_REGEX);
            JSONArray shouldArr = new JSONArray();

            for (int i = 0; i < orArray.length; i++) {
                String subKeyword = orArray[i];

                Matcher matcher = KEYWORD_PATTERN.matcher(subKeyword);
                String[] array = subKeyword.split(KEYWORD_PATTERN_REGEX);

                Map<String, Set<String>> opMap = new LinkedHashMap<>();
                for (int j = 0; j < array.length; j++) {
                    String kw = array[j];
                    if (!StringUtils.hasLength(kw, true)) {
                        continue;
                    }

                    String op = KEYWORD_NEED_BOTH_HAVE;
                    if (j != 0 && matcher.find()) {
                        op = matcher.group();
                    }
                    Set<String> set = opMap.get(op);
                    if (set == null) {
                        set = new HashSet<>();
                        opMap.put(op, set);
                    }
                    set.add(kw);
                }

                JSONObject subBool = new JSONObject();
                JSONObject opObj = new JSONObject();
                for (Map.Entry<String, Set<String>> entry : opMap.entrySet()) {
                    Set<String> set = entry.getValue();
                    String type = KEYWORD_NEED_BOTH_HAVE
                            .equals(entry.getKey()) ? SearchConstants.MUST
                                                    : SearchConstants.MUST_NOT;
                    JSONArray jsonArray = new JSONArray();
                    for (String kw : set) {
                        jsonArray.add(addFieldQuery(field, kw, keywordType,
                                                    null, language));
                    }

                    opObj.put(type, jsonArray);
                }

                subBool.put(SearchConstants.BOOL, opObj);
                shouldArr.add(subBool);
            }
            JSONObject bool = new JSONObject();
            bool.put(SearchConstants.SHOULD, shouldArr);
            result.put(SearchConstants.BOOL, bool);
        }

        return result;
    }

    /**
     * 简历来源
     *
     * @param condition
     * @param resumeSource
     * @param brandId
     * @param language
     * @return
     */
    private JSONObject addResumeSourceQuery(JSONObject condition,
                                            Integer resumeSource,
                                            Integer brandId,
                                            int language) {

        // 网络渠道
        String netChannelId = condition
                .getString(SearchConstants.NET_CHANNEL_ID);

        String sourceChannel = resumeSource.toString();

        if (resumeSource == ChannelType.INNER_EXTERNAL_RECOMMEND) {
            // 内外推：15,16,20,25,34
            sourceChannel = "15,16,20,25,34";
            return addShouldQuery(SearchConstants.SOURCE_CHANNEL,
                                  sourceChannel.split(StringUtils.COMMA), null,
                                  null, language);
        } else if (resumeSource == ChannelType.AGENT) {
            // 中介
            Integer huntingId = condition
                    .getInteger(SearchConstants.HEAD_HUNTING_ID);
            if (huntingId != null) {
                sourceChannel += StringUtils.UNDERLINE + huntingId;
                return addCommonFieldQuery(SearchConstants.SOURCE_CHANNEL,
                                           sourceChannel, language);
            } else {
                return addSuffixFuzzyQuery(SearchConstants.SOURCE_CHANNEL,
                                           sourceChannel, language);
            }
        } else if (resumeSource == ChannelType.WEB) {
            // 前台品牌
            if (netChannelId != null && brandId != null) {
                return addCommonFieldQuery(SearchConstants.SOURCE_CHANNEL,
                                           sourceChannel, language);
            } else {
                if (netChannelId != null) {
                    sourceChannel += StringUtils.UNDERLINE + netChannelId;
                }

                if (brandId != null) {
                    sourceChannel += StringUtils.UNDERLINE + brandId;
                }

                return addSuffixFuzzyQuery(SearchConstants.SOURCE_CHANNEL,
                                           sourceChannel, language);
            }
        } else if (resumeSource == ChannelType.INNER_RECOMMEND) {
            // 内部推荐PC端
            if (netChannelId != null) {
                sourceChannel += StringUtils.UNDERLINE + netChannelId;
                return addCommonFieldQuery(SearchConstants.SOURCE_CHANNEL,
                                           sourceChannel, language);
            } else {
                return addSuffixFuzzyQuery(SearchConstants.SOURCE_CHANNEL,
                                           sourceChannel, language);
            }

        } else {
            if (netChannelId != null) {
                List<Integer> channelList = (List<Integer>) condition
                        .get(SearchConstants.NET_CHANEL_LIST);
                if (channelList != null) {
                    String[] channelArr = new String[channelList.size()];
                    for (int i = 0; i < channelList.size(); i++) {
                        channelArr[i] = sourceChannel + StringUtils.UNDERLINE
                                        + channelArr[i];
                    }
                    return addShouldQuery(SearchConstants.SOURCE_CHANNEL,
                                          channelArr, null, null, language);
                } else {
                    if (!"160001".equals(netChannelId)) {
                        sourceChannel += StringUtils.UNDERLINE + netChannelId;
                    }
                    return addShouldQuery(SearchConstants.SOURCE_CHANNEL,
                                          sourceChannel
                                                  .split(StringUtils.COMMA),
                                          null, null, language);
                }
            } else {
                return addSuffixFuzzyQuery(SearchConstants.SOURCE_CHANNEL,
                                           sourceChannel, language);
            }
        }
    }

    /**
     * 排序
     *
     * @param condition
     * @return
     */
    private JSONArray createOrderCondition(JSONObject condition) {

        String orderByStr = condition.getString(SearchConstants.ORDER);

        if (orderByStr != null
            && orderByStr.indexOf(SearchConstants.INTERVIEW_TYPE) > -1) {
            StringBuilder orderBuffer = new StringBuilder();
            String[] orderArr = orderByStr.split(StringUtils.SEMICOLON);
            int interviewIndex = 0;
            for (int ii = 0; ii < orderArr.length; ii++) {
                String order = orderArr[ii];
                if (StringUtils.hasLength(order)) {
                    String orderNum = order.substring(0, order.indexOf("_"));
                    int curOrder = Integer.parseInt(orderNum);
                    String asc = order.substring(order.lastIndexOf("_") + 1);
                    String property = order.substring(order.indexOf("_") + 1,
                                                      order.lastIndexOf("_"));
                    if (order.indexOf(SearchConstants.INTERVIEW_TYPE) > -1) {
                        interviewIndex = ii;
                        String orderStr = order + StringUtils.SEMICOLON
                                          + (curOrder + 1)
                                          + SearchConstants.EVALUATE_STATUS
                                          + asc;
                        orderBuffer.append(orderStr);
                    } else {
                        if (interviewIndex != 0 && interviewIndex < ii) {
                            orderBuffer.append((curOrder + 1) + property + asc);
                        } else {
                            orderBuffer.append(order);
                        }
                    }
                }
                orderBuffer.append(StringUtils.SEMICOLON);
            }
            orderByStr = orderBuffer.toString();
        }

        JSONArray sortArr = new JSONArray();
        Set<String> sortSet = new HashSet<>();

        if (!StringUtils.isEmpty(orderByStr)) {
            String[] orderArr = orderByStr.split(StringUtils.SEMICOLON);
            for (String orderStr : orderArr) {
                if (!StringUtils.hasLength(orderStr, true)) {
                    continue;
                }
                String[] tempAry = orderStr.split(StringUtils.UNDERLINE);
                if (tempAry.length == 3) {
                    String property = tempAry[1];

                    property = SearchConstants.orderMap.get(property);
                    if (property == null) {
                        continue;
                    }

                    sortArr.add(addOrderCondition(property, tempAry[2]));
                    sortSet.add(property);
                }
            }
        }

        if (!sortSet.contains(SearchConstants.CURRENT_INTO_CAND_DATE)) {
            sortArr.add(addOrderCondition(SearchConstants.CURRENT_INTO_CAND_DATE,
                                          SearchConstants.DESC));
        }
        if (!sortSet.contains(SearchConstants.RESUME_ID)) {
            sortArr.add(addOrderCondition(SearchConstants.RESUME_ID,
                                          SearchConstants.DESC));
        }

        return sortArr;
    }

    private JSONObject addOrderCondition(String key, String sort) {

        JSONObject orderObj = new JSONObject();
        orderObj.put(SearchConstants.ORDER,
                     sort == null ? SearchConstants.DESC : sort);

        JSONObject obj = new JSONObject();
        obj.put(key, orderObj);

        return obj;
    }

}
