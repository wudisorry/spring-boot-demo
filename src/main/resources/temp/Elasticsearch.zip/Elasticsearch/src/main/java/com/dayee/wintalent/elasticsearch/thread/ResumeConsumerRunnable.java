
package com.dayee.wintalent.elasticsearch.thread;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dayee.wintalent.elasticsearch.service.IndexerService;
import com.dayee.wintalent.elasticsearch.util.SpringUtil;

public class ResumeConsumerRunnable implements Runnable {

    private static final Logger logger = LoggerFactory
            .getLogger(ResumeConsumerRunnable.class);

    private IndexerService      indexerService;

    public ResumeConsumerRunnable() {

        if (indexerService == null) {
            indexerService = (IndexerService) SpringUtil
                    .getBean("indexerService");
        }
    }

    @Override
    public void run() {

        do {
            indexerService.buildResumeIndex(ResumePoolManager.get());
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                logger.error(e.getMessage(), e);
            }
        } while (true);
    }
}
