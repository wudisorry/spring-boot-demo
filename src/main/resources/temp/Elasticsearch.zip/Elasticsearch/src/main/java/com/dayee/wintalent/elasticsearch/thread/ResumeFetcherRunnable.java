
package com.dayee.wintalent.elasticsearch.thread;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dayee.wintalent.elasticsearch.constant.Constants;
import com.dayee.wintalent.elasticsearch.framework.datasource.DynamicDataSourceContextHolder;
import com.dayee.wintalent.elasticsearch.mq.ResumeProducer;
import com.dayee.wintalent.elasticsearch.pojo.InfoClass;
import com.dayee.wintalent.elasticsearch.pojo.ResumeVO;
import com.dayee.wintalent.elasticsearch.service.ResumeService;
import com.dayee.wintalent.elasticsearch.util.ConfigUtils;
import com.dayee.wintalent.elasticsearch.util.SpringUtil;
import com.dayee.wintalent.elasticsearch.util.SqlUtils;
import org.springframework.util.CollectionUtils;

/***
 * 获取数据库简历
 */
public class ResumeFetcherRunnable extends Thread {

    private static final Logger logger = LoggerFactory
            .getLogger(ResumeFetcherRunnable.class);

    private Integer             startIndex;

    private Integer             handleSize;

    private String              type;

    private String              corpCode;

    private ResumeService       resumeService;

    private ResumeProducer      resumeProducer;

    public ResumeFetcherRunnable(String corpCode,
                                 String type,
                                 Integer startIndex,
                                 Integer handleSize) {

        this.corpCode = corpCode;
        this.type = type;
        this.startIndex = startIndex;
        this.handleSize = handleSize;

        if (resumeService == null) {
            //Thread.currentThread().setName(corpCode + "_" + type + "-Fetcher");
            resumeService = (ResumeService) SpringUtil.getBean("resumeService");
            resumeProducer = (ResumeProducer) SpringUtil
                    .getBean("resumeProducer");
        }
    }

    @Override
    public void run() {

        DynamicDataSourceContextHolder.setAlias(corpCode);
        Map<String, String> dicInfoMap = null;
        List<InfoClass> infoClasses = null;
        StringBuilder sql = new StringBuilder();
        long t0 = System.currentTimeMillis();
        int count = 0;
        try {
            String initTable = getInitTableName();
            if (ConfigUtils.isSimulationDataEnable()) {
                initTable += "_" + corpCode;
            }
            int pageCount = (handleSize + Constants.BATCH_DB_QUERY_SIZE - 1)
                            / Constants.BATCH_DB_QUERY_SIZE;
            int index = 1;
            do {
                long t1 = System.currentTimeMillis();
                int start = startIndex
                            + (index - 1) * Constants.BATCH_DB_QUERY_SIZE;
                int size = Constants.BATCH_DB_QUERY_SIZE;
                if (index >= pageCount) {
                    size = handleSize
                           - (index - 1) * Constants.BATCH_DB_QUERY_SIZE;
                }
                sql.delete(0, sql.length());
                sql.append("SELECT * FROM ")
                        .append(SqlUtils.getTable(initTable)).append(" LIMIT ")
                        .append(start).append(",").append(size);
                Collection<ResumeVO> resumeList = resumeService
                        .getInitResumeList(sql.toString(), type, dicInfoMap,
                                           infoClasses);

                // 获取线程最后一份简历，并打标记
                if (!CollectionUtils.isEmpty(resumeList)) {
                    count += resumeList.size();
                    if(index == pageCount){
                        int i = 0;
                        for (ResumeVO vo : resumeList) {
                            ++i;
                            if (i == resumeList.size()) {
                                vo.setThreadLastResume(true);
                            }
                        }
                    }
                }

                long t = System.currentTimeMillis() - t1;
                if (index < pageCount) {
                    String timeStr = "min";
                    float remainMin = (pageCount - index) * t / 60000;
                    if (remainMin == 0) {
                        remainMin = (pageCount - index) * t / 1000;
                        timeStr = "s";
                    }
                    timeStr = remainMin + timeStr;
                    logger.info("[{}_{}]({}/{})本批次已生产{}/{}份简历，耗时{}ms，将放入消费队列...预计剩余批次生产时间{}",
                            corpCode, type, index, pageCount, resumeList.size(), size, t, timeStr);
                } else {
                    logger.info("[{}_{}]({}/{})本批次已生产{}/{}份简历，耗时{}ms，将放入消费队列...",
                            corpCode, type, index, pageCount, resumeList.size(), size, t);
                }
                if (ConfigUtils.isRabbitmqEnable()) {
                    resumeProducer.resumeSend(resumeList);
                } else {
                    ResumePoolManager.putAll(resumeList);
                }
                index++;
            } while (index <= pageCount);

        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }

        long t = System.currentTimeMillis() - t0;
        logger.info("[{}_{}]本线程结束，生产{}/{}份简历，耗时{}ms",
                corpCode, type, count, handleSize, t);
    }

    private String getInitTableName() {

        return Constants.TYPE_APPLY
                .equals(type) ? "T_LUCENE_RESUME_APPLY_INIT_RECORD"
                              : "T_LUCENE_RESUME_TALENT_INIT_RECORD";
    }

    public String getType() {

        return type;
    }

    public void setType(String type) {

        this.type = type;
    }

    public String getCorpCode() {

        return corpCode;
    }

    public void setCorpCode(String corpCode) {

        this.corpCode = corpCode;
    }
}
