
package com.dayee.wintalent.elasticsearch.thread;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.concurrent.CustomizableThreadFactory;
import org.springframework.util.CollectionUtils;

import com.dayee.wintalent.elasticsearch.constant.Constants;
import com.dayee.wintalent.elasticsearch.pojo.ResumeVO;

public class ResumePoolManager {

    private static final Logger           logger                  = LoggerFactory
            .getLogger(ResumePoolManager.class);

    private final static ThreadFactory    CONSUMER_THREAD_FACTORY = new CustomizableThreadFactory(
            "W-ConsumerJobThread-%d");

    private final static ThreadFactory    PRODUCER_THREAD_FACTORY = new CustomizableThreadFactory(
            "W-ProducerJobThread-%d");

    public static final Map<String, Lock> LOCK_MAP                = new ConcurrentHashMap<>();

    public static Queue<String>           corpQueue               = new ConcurrentLinkedQueue<>();

    public static Map<String, Long>       refreshTimeMap          = new ConcurrentHashMap<>();

    public static BlockingQueue<ResumeVO> queue                   = new LinkedBlockingDeque<>();

    public static ExecutorService         consumerService;

    public static ExecutorService         producerService;

    public synchronized static void checkLock(String corpCode) {

        Lock lock = LOCK_MAP.get(corpCode);
        if (lock == null) {
            LOCK_MAP.put(corpCode, new ReentrantLock());
            addCorp(corpCode);
        }
    }

    public synchronized static void addCorp(String corpCode) {

        corpQueue.offer(corpCode);
    }

    public synchronized static String getCorp() {

        return corpQueue.poll();
    }

    public synchronized static void updateRefreshTime(String corpCode) {

        refreshTimeMap.put(corpCode, System.currentTimeMillis());
    }

    public synchronized static void addProducerListener(Runnable runnable) {

        if (producerService == null) {
            Integer coreSize = Constants.MAX_FETCH_THREAD;
            producerService = getProducerExecutorPool(coreSize, coreSize * 3);
        }
        producerService.execute(runnable);
    }

    // http://blog.sina.com.cn/s/blog_cfee55a70102xlca.html
    private static ExecutorService getProducerExecutorPool(int core, int max) {

        // Executors.newCachedThreadPool();
        ThreadPoolExecutor executor = new ThreadPoolExecutor(core, max, 5L,
                TimeUnit.SECONDS, new ArrayBlockingQueue(6),
                PRODUCER_THREAD_FACTORY, new RejectedExecutionHandler() {

                    @Override
                    public void rejectedExecution(Runnable r,
                                                  ThreadPoolExecutor executor) {

                        // 核心改造点，由blockingqueue的offer改成put阻塞方法
                        try {
                            executor.getQueue().put(r);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                });
        executor.allowCoreThreadTimeOut(true);
        return executor;
    }

    public synchronized static void addConsumerListener(Runnable runnable) {

        if (consumerService == null) {
            consumerService = Executors
                    .newFixedThreadPool(Constants.CONSUMER_THREAD_SIZE);
        }
        consumerService.execute(runnable);
    }

    public static void putAll(Collection<ResumeVO> obj) {

        if (CollectionUtils.isEmpty(obj)) {
            return;
        }
        synchronized (queue) {

            while ((queue.size() + obj.size()) > Constants.RESUME_POOL_SIZE) {
                try {
                    queue.wait();
                } catch (InterruptedException e) {
                    logger.error("put resume to pool exception :"
                                 + e.getMessage(), e);
                }
            }
            queue.addAll(obj);
            logger.info("此次生产{}份简历完毕（剩余待消费{}份简历），通知消费者消费", obj.size(),
                         queue.size());
            queue.notifyAll();
        }
    }

    public static List<ResumeVO> get() {

        List<ResumeVO> resumeList = null;
        synchronized (queue) {

            while (queue.size() == 0) {
                // logger.error("缓冲区充足, 等待生产者生产");
                try {
                    queue.wait();
                } catch (InterruptedException e) {
                    logger.error("get resume from pool exception :"
                                 + e.getMessage(), e);
                }
            }
            resumeList = new ArrayList<>();
            do {
                resumeList.add(queue.poll());
            } while (resumeList.size() < Constants.BATCH_ES_INDEX_SIZE
                     && !queue.isEmpty());
            logger.info("此次消费{}份简历完毕（剩余待消费{}份简历），通知生产者生产", resumeList.size(),
                         queue.size());
            queue.notifyAll();
        }
        return resumeList;
    }
}
