
package com.dayee.wintalent.elasticsearch.timer;

import java.util.concurrent.locks.Lock;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dayee.wintalent.elasticsearch.framework.datasource.DynamicDataSourceContextHolder;
import com.dayee.wintalent.elasticsearch.service.IndexerService;
import com.dayee.wintalent.elasticsearch.thread.ResumePoolManager;
import com.dayee.wintalent.elasticsearch.util.SpringUtil;

/**
 * 定时增量索引
 * 
 * @author Zhanggp
 * @date 2019/12/25 15:40
 */
public class QuartzIndexThread extends Thread {

    private static final Logger logger = LoggerFactory
            .getLogger(QuartzIndexThread.class);

    private Integer             index;

    private Integer             delayTime;

    private IndexerService      indexerService;

    QuartzIndexThread(Integer index, Integer delayTime) {

        this.index = index;
        this.delayTime = delayTime;
    }

    @Override
    public void run() {

        if (delayTime > 0) {
            try {
                Thread.sleep(delayTime);
            } catch (InterruptedException e) {
                logger.error(e.getMessage(), e);
            }
        }
        indexerService = (IndexerService) SpringUtil.getBean("indexerService");
        do {
            String corpCode = ResumePoolManager.getCorp();
            if (corpCode != null) {
                try {
                    Lock lock = ResumePoolManager.LOCK_MAP.get(corpCode);
                    if (lock.tryLock()) {
                        Long l1 = System.currentTimeMillis();
                        try {
                            updateRefreshTime(corpCode);
                            DynamicDataSourceContextHolder.setAlias(corpCode);
                            indexerService.refresh(null);
                        } catch (Exception e) {
                            logger.error("{}->{} refresh exception，{}",
                                         "QuartzIndexThread-" + index, corpCode,
                                         e.getMessage(), e);
                        } finally {
                            lock.unlock();
                            logger.debug("{} end refresh 【{}】use time 【{}】s",
                                         "QuartzIndexThread-" + index, corpCode,
                                         (System.currentTimeMillis()
                                          - l1) / 1000);
                        }
                    } else {
                        logger.info("{}->{} is indexing，will skip ###############################",
                                     "QuartzIndexThread-" + index, corpCode);
                    }
                } catch (Exception e) {
                    logger.error(e.getMessage(), e);
                } finally {
                    ResumePoolManager.addCorp(corpCode);
                }
            }
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                logger.error(e.getMessage(), e);
            }
        } while (true);
    }

    private void updateRefreshTime(String corpCode) {

        Long last = ResumePoolManager.refreshTimeMap.get(corpCode);
        logger.debug("{} start refresh 【{}】,time interval 【{}】s",
                     "QuartzIndexThread-" + index, corpCode,
                     last == null ? -1
                                  : (System.currentTimeMillis() - last) / 1000);
        ResumePoolManager.updateRefreshTime(corpCode);
    }

    public Integer getIndex() {

        return index;
    }

    public void setIndex(Integer index) {

        this.index = index;
    }

    public Integer getDelayTime() {

        return delayTime;
    }

    public void setDelayTime(Integer delayTime) {

        this.delayTime = delayTime;
    }
}
