
package com.dayee.wintalent.elasticsearch.timer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.dayee.wintalent.elasticsearch.util.ConfigUtils;

@Component
public class QuartzServiceManage {

    private static final Logger logger = LoggerFactory
            .getLogger(QuartzServiceManage.class);

    public static void init() {

        Integer size = ConfigUtils.getRefreshIndexThread();
        if (size != null && size > 0) {
            for (int i = 1; i <= size; i++) {
                // 刷新索引，弥补未成功实时索引的数据
                QuartzIndexThread thread = new QuartzIndexThread(i, i * 5000);
                thread.start();
                logger.info("start QuartzIndexThread->{}", i);
            }
        }
    }
}