
package com.dayee.wintalent.elasticsearch.util;

import java.math.BigDecimal;

import org.springframework.util.Assert;

public abstract class AbstractDataTypeUtils {

    public static boolean isBigDecimal(Object obj) {

        return isBigDecimal(obj.getClass());
    }

    public static boolean isBigDecimal(Class<?> propType) {

        return (BigDecimal.class == propType) ? true : false;
    }

    public static boolean isInteger(Object obj) {

        Assert.notNull(obj);
        Class<?> propType = obj.getClass();
        return (Integer.class == propType || int.class == propType) ? true
                                                                    : false;
    }

    public static boolean isLong(Object obj) {

        Assert.notNull(obj);
        Class<?> propType = obj.getClass();
        return (Long.class == propType || long.class == propType) ? true
                                                                  : false;
    }

}
