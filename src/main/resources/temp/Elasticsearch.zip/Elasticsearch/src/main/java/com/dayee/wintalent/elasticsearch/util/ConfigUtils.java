
package com.dayee.wintalent.elasticsearch.util;

import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "wintalent")
public class ConfigUtils {

    private static boolean      talentPoolEnable;

    private static List<String> esNodeList;

    private static boolean      rabbitmqEnable;

    /**
     * 是否记录企业索引的开始创建时间和结束时间
     */
    private static boolean      indexTimeLogEnable;

    private static boolean      simulationDataEnable;

    private static Integer      refreshIndexThread;

    private static boolean      noticeUpdateEnable = true;

    private static boolean      filterCodeEnable;

    private static boolean      checkRepeatUseLike;

    private static boolean      updateFieldEnable;

    public static List<String> getEsNodeList() {

        return esNodeList;
    }

    public void setEsNodeList(List<String> esNodeList) {

        ConfigUtils.esNodeList = esNodeList;
    }

    public static boolean isRabbitmqEnable() {

        return rabbitmqEnable;
    }

    public void setRabbitmqEnable(boolean rabbitmqEnable) {

        ConfigUtils.rabbitmqEnable = rabbitmqEnable;
    }

    public static boolean isTalentPoolEnable() {

        return talentPoolEnable;
    }

    public void setTalentPoolEnable(boolean talentPoolEnable) {

        ConfigUtils.talentPoolEnable = talentPoolEnable;
    }

    public static boolean isIndexTimeLogEnable() {

        return indexTimeLogEnable;
    }

    public void setIndexTimeLogEnable(boolean indexTimeLogEnable) {

        ConfigUtils.indexTimeLogEnable = indexTimeLogEnable;
    }

    public static boolean isSimulationDataEnable() {

        return simulationDataEnable;
    }

    public void setSimulationDataEnable(boolean simulationDataEnable) {

        ConfigUtils.simulationDataEnable = simulationDataEnable;
    }

    public static Integer getRefreshIndexThread() {

        return refreshIndexThread;
    }

    public void setRefreshIndexThread(Integer refreshIndexThread) {

        ConfigUtils.refreshIndexThread = refreshIndexThread;
    }

    public static boolean isNoticeUpdateEnable() {

        return noticeUpdateEnable;
    }

    public void setNoticeUpdateEnable(boolean noticeUpdateEnable) {

        ConfigUtils.noticeUpdateEnable = noticeUpdateEnable;
    }

    public static boolean isFilterCodeEnable() {

        return filterCodeEnable;
    }

    public void setFilterCodeEnable(boolean filterCodeEnable) {

        ConfigUtils.filterCodeEnable = filterCodeEnable;
    }

    public static boolean isCheckRepeatUseLike() {

        return checkRepeatUseLike;
    }

    public void setCheckRepeatUseLike(boolean checkRepeatUseLike) {

        ConfigUtils.checkRepeatUseLike = checkRepeatUseLike;
    }

    public static boolean isUpdateFieldEnable() {
        return updateFieldEnable;
    }

    public void setUpdateFieldEnable(boolean updateFieldEnable) {
        ConfigUtils.updateFieldEnable = updateFieldEnable;
    }

}
