
package com.dayee.wintalent.elasticsearch.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DateUtils {

    private static final Logger logger                 = LoggerFactory
            .getLogger(DateUtils.class);

    public static final String  DATE_NUMBER_FORMAT_YMD = "yyyyMMdd";

    public static Date charToDate(String dateStr, String format) {

        if (!StringUtils.hasLength(dateStr, true)) {
            return null;
        }
        try {
            SimpleDateFormat sdf = new SimpleDateFormat(format);
            return sdf.parse(dateStr);
        } catch (Exception e) {
            logger.error("{} format error {}", dateStr, e.getMessage());
        }
        return null;

    }

    public static Date getDateOfStartYear(int year) {

        Calendar lastDate = Calendar.getInstance();
        lastDate.set(Calendar.YEAR, year);
        lastDate.set(Calendar.MONTH, 0);
        lastDate.set(Calendar.DAY_OF_MONTH, 1);
        lastDate.set(Calendar.HOUR_OF_DAY, 0);
        lastDate.set(Calendar.MINUTE, 0);
        lastDate.set(Calendar.SECOND, 0);
        lastDate.set(Calendar.MILLISECOND, 0);
        return lastDate.getTime();
    }

    public static Date getDateOfEndYear(int year) {

        Calendar lastDate = Calendar.getInstance();
        lastDate.set(Calendar.YEAR, year);
        lastDate.set(Calendar.MONTH, 11);
        lastDate.set(Calendar.DAY_OF_MONTH, 31);
        lastDate.set(Calendar.HOUR_OF_DAY, 23);
        lastDate.set(Calendar.MINUTE, 59);
        lastDate.set(Calendar.SECOND, 59);
        return lastDate.getTime();
    }

    public static Date getDateBeforeMinute(Date d, int minute) {

        Calendar now = Calendar.getInstance();
        now.setTime(d);
        now.set(Calendar.MINUTE, now.get(Calendar.MINUTE) - minute);
        return now.getTime();
    }
}
