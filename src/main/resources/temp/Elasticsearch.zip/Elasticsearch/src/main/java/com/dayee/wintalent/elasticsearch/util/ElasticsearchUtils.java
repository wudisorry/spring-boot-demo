
package com.dayee.wintalent.elasticsearch.util;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.*;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.elasticsearch.client.Request;
import org.elasticsearch.client.Response;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestClientBuilder;
import org.springframework.util.CollectionUtils;

public class ElasticsearchUtils {

    public static final int   CONNECT_TIMEOUT            = 60000;

    public static final int   CONNECTION_REQUEST_TIMEOUT = 60000;

    public static final int   SOCKET_TIMEOUT             = 60000;

    public static final int   MAXRETRY_TIMEOUT           = 60000;

    private static RestClient restClient;

    /**
     * @return
     * @throws IOException
     */
    public static RestClient getRestClient() throws IOException {

        if (restClient == null) {

            synchronized (ElasticsearchUtils.class) {
                if (restClient == null) {
                    initRestClient();
                }
            }
        }
        return restClient;
    }

    private static final Pattern HOST_PATTERN = Pattern
            .compile("(http|https)://([^:]+):(\\d+)");

    private static void initRestClient() {

        HttpHost[] hosts = initEsNodes();

        RestClientBuilder restClientBuilder = RestClient.builder(hosts);
        restClientBuilder.setMaxRetryTimeoutMillis(MAXRETRY_TIMEOUT)
                .setRequestConfigCallback(new RestClientBuilder.RequestConfigCallback() {

                    @Override
                    public RequestConfig.Builder customizeRequestConfig(RequestConfig.Builder requestConfigBuilder) {

                        return requestConfigBuilder
                                .setConnectTimeout(CONNECT_TIMEOUT)
                                .setConnectionRequestTimeout(CONNECTION_REQUEST_TIMEOUT)
                                .setSocketTimeout(SOCKET_TIMEOUT);
                    }
                });
        restClient = restClientBuilder.build();
    }

    private static HttpHost[] initEsNodes() {

        HttpHost[] hosts = null;
        List<String> nodeList = ConfigUtils.getEsNodeList();
        if (!CollectionUtils.isEmpty(nodeList)) {
            hosts = new HttpHost[nodeList.size()];
            Matcher matcher = null;
            int index = 0;
            for (String nodeStr : nodeList) {
                matcher = HOST_PATTERN.matcher(nodeStr);
                if (matcher.find()) {
                    String scheme = matcher.group(1);
                    String host = matcher.group(2);
                    int port = Integer.parseInt(matcher.group(3));
                    hosts[index++] = new HttpHost(host, port, scheme);
                }
            }
        } else {
            throw new RuntimeException("无可用Es节点！");
        }
        return hosts;
    }

    public static String sendRestClientRequest(String uri,
                                               String method,
                                               String requestBody)
            throws IOException {

        Response response = getRestClientResponse(uri, method, requestBody);
        if (response.getEntity() != null) {
            String result = IOUtils.toString(response.getEntity().getContent(),
                                             "utf-8");
            IOUtils.closeQuietly(response.getEntity().getContent());
            return result;
        }

        return null;
    }

    private static Response getRestClientResponse(String uri,
                                                  String method,
                                                  String requestBody)
            throws IOException {

        RestClient restClient = getRestClient();
        Request request = new Request(method, uri);
        if (requestBody != null) {
            request.setJsonEntity(requestBody);
        }
        return restClient.performRequest(request);
    }

    /**
     * <pre>
     *  验证es的某个索引是否存在
     *  Response response = restClient.performRequest("HEAD","/ygbx8_apply",Collections.<String, String>emptyMap());
     * </pre>
     * 
     * @return
     */
    public static boolean isIndexExstis(String corpCode, String type)
            throws IOException {

        String uri = StringUtils.DIAGONAL
                     + IndexerUtils.getIndexerName(corpCode, type);
        Response response = getRestClientResponse(uri, HttpHead.METHOD_NAME,
                                                  null);
        return response.getStatusLine().getStatusCode() == 200;
    }

    public static String sendRequest(String url,
                                     String method,
                                     Map<String, String> headerMap,
                                     Map<String, Object> paramMap,
                                     String requestBody)
            throws IOException {

        String result = null;
        CloseableHttpResponse httpResponse = null;
        RequestConfig requestConfig = RequestConfig.custom()
                .setConnectTimeout(CONNECT_TIMEOUT)
                .setConnectionRequestTimeout(CONNECTION_REQUEST_TIMEOUT)
                .setSocketTimeout(SOCKET_TIMEOUT).build();

        CloseableHttpClient httpclient = HttpClients.custom()
                .setDefaultRequestConfig(requestConfig).build();

        HttpRequestBase request = generateHttpRequest(url, method, headerMap,
                                                      paramMap, requestBody);
        httpResponse = httpclient.execute(request);
        if (httpResponse.getEntity() != null) {
            result = IOUtils.toString(httpResponse.getEntity().getContent(),
                                      "utf-8");
            IOUtils.closeQuietly(httpResponse.getEntity().getContent());
        }
        return result;
    }

    private static HttpRequestBase generateHttpRequest(String url,
                                                       String method,
                                                       Map<String, String> headerMap,
                                                       Map<String, Object> paramMap,
                                                       String requestBody)
            throws UnsupportedEncodingException {

        HttpRequestBase request = null;
        if (HttpGet.METHOD_NAME.equalsIgnoreCase(method)) {
            request = new HttpGet(url);
        } else if (HttpDelete.METHOD_NAME.equalsIgnoreCase(method)) {
            request = new HttpDelete(url);
        } else {
            if (HttpPost.METHOD_NAME.equalsIgnoreCase(method)) {
                request = new HttpPost(url);
            } else if (HttpPut.METHOD_NAME.equalsIgnoreCase(method)) {
                request = new HttpPut(url);
            }
            // set entity
            HttpEntity httpEntity = generateHttpEntity(paramMap, requestBody,
                                                       null);
            if (httpEntity != null) {
                ((HttpEntityEnclosingRequestBase) request)
                        .setEntity(httpEntity);
            }
        }
        addHeaders(headerMap, request);
        return request;
    }

    private static void addHeaders(Map<String, String> headerMap,
                                   HttpRequestBase request) {

        if (headerMap != null) {
            for (Map.Entry<String, String> entry : headerMap.entrySet()) {
                request.addHeader(entry.getKey(), entry.getValue());
            }
        }
    }

    private static HttpEntity generateHttpEntity(Map<String, Object> paramMap,
                                                 String requestBody,
                                                 String encoding)
            throws UnsupportedEncodingException {

        if (!StringUtils.hasLength(encoding)) {
            encoding = "utf-8";
        }
        if (StringUtils.hasLength(requestBody)) {

            StringEntity entity = new StringEntity(requestBody, encoding);
            entity.setContentEncoding(encoding);
            entity.setContentType("application/json");
            return entity;
        } else {

            List<NameValuePair> formParams = new ArrayList<NameValuePair>();
            if (paramMap != null) {
                for (Map.Entry<String, Object> entry : paramMap.entrySet()) {
                    formParams.add(new BasicNameValuePair(entry.getKey(),
                            (String) entry.getValue()));
                }
            }
            return new UrlEncodedFormEntity(formParams, encoding);
        }
    }
}
