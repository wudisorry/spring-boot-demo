
package com.dayee.wintalent.elasticsearch.util;

import java.util.ArrayList;
import java.util.List;

import com.dayee.wintalent.elasticsearch.constant.Constants;
import com.dayee.wintalent.elasticsearch.framework.datasource.DynamicDataSourceContextHolder;

public class IndexerUtils {

    public static String getIndexerName(String type) {

        return getIndexerName(DynamicDataSourceContextHolder.getAlias(), type);
    }

    public static String getIndexerName(String corpCode, String type) {

        return corpCode.toLowerCase() + StringUtils.UNDERLINE + type;
    }

    public static List<String> getTypeList(String types) {

        List<String> typeList = StringUtils.strToStrList(types,
                                                         StringUtils.COMMA);
        if (typeList == null) {
            typeList = new ArrayList<>();
            typeList.add(Constants.TYPE_APPLY);
            typeList.add(Constants.TYPE_CAND);
        }
        return typeList;
    }
}
