
package com.dayee.wintalent.elasticsearch.util;

import java.util.Date;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

public class JsonUtils {

    public static String getString(JSONObject obj, String name) {

        Object o = obj == null ? null : obj.get(name);
        if (o != null) {
            return o.toString();
        } else {
            return StringUtils.EMPTY;
        }
    }

    public static JSONArray getJSONArray(JSONObject obj, String name) {

        Object o = obj == null ? null : obj.get(name);
        if (o != null && (o instanceof JSONArray)) {
            return (JSONArray) o;
        } else {
            return null;
        }
    }

    public static JSONObject getJSONObject(JSONObject obj, String name) {

        Object o = obj == null ? null : obj.get(name);
        if (o != null && (o instanceof JSONObject)) {
            return (JSONObject) o;
        } else {
            return null;
        }
    }

    public static Date getDate(JSONObject resume, String key) {

        if (resume != null && StringUtils.hasLength(key, true)) {
            Long time = resume.getLong(key);
            return time == null ? null : new Date(time);
        }
        return null;
    }

    public static Integer getInteger(JSONObject obj, String name) {

        Object o = obj == null ? null : obj.get(name);
        if (o != null) {
            return (o instanceof Number) ? ((Number) o).intValue()
                                         : Integer.parseInt((String) o);
        }
        return null;
    }
}
