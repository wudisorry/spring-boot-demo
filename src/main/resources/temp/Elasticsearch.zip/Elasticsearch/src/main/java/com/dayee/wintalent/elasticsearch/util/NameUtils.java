
package com.dayee.wintalent.elasticsearch.util;

import java.io.BufferedReader;
import java.io.StringReader;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Zhanggp
 * @date 2020/3/20 19:08
 */
public class NameUtils {

    private static final Logger      logger               = LoggerFactory
            .getLogger(NameUtils.class);

    public static Collection<String> SCHOOLS;

    /***
     * 北京大学、广西体育高等专科学校、北京师范大学珠海分校、广东工业大学华立学院
     */
    public static final String[]     SCHOOL_TAGS          = new String[] { "大学",
            "学校", "分校", "学院" };

    public static final String[]     N_SCHOOL_RELATE_TAGS = new String[] {
            "985", "211", "校区", "学院" };

    public static final String[]     COMPANY_TAGS         = new String[] {
            "管理有限公司", "发展有限公司", "科技有限公司", "责任有限公司", "股份有限公司", "信息有限公司",
            "信息工程有限公司", "服务有限公司", "投资有限公司", "有限责任公司", "电子商务有限公司", "有限公司" };

    static {
        SCHOOLS = getDicSet("dic_school.item");
    }

    public static Collection<String> getDicSet(String name) {

        Set<String> dicNameSet = null;
        try {
            String content = IOUtils.toString(NameUtils.class
                    .getResourceAsStream("/item/" + name), "utf-8");
            BufferedReader reader = new BufferedReader(
                    new StringReader(content));
            dicNameSet = new TreeSet<>();
            String line = null;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (StringUtils.hasLength(line)) {
                    dicNameSet.add(line);
                }
            }
        } catch (Exception e) {
            logger.error("get {} error {}", name, e.getMessage(), e);
        }
        return dicNameSet;
    }

    public static String getCompanyName(String company) {

        for (String tag : COMPANY_TAGS) {
            if (company.endsWith(tag)) {
                return company.substring(0, company.lastIndexOf(tag));
            }
        }
        return company;
    }

    public static boolean isSameCompany(List<String> resumeCompanys,
                                        String dbCompany) {

        if (resumeCompanys.contains(dbCompany)) {
            return true;
        }
        String dbCompanySimple = getCompanyName(dbCompany);
        for (String resumeCompany : resumeCompanys) {
            String resumeCompanySimple = getCompanyName(resumeCompany);
            if (StringUtils.equals(dbCompanySimple, resumeCompanySimple)
                || StringUtils.equals(resumeCompany, dbCompanySimple)
                || StringUtils.equals(resumeCompanySimple, dbCompany)) {
                return true;
            }
        }
        return false;
    }

    public static String getSchoolName(String school) {

        if (SCHOOLS == null) {
            return school;
        }
        for (String name : SCHOOLS) {
            if (school.contains(name)) {
                return name;
            }
        }
        for (String tag : SCHOOL_TAGS) {
            int index = school.lastIndexOf(tag);
            if (index > -1) {
                return school.substring(0, index + tag.length());
            }
        }
        return school;
    }

    public static boolean isSameSchool(List<String> resumeSchools,
                                       String dbSchool) {

        if (resumeSchools.contains(dbSchool)) {
            return true;
        }
        String dbSchoolSimple = getSchoolName(dbSchool);
        String dbTail = dbSchool.replace(dbSchoolSimple, "");
        boolean dbTailIsKey = isSchoolKeyword(dbTail);
        for (String resumeSchool : resumeSchools) {
            String resumeSchoolSimple = getSchoolName(resumeSchool);
            if (SCHOOLS != null && SCHOOLS.contains(dbSchoolSimple)
                && SCHOOLS.contains(resumeSchoolSimple)) {
                return StringUtils.equals(resumeSchoolSimple, dbSchoolSimple);
            }
            String resumeSchoolTail = StringUtils
                    .trim(resumeSchool.replace(resumeSchoolSimple, ""));
            boolean resumeSchoolTailIsKey = isSchoolKeyword(resumeSchoolTail);
            if (dbTailIsKey || resumeSchoolTailIsKey) {
                return false;
            }
            return StringUtils.equals(resumeSchoolSimple, dbSchoolSimple);
        }
        return false;
    }

    private static boolean isSchoolKeyword(String tail) {

        if (!StringUtils.hasLength(tail, true)) {
            return false;
        }
        boolean relate = true;
        for (String tag : N_SCHOOL_RELATE_TAGS) {
            if (tail.contains(tag)) {
                relate = false;
                break;
            }
        }
        return relate;
    }
}
