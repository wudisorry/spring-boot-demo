package com.dayee.wintalent.elasticsearch.util;


import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ResumeEncryptUtils {

    private static final Logger logger = LoggerFactory.getLogger(ResumeEncryptUtils.class);


    private static final String key = "0eTnbJtXgjEs11bR";  // 固定key, 用于加密每个企业的密钥





    /**
     * 获取一个新的随机16位密钥,并加密
     * @return
     */
    public static String getNewCorpAESKey() throws Exception{
        Random random = new Random();

        StringBuffer valSb = new StringBuffer();

        String charStr = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

        int charLength = charStr.length();

        for (int i = 0; i < 16; i++) {

            int index = random.nextInt(charLength);

            valSb.append(charStr.charAt(index));

        }

        return encrypt(valSb.toString());
    }


    public static void addEncryptRecord(Integer resumeId) {


        if(resumeId != null){

        }
    }



    public static String encrypt(String sSrc) throws Exception {

        return encrypt(sSrc,key);
    }

    public static String encrypt(String sSrc,String key) throws Exception {

        if (key == null) {
            logger.error("Key为空null");
            return null;
        }
        // 判断Key是否为16位
        if (key.length() != 16) {
            logger.error("Key长度不是16位");
            return null;
        }
        byte[] raw = key.getBytes("ASCII");
        SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
        byte[] encrypted = cipher.doFinal(sSrc.getBytes());
        return byte2hex(encrypted).toLowerCase();
    }



    public static String decrypt(String sSrc,String key,String corpCode) throws Exception {

        try {
            // 判断Key是否正确
            if (key == null) {
                logger.error(corpCode+",Key为空null");
                return null;
            }
            // 判断Key是否为16位
            if (key.length() != 16) {
                logger.error(corpCode+",Key长度不是16位");
                return null;
            }

            byte[] raw = key.getBytes("ASCII");
            SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            cipher.init(Cipher.DECRYPT_MODE, skeySpec);
            byte[] encrypted1 = hex2byte(sSrc);
            byte[] original = cipher.doFinal(encrypted1);
            String originalString = "";
            originalString = new String(original,"utf-8");
            return originalString;
        } catch (Exception ex) {
            logger.error(corpCode+",AES解密错误："+sSrc+",eMessage:"+ex.getMessage(),ex);
            return sSrc;
        }
    }

    public static byte[] hex2byte(String strhex) {

        if (strhex == null) {
            return null;
        }
        int l = strhex.length();
        if (l % 2 == 1) {
            return null;
        }
        byte[] b = new byte[l / 2];
        for (int i = 0; i != l / 2; i++) {
            b[i] = (byte) Integer.parseInt(strhex.substring(i * 2, i * 2 + 2),
                    16);
        }
        return b;
    }


    public static String byte2hex(byte[] b) {

        String hs = "";
        String stmp = "";
        for (int n = 0; n < b.length; n++) {
            stmp = (java.lang.Integer.toHexString(b[n] & 0XFF));
            if (stmp.length() == 1) {
                hs = hs + "0" + stmp;
            } else {
                hs = hs + stmp;
            }
        }
        return hs.toUpperCase();
    }
}
