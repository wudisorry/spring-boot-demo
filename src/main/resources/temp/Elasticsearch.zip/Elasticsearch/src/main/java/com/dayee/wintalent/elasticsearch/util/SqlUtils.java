
package com.dayee.wintalent.elasticsearch.util;

import java.math.BigDecimal;

import com.dayee.wintalent.elasticsearch.framework.datasource.DynamicDataSourceContextHolder;

public class SqlUtils {

    public static final int    SELECT_EQ_SIZE      = 1;

    public static final int    SELECT_IN_SIZE      = 2000;

    public static final String CONSTANT_INEQUALITY = " (1 != 1) ";

    public static final String EQ                  = " = ? ";

    public static final String IN                  = " IN ";

    public static final String NOT_IN              = " NOT IN ";

    public static final String OR                  = " OR ";

    public static final String LEFT_BRACKETS       = "(";

    public static final String RIGHT_BRACKETS      = ")";

    public static final String COMMA               = ",";

    public static final String Q_MARK              = "?";

    public static final String DOT                 = ".";

    public static String getTable(String table) {

        String db = DynamicDataSourceContextHolder.getDataSourceDb();
        if (StringUtils.hasLength(db)) {
            return StringUtils.SINGLE_REF_CH + db
                   + StringUtils.SINGLE_REF_CH
                   + DOT
                   + table;
        }
        return table;
    }

    public static Integer getInteger(Object obj) {

        Integer result = null;
        if (obj != null) {
            if (AbstractDataTypeUtils.isBigDecimal(obj)) {
                BigDecimal bid = (BigDecimal) obj;
                result = bid.intValue();
            } else if (AbstractDataTypeUtils.isInteger(obj)) {
                result = (Integer) obj;
            } else if (AbstractDataTypeUtils.isLong(obj)) {
                result = ((Long) obj).intValue();
            }
        }
        return result;
    }

    public static String createInJunction(String property, int size) {

        if (size > 0) {

            if (size == SELECT_EQ_SIZE) {
                StringBuilder buffer = new StringBuilder();
                buffer.append(property).append(EQ);
                return buffer.toString();
            } else if (size <= SELECT_IN_SIZE) {
                StringBuilder buffer = new StringBuilder(size * 2);
                buffer.append(LEFT_BRACKETS);
                buffer.append(property).append(IN).append(LEFT_BRACKETS);
                for (int i = 0; i < size; i++) {
                    if (i > 0) {
                        buffer.append(COMMA);
                    }
                    buffer.append(Q_MARK);
                }
                buffer.append(RIGHT_BRACKETS);
                buffer.append(RIGHT_BRACKETS);
                return buffer.toString();
            } else {

                StringBuilder buffer = new StringBuilder(size * 2);
                buffer.append(LEFT_BRACKETS);
                int num = 0;
                do {
                    if (num > 0) {
                        buffer.append(OR);
                    }
                    buffer.append(property).append(IN).append(LEFT_BRACKETS);

                    for (int i = 0; i < SELECT_IN_SIZE; i++) {
                        buffer.append(Q_MARK);
                        num++;
                        if (num < size) {
                            buffer.append(COMMA);
                        } else {
                            buffer.append(RIGHT_BRACKETS);
                            break;
                        }
                    }
                    if (num < size) {
                        num++;
                        buffer.append(Q_MARK).append(RIGHT_BRACKETS);
                    }

                } while (num < size);
                buffer.append(RIGHT_BRACKETS);
                return buffer.toString();
            }
        } else {
            return CONSTANT_INEQUALITY;
        }
    }
}
