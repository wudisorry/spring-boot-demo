
package com.dayee.wintalent.elasticsearch.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class StringUtils extends org.springframework.util.StringUtils {

    public static final String UNDERLINE     = "_";

    public static final String EMPTY         = "";

    public static final String COMMA         = ",";

    public static final String DIAGONAL      = "/";

    public static final String SINGLE_REF_CH = "`";

    public static final String SEMICOLON     = ";";

    public static final String SPACE         = " ";

    public static final String ASTERISK      = "*";

    public static final String SHORT_LINE    = "-";

    public static boolean hasLength(CharSequence s, boolean isTrim) {

        if (s == null || s.length() == 0) {
            return false;
        }
        if (isTrim) {
            String str = StringUtils.trim(s.toString());
            return str.length() > 0;
        } else {
            return true;
        }
    }

    public static String trim(String str) {

        return str == null ? null : str.trim();
    }

    public static List<Integer> strToIntegerList(String str,
                                                 String splitRegex) {

        List<Integer> ret = null;
        if (StringUtils.hasLength(str, true)) {
            ret = new ArrayList<Integer>();
            String[] array = str.split(splitRegex);
            for (String s : array) {
                if (StringUtils.hasLength(s, true)) {
                    ret.add(Integer.parseInt(s.trim()));
                }
            }
        }
        return ret;
    }

    public static List<String> strToStrList(String str, String splitRegex) {

        List<String> ret = null;
        if (StringUtils.hasLength(str, true)) {
            ret = new ArrayList<String>();
            String[] array = str.split(splitRegex);
            for (String s : array) {
                if (StringUtils.hasLength(s, true)) {
                    ret.add(s.trim());
                }
            }
        }
        return ret;
    }

    public static void joinCollectionValueToStr(Collection<?> c,
                                                StringBuilder sb) {

        for (Object value : c) {
            if (value == null) {
                continue;
            }

            if (sb.length() > 0) {
                sb.append(StringUtils.COMMA);
                sb.append(StringUtils.SPACE);
            }
            sb.append(value);
        }
    }

    public static boolean equals(String str1, String str2) {

        return str1 == null ? str2 == null : str1.equals(str2);
    }
}
