
package com.dayee.wintalent.elasticsearch;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringRunner;

import com.dayee.wintalent.elasticsearch.framework.datasource.DynamicDataSourceContextHolder;
import com.dayee.wintalent.elasticsearch.service.SearchService;

//@RunWith(SpringRunner.class)
public class ElasticsearchQueryTest {

    //@Autowired
    private SearchService searchService;

    //@Test
    public void textQueryTest() throws Exception {

        DynamicDataSourceContextHolder.setAlias("ygbx8");
        String keyword = "STAFFING+MANAGER-人事共享中心-招聘-RECUITER-TALENT ACQUISITION-RESUIT-培训-TRAINING-薪资-薪酬-PAYROLL-C&B-社保-福利-BENEFIT-绩效-考核-PERFORMANCE-员工关系-员工沟通-EMPLOYEE RELATIONSHIP-ERM-ER-组织发展-组织与人才发展-OD-ORGANIZATION DEVELOPMENT-员工发展-员工培训发展-员工培训与发展-LEARNING AND DEVELOPMENT-组织与人才发展-COE-CENTER OF EXPERTISE-CENTER OF EXCELLENCE-COE招聘-COE 招聘-COE RECUITER-COE OF TALENT ACQUISITION-COE薪酬-COE 薪酬-COE C&B-人力资源伙伴-人力资源业务合作-人事业务合作-人力业务合作伙伴-HRBP-HR BP-人力资源共享-人事资源共享-人力共享中心-人事共享中心-SSC-HR/-SSC-HRSSC-HR SSC+SUPERVISOR";
        Integer keywordType = 6;
        Integer resumeType = 1;
        int language = 1;

        List<String> resumeIdList = searchService
                .keyWordQuery(keywordType, keyword, resumeType, null, null, language);
        System.out.println(resumeIdList);
    }
}
