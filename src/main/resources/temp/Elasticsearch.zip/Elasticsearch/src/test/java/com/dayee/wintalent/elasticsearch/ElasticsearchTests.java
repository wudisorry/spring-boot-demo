
package com.dayee.wintalent.elasticsearch;

import java.io.IOException;
import java.util.UUID;

import org.apache.http.client.methods.HttpPut;

import com.dayee.wintalent.elasticsearch.util.ElasticsearchUtils;

public class ElasticsearchTests {

    static String INDEX_URL = "http://localhost:9200";

    public static void main(String[] args) throws IOException {

        //createIndex();
    }

    public static void createIndex() throws IOException {

        final String requestBody = "{\"first_name\":\"John\","
                                   + "\"last_name\":\"haha\","
                                   + "\"age\":25,"
                                   + "\"about1\":\"I love to go rock climbing\","
                                   + "\"interests\":[\"sports\",\"music\"]}";
        final String requstUrl = INDEX_URL + "/megacorp/employee/";
        for (int i = 0; i < 5; i++) {
            new Thread() {

                @Override
                public void run() {

                    for (int j = 0; j < 1000; j++) {
                        try {
                            String result = ElasticsearchUtils
                                    .sendRequest(requstUrl + UUID.randomUUID(),
                                                 HttpPut.METHOD_NAME, null,
                                                 null, requestBody);
                            System.out.println(Thread.currentThread().getName()
                                               + "\t"
                                               + result);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }.start();
        }
    }
}
