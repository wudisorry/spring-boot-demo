
package com.dayee.wintalent.elasticsearch;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.util.Collection;
import java.util.Comparator;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.io.FileUtils;

import com.dayee.wintalent.elasticsearch.util.NameUtils;
import com.dayee.wintalent.elasticsearch.util.StringUtils;

/**
 * @author Zhanggp
 * @date 2020/3/22 10:50
 */
public class SchooleFilterTest {

    public static void main(String[] args) throws IOException {

        filterSchool();
        String[] names = new String[] { "江苏大学吴江校区", "江苏大学管理学院", "江苏大学(985)",
                "江苏大学(985、211)" };
        findSchool(names);
    }

    public static void findSchool(String[] names) {

        for (String input : names) {
            System.out.println("input:" + input
                               + "->"
                               + NameUtils.getSchoolName(input));
        }
    }

    private static void filterSchool() throws IOException {

        String content = FileUtils
                .readFileToString(new File("F:\\proxy\\0312\\school.txt"),
                                  "utf-8");

        Collection<String> old = NameUtils.getDicSet("dic_school.item");

        Set<String> sepciall = new TreeSet<>(new StringComparator());
        BufferedReader reader = new BufferedReader(new StringReader(content));
        String line = null;
        while ((line = reader.readLine()) != null) {
            line = StringUtils.trim(line.trim());
            if (StringUtils.hasLength(line)) {
                line = line.replaceAll("（", "(").replaceAll("）", ")");
                int score = 0;
                for (String tag : NameUtils.SCHOOL_TAGS) {
                    if (line.contains(tag)) {
                        score++;
                    }
                }
                if (score > 1) {
                    old.remove(line);
                    sepciall.add(line);
                } else if (line.endsWith("大学") || line.endsWith("学院")
                           || line.endsWith("学校")
                           || line.endsWith("分校")) {

                } else {
                    old.remove(line);
                    sepciall.add(line);
                }
            }
        }
        sepciall.addAll(old);
        System.out.println(sepciall);
    }

    static class StringComparator implements Comparator {

        @Override
        public int compare(Object o1, Object o2) {

            String s1 = (String) o1;
            String s2 = (String) o2;
            int num = new Integer(s2.length())
                    .compareTo(new Integer(s1.length()));
            if (num == 0) {
                return s2.compareTo(s1);
            }
            return num;
        }
    }
}
