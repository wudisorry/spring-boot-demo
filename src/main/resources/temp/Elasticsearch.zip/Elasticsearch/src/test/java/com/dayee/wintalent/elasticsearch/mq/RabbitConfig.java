
package com.dayee.wintalent.elasticsearch.mq;

import org.springframework.amqp.core.Queue;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author Zhanggp
 * @date 2019/8/24 17:43
 */
@Configuration
public class RabbitConfig {

    @Bean
    public Queue string() {

        return new Queue("string");
    }
}
