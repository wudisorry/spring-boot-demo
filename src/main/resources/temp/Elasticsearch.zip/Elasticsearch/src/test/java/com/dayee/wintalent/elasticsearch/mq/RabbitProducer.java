
package com.dayee.wintalent.elasticsearch.mq;

import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author Zhanggp
 * @date 2019/8/24 18:35
 */
@Component
public class RabbitProducer {

    @Autowired
    private AmqpTemplate rabbitTemplate;

    public void stringSend() {

        String l1 = "a" + System.currentTimeMillis();
        long l2 = System.currentTimeMillis();
        System.out.println("[string] send msg:" + l1);
        this.rabbitTemplate.convertAndSend("string", l2);
    }
}
