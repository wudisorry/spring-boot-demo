mvn clean package -Pdev -DskipTests

插件安装：
    https://blog.csdn.net/zebra_916/article/details/78020630
    ik：https://github.com/medcl/elasticsearch-analysis-ik

文档：
    https://blog.csdn.net/zxc123e/article/details/79268361

查看字段mapping：
    http://localhost:9200/ygbx8/_mapping?pretty
    http://localhost:9200/dayeegame_apply/_mapping/resume?pretty

查看索引的索引
    http://localhost:9200/_cat/indices?v

请求url：http://localhost:9200/ygbx8/resume/_search
请求参数：
    {"query":{"bool":{"must":[{"match_all":{}}],"must_not":[],"should":[]}},"from":0,"size":10,"sort":[],"aggs":{}}
    {
        "query": {
            "bool": {
                "must": [
                    {
                        "prefix": {
                            "detailInfo.PERS_INFO_CH.keyword": "马"
                        }
                    }
                ],
                "must_not": [ ],
                "should": [ ]
            }
        },
        "from": 0,
        "size": 5000,
        "sort": [ ], // 排序
        "aggs": { }, // 聚合查询
        "_source": [] // 返回指定的字段
    }

    "_source": "obj.*",
    "_source": [ "obj1.*", "obj2.*" ],
    "_source": {
            "includes": [ "obj1.*", "obj2.*" ],
            "excludes": [ "*.description" ]
        },

    //_mapping
    {
        "resume": {
                "properties": {
                    "name": {
                        "type": "text",
                        "fields":{
                        	"raw":{"type":"keyword"}
                        }
                    },
                    "gender":{
                    	"type": "keyword"
                    },
                    "school":{
                    	"type":"text",
                    	"fields":{
                    		"raw":{"type":"keyword"}
                    	}
                    },
                    "workExp":{
                    	"type":"nested",
                    	"properties":{
                    		"corpName":{
                    			"type":"text",
                    			"fields":{"raw":{"type":"keyword"}}
                    		},
                    		"post":{
                    			"type":"text",
                    			"fields":{"raw":{"type":"keyword"}}
                    		}
                    	}
                    }
                }
            }
      }

    {
      "query": {
        "match": {
          "school.raw": "北京大学"
        }
      }
    }

    {
        "query": {
            "bool": {
                "must": [
                    {
                        "nested": {
                            "path": "eduExp",
                            "query": {
                                "bool": {
                                    "must": [
                                        {
                                            "match": {
                                                "eduExp.major": "控制工程"
                                            }
                                        },
                                        {
                                            "match": {
                                                "eduExp.school": "内蒙古科技大学"
                                            }
                                        }
                                    ]
                                }
                            }
                        }
                    }
                ]
            }
        }
    }


    {
      "query": {
        "bool": {
          "must": [
            {
              "nested": {
                "path": "workExp",
                "query": {
                  "bool": {
                    "must": [
                      {
                        "match": {
                          "workExp.corpName.raw": "百度"
                        }
                      },
                      {
                        "match": {
                          "workExp.post.raw": "java"
                        }
                      }
                    ]
                  }
                }
              }
            }
          ]
        }
      }
    }

    ik分词（post），例如：海牛
        ik_max_word “上海”、“牛人”、“海牛
        ik_smart    “上海”、“牛人”
        standard    “海”、“牛”
    测试分词请求：
        http://localhost:9200/_analyze
        {
           "text":"世界如此之大，我想去看看张三","analyzer":"ik_max_word"
        }

一、初级查询

1、简单查询：
    http://localhost:9200/ygbx8/resume/923875689-1
    http://localhost:9200/ygbx8/resume/923875689-1?version=1

2、条件查询（所有的查询都是以query作为关键词）

    a、查询所有数据
        {
          "query": {
            "match_all": {}
          }
        }

    b、关键词查询（查询name包含张远的文档）
    匹配（match）查询属于全文查询，ElasticSearch引擎在处理全文搜索时，首先分析（analyze）查询字符串，然后根据分词构建查询，最终返回查询结果。对于全文查询条件 “title”: “Quick Foxes!”，ElasticSearch引擎首先分析查询字符串，将其拆分成两个小写的分词。只要title字段值中包含有任意一个关键字quick或者oxes，那么返回该文档。
        {
          "query": {
            "match": {
              "name": "张远"
            }
          }
        }


3、聚合查询 ?

4、通配符查询

    a、前缀匹配查询
        {
            "query":{
                "prefix":{
                    "name":"python"
                }
            }
        }

    b、通配符查询 （? 匹配任意字符， * 匹配 0 或多个字符）
        {
            "query":{
                "wildcard":{
                    "name":"*张"
                }
            }
        }

    c、正则匹配查询
        {
            "query": {
                "regexp": {
                    "resumeId": "[0-3].+"
                }
            }
        }

二、子条件查询，查询特定字段所指特定值，子条件查询分为Query context和Filter context。

* Query Context
1、全文本查询：ElasticSearch引擎会先分析（analyze）查询字符串，将其拆分成小写的分词，只要已分析的字段中包含词条的任意一个，或全部包含，就匹配查询条件，返回该文档；如果不包含任意一个分词，表示没有任何文档匹配查询条件。

    a、模糊匹配：查询name中包含“张”或“远”或“张远”的数据：
        {
          "query": {
            "match": {
              "name": "张远"
            }
          }
        }

    b、习语查询：将"张远"作为一个整体查询
        {
            "query":{
                "match_phrase":{
                    "name":"张远"
                }
            }
        }
    match_phrase检索时候，文档必须同时满足以下两个条件，才能被检索到：
    1）分词后所有词项都出现在该字段中；
    2）字段中的词项顺序要一致。

    c、多个字段匹配查询：查询name和detailInfo.PERS_INFO_CH字段包含chm的所有文档。
        {
            "query":{
                "multi_match":{
                    "query":"chm",
                    "fields":["name","detailInfo.PERS_INFO_CH"]
                }
            }
        }

    d、语法查询：
        {
            "query":{
                "query_string":{
                    "query":"(Elasticsearch AND 入门)  OR charmingfst"
                }
            }
        }

        查询author和title中包含”Elasticsearch”或者”张三”的文档：
        {
            "query":{
                "query_string":{
                    "query":"Elasticsearch OR 张三",
                    "fields":["author", "title"]
                }
            }
        }

2、 字段级别查询：针对结构化数据，如数字、日期等，对于文本的搜索，term查询并非像mysql中的=一样
    term 查询被用于精确值匹配，term 查询对于输入的文本不分析，所以它将给定的值进行精确查询
    {
        "query":{
            "term":{
                "name":"张三"
            }
        }
    }

    字段级别查询支持范围查询
    {
        "query":{
            "range":{
                "publish_date":{
                    "gt":"2017-01-01",
                    "lte":"now"
                }
            }
        }
    }


* Filter context
……

三、复合条件查询：以一定的逻辑组合子条件查询
……


四、scroll api
http://localhost:9200/dayeegame_cand/_search?scroll=1m
{
  "query": {
    "match_all": {}
  },
  "from": 0,
  "size": 1000,
  "_source": {
    "includes": [
      "resumeId"
    ]
  }
}


http://localhost:9200/_search/scroll
{
  "scroll": "1m",
  "scroll_id": "DnF1ZXJ5VGhlbkZldGNoBQAAAAAAAbcYFmNUbEhtdVpsUWlLMm5TQ2x2TEI5THcAAAAAAAG3FhZjVGxIbXVabFFpSzJuU0NsdkxCOUx3AAAAAAABtxkWY1RsSG11WmxRaUsyblNDbHZMQjlMdwAAAAAAAbcXFmNUbEhtdVpsUWlLMm5TQ2x2TEI5THcAAAAAAAG3GhZjVGxIbXVabFFpSzJuU0NsdkxCOUx3"
}

