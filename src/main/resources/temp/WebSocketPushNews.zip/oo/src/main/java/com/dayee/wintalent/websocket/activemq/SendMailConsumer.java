package com.dayee.wintalent.websocket.activemq;

import java.util.List;
import java.util.Map;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;
import com.alibaba.fastjson.JSONObject;
import com.dayee.wintalent.websocket.utils.EmailUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class SendMailConsumer {

    @JmsListener(destination = "schedule.reminder.mail.queue")
    public void receiveQueue(String message) {

        JSONObject jsonObject = JSONObject.parseObject(message);
        String corpCode = jsonObject.getString("corpCode");
        String data = jsonObject.getString("paramData");
        JSONObject param = JSONObject.parseObject(data);
        Map<Integer, List<Integer>> paramMap = (Map) param;

        log.debug("corpCode:" + corpCode+ ", params:" + paramMap);
        // 调接口发送邮件
        EmailUtil.sendMail(corpCode, paramMap);
    }

}
