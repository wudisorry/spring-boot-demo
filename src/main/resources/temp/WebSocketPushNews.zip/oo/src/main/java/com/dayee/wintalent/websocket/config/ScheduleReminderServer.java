package com.dayee.wintalent.websocket.config;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;

import javax.websocket.*;
import javax.websocket.Session;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;


import com.dayee.wintalent.websocket.datasource.DynamicDataSourceContextHolder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSONObject;
import com.dayee.wintalent.websocket.constants.Constants;
import com.dayee.wintalent.websocket.utils.CollectionUtil;


@Slf4j
@ServerEndpoint("/scheduleReminder/{corpCode}/{userId}")
@Component
public class ScheduleReminderServer {

    //静态变量，用来记录当前在线连接数。应该把它设计成线程安全的。
    private static int                                          onlineCount = 0;

    //concurrent包的线程安全Set，用来存放每个客户端对应的ScheduleReminderServer对象。
    private static CopyOnWriteArraySet<ScheduleReminderServer>  webSocketSet = new CopyOnWriteArraySet<>();

    //与某个客户端的连接会话，需要通过它来给客户端发送数据
    private Session                                             session;

    //corpCode
    private String                                              corpCode;

    //接收userId
    private Integer                                             userId;

    /**
     * 连接建立成功调用的方法*/
    @OnOpen
    public void onOpen(Session session,
                       @PathParam("corpCode") String corpCode,
                       @PathParam("userId") Integer userId) {

        this.userId = userId;
        this.corpCode = corpCode;
        this.session = session;
        if (!DynamicDataSourceContextHolder.corpDataSourceMap.containsKey(corpCode)) {
            log.info(corpCode + "该企业尚未注册，请联系管理员！");
            return;
        }
        log.debug("onOpen...");
        webSocketSet.add(this); //加入set中
        addOnlineCount(); //在线数加1
        log.info("有新窗口开始监听:"+corpCode+" - "+userId+",当前在线人数为" + getOnlineCount() + ",sessionId:" + session.getId() + ", session size:" + webSocketSet.size());

    }

    /**
     * 连接关闭调用的方法
     */
    @OnClose
    public void onClose() {

        boolean remove = webSocketSet.remove(this); //从set中删除
        if (remove) {
            subOnlineCount(); //在线数减1
            log.info("有一连接关闭！当前在线人数为" + getOnlineCount()+ ", session size:" + webSocketSet.size());
        }
    }

    /**
     * 收到客户端消息后调用的方法
     *
     * @param message 客户端发送过来的消息*/
    @OnMessage
    public void onMessage(String message, Session session) {

        log.debug("收到来自窗口"+corpCode + " - " + userId+"的信息:"+message);
    }

    /**
     *
     * @param session
     * @param error
     */
    @OnError
    public void onError(Session session, Throwable error) {


        boolean remove = webSocketSet.remove(this); //从set中删除
        if (remove) {
            subOnlineCount(); //在线数减1
            log.info("发生错误！有一连接关闭！当前在线人数为" + getOnlineCount()+ ", session size:" + webSocketSet.size());
        }
        log.error(error.getMessage());
    }

    /**
     * 实现服务器主动推送
     */
    public void sendMessage(String message) throws IOException {

        try {
            if (this.session.isOpen()) {
                this.session.getBasicRemote().sendText(message);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

    }

    /**
     * 群发自定义消息
     * */
    public static void sendInfo(String corpCode, Map<Integer, List<Integer>> corpCalendarMap) {

        JSONObject obj = null;
        for (ScheduleReminderServer server : webSocketSet) {
            try {
                if (server.corpCode.equals(corpCode)) {
                    List<Integer> calendarIdList = corpCalendarMap.get(server.userId);
                    if (CollectionUtil.notEmpty(calendarIdList)) {
                        obj = new JSONObject();
                        obj.put("status", Constants.YES);
                        obj.put("list", calendarIdList);
                        server.sendMessage(obj.toJSONString());
                    }
                }
            } catch (IOException e) {
                log.error(e.getMessage(), e);
            }
        }
    }

    public static synchronized int getOnlineCount() {
        return onlineCount;
    }

    public static synchronized void addOnlineCount() {
        ScheduleReminderServer.onlineCount++;
    }

    public static synchronized void subOnlineCount() {
        ScheduleReminderServer.onlineCount--;
    }

    public static void reset() {
        webSocketSet.clear();
        onlineCount = 0;
    }
}
