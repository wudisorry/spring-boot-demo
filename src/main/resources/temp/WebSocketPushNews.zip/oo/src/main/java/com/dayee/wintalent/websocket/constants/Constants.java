package com.dayee.wintalent.websocket.constants;

public class Constants {

    // 简历类别
    public static final Integer RESUME_TYPE_CANDIDATE_RESUME            = 1;

    public static final Integer RESUME_TYPE_TALENT_POOL_RESUME          = 2;

    public static final Integer RESUME_TYPE_ADDRESS_USER                = 3;

    //语言
    public static final Integer LANGUAGE_TYPE_CH                        = 1;

    public static final Integer LANGUAGE_TYPE_EN                        = 2;

    public static final int     YES                                     = 0;

    public static final int     NO                                      = 1;

    public static final int     FTP_OR_MAIL_ATTEMPT_TIME                = 5;
}
