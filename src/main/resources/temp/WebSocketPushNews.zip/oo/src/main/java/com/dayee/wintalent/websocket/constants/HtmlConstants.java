package com.dayee.wintalent.websocket.constants;

public class HtmlConstants {

    public static final String SEND_MAIL_TABLE_     = "<table style=\"border: 1px solid #b4d2f0;width: 100%;text-align: left;border-collapse: collapse;text-indent:0;\">";

    public static final String _TABLE               = "</table>";

    public static final String SEND_MAIL_TR_TITLE_  = "<tr style=\"background:#fff\">";

    public static final String SEND_MAIL_TR_        = "<tr style=\"background:#eef7ff;\">";

    public static final String TH_                  = "<th style=\"white-space:nowrap;text-align:left;padding-left:10px;padding-top:5px;padding-bottom:5px;line-height:30px;font-family:'Microsoft YaHei';font-size:14px;\">";

    public static final String _TH                  = "</th>";

    public static final String _TR                  = "</tr>";

    public static final String TD_NOWRAP_           = "<td style=\"text-align:left;white-space:nowrap;padding-left:10px;line-height:20px;font-family:'Microsoft YaHei';font-size:14px;\">";

    public static final String TD_                  = "<td style=\"text-align:left;padding-left:10px;line-height:20px;font-family:'Microsoft YaHei';font-size:14px;\">";

    public static final String _TD                  = "</td>";

    public static final String A_OP_                = "<a target=\"_blank\" style=\"color:#08c;text-decoration:none\" href=\"";

    public static final String _A_OP                = "</a>";

    public static final String _NODE                = "\">";
}
