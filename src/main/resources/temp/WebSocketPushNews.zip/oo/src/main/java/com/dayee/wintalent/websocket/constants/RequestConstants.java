package com.dayee.wintalent.websocket.constants;

public class RequestConstants {


    public static final String ATTR_USER_ID_KEY             = "userId";

    public static final String ATTR_CORP_CODE_KEY           = "corpCode";

    public static final String CONSOLE                      = "CONSOLE";
}
