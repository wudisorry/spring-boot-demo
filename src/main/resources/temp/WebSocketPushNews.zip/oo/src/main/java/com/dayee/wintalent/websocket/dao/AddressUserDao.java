package com.dayee.wintalent.websocket.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.dayee.wintalent.websocket.entity.AddressUser;

@Repository
public interface AddressUserDao {

    List<AddressUser> selectAddressUserListById(@Param("uniqueKeyList")List<Integer> uniqueKeyList);
}
