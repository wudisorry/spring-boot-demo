package com.dayee.wintalent.websocket.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.dayee.wintalent.websocket.entity.PersonalCalendar;

@Repository
public interface CalendarDao {

    /**
     *
     * @param beginDate
     * @param endDate
     * @return
     */
    List<PersonalCalendar> selectCalendarList(@Param("beginDate") String beginDate,
                                              @Param("endDate") String endDate);
}
