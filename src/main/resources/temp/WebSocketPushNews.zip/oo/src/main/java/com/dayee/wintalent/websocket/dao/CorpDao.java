package com.dayee.wintalent.websocket.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.dayee.wintalent.websocket.entity.Corp;

@Repository
public interface CorpDao {

    List<Corp> getCorpList();
}
