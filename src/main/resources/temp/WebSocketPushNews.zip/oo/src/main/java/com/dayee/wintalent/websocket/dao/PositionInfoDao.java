package com.dayee.wintalent.websocket.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.dayee.wintalent.websocket.entity.Position;

@Repository
public interface PositionInfoDao {

    List<Position> selectPostListById(@Param("postIdList")List<Integer> postIdList);
}
