package com.dayee.wintalent.websocket.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.dayee.wintalent.websocket.entity.CorpUser;

@Repository
public interface UserDao {

    List<CorpUser> getCorpUserList(@Param("userIdList") List<Integer> userIdList);
}
