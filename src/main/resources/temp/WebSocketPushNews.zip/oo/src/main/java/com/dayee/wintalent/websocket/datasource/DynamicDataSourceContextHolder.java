package com.dayee.wintalent.websocket.datasource;

import java.util.LinkedHashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dayee.wintalent.websocket.entity.Corp;
import com.dayee.wintalent.websocket.utils.StringUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * @Author zhangheng
 * @Date 2018-12-12
 * @Description 动态数据源上下文管理
 */
@Slf4j
public class DynamicDataSourceContextHolder {

    /**
     * 存放当前线程使用的数据源类型信息
      */
    private static final ThreadLocal<String>        CURRENT_ALIAS       = new ThreadLocal<String>();

    /**
     * 存放数据源CorpMap
     */
    public static Map<String, Corp>                 corpDataSourceMap   = new LinkedHashMap<>();


    /**
     * 设置数据源
     * @param corpCode
     */
    public static void setAlias(String corpCode) {

        if (StringUtil.hasLength(corpCode, true)) {
            CURRENT_ALIAS.set(corpCode);
        }
    }

    /**
     * 获取数据源
     * @return
     */
    public static String getAlias() {

        return CURRENT_ALIAS.get();
    }

    /**
     * 清除上下文数据
     */
    public static void clearAlias() {

        CURRENT_ALIAS.remove();
    }

    /**
     * 判断当前数据源是否存在
     * @param corpCode
     * @return
     */
    public static boolean isContainsDataSource(String corpCode) {

        return corpDataSourceMap.containsKey(corpCode);
    }

    private static Corp getCurrentCorp() {

        String alias = getAlias();
        if (alias != null) {
            return corpDataSourceMap.get(alias);
        }
        return null;
    }

    public static String getDataSourceRouterKey() {

        Corp corp = getCurrentCorp();
        String ds = null;
        if (corp != null) {
            ds = corp.getHost();
        }
        return ds;
    }
}
