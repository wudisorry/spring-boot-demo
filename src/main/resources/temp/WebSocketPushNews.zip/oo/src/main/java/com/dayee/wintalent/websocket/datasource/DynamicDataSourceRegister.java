package com.dayee.wintalent.websocket.datasource;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.MutablePropertyValues;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.GenericBeanDefinition;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.EnvironmentAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportBeanDefinitionRegistrar;
import org.springframework.core.env.Environment;
import org.springframework.core.type.AnnotationMetadata;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.util.CollectionUtils;

import com.dayee.wintalent.websocket.entity.Corp;
import com.dayee.wintalent.websocket.utils.StringUtil;

import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;

@Slf4j
@Configuration
public class DynamicDataSourceRegister implements ImportBeanDefinitionRegistrar, EnvironmentAware {

    private DataSource                      defaultDataSource;

    private Map<String, DataSource>         slaveDataSources        = new HashMap<>();

    private static final String             DATASOURCE_TYPE_DEFAULT = "com.alibaba.druid.pool.DruidDataSource";

    private static final String             DRIVER_TYPE_DEFAULT     = "com.mysql.jdbc.Driver";

    @Bean(name = "dataSource")
    public DynamicDataSource dataSource() {

        DynamicDataSource dynamicDataSource = new DynamicDataSource();
        dynamicDataSource.setDefaultTargetDataSource(defaultDataSource);

        // 配置多数据源
        Map<Object, Object> targetDataSources = new HashMap(5);
        targetDataSources.put("dataSource", this.defaultDataSource);
        targetDataSources.putAll(slaveDataSources);
        dynamicDataSource.setTargetDataSources(targetDataSources);

        return dynamicDataSource;
    }

    @Override
    public void setEnvironment(Environment environment) {

        initDefaultDataSource(environment);
        initSlaveDataSources(environment);
    }

    private void initDefaultDataSource(Environment env) {

        // 读取主数据源
        Map<String, Object> dsMap = new HashMap<>();
        dsMap.put("type", env.getProperty("spring.datasource.type"));
        dsMap.put("driver",
                env.getProperty("spring.datasource.driver-class-name"));
        dsMap.put("url", env.getProperty("spring.datasource.url"));
        dsMap.put("username", env.getProperty("spring.datasource.username"));
        dsMap.put("password", env.getProperty("spring.datasource.password"));
        defaultDataSource = buildDataSource(env, dsMap);
    }

    private void initSlaveDataSources(Environment env) {

        String dataSourceType = env.getProperty("spring.datasource.type");
        if (StringUtil.isEmpty(dataSourceType)) {
            dataSourceType = DATASOURCE_TYPE_DEFAULT;
        }
        String driverClassName = env.getProperty("spring.datasource.driver-class-name");
        if (StringUtils.isEmpty(driverClassName)) {
            driverClassName = DRIVER_TYPE_DEFAULT;
        }
        // 读取配置文件获取更多数据源
        Map<String, Map<String, Object>> dsMap = new LinkedHashMap<>();
        JdbcTemplate template = new JdbcTemplate(defaultDataSource);
        List<Map<String, Object>> list = template
                .queryForList("select * from t_corp_info");
        if (!CollectionUtils.isEmpty(list)) {
            // 一个端口一个数据源
            for (Map<String, Object> entry : list) {
                String code = (String) entry.get("F_CODE");
                if ("console".equalsIgnoreCase(code)) {
                    continue;
                }
                String url = (String) entry.get("F_DATABASE_URL");
                if (!StringUtil.hasLength(url, true)) {
                    url = env.getProperty("spring.datasource.url");
                    url = url.substring(0, url.lastIndexOf("/"));
                }
                String db = (String) entry.get("F_DATABASE_NAME");
                if (StringUtil.hasLength(db, true)) {
                    url += "/" + db;
                }
                if (!dsMap.containsKey(url)) {
                    Map<String, Object> map = new LinkedHashMap<>();
                    String user = (String) entry.get("F_DATABASE_USERNAME");
                    String pwd = (String) entry.get("F_DATABASE_PASSWORD");
                    map.put("url", url);
                    map.put("username", user);
                    map.put("password", pwd);
                    map.put("type", dataSourceType);
                    map.put("driver", driverClassName);

                    if (!StringUtil.hasLength(user, true)
                            && !StringUtil.hasLength(pwd, true)) {
                        String sysUserName = (String) entry
                                .get("F_DATABASE_SYSTEM_USERNAME");
                        String sysPwd = (String) entry
                                .get("F_DATABASE_SYSTEM_PASSWORD");
                        if (!StringUtil.hasLength(sysUserName, true)
                                && !StringUtil.hasLength(sysPwd, true)) {
                            sysUserName = env
                                    .getProperty("spring.datasource.username");
                            sysPwd = env.getProperty("spring.datasource.password");
                        }
                        map.put("username", sysUserName);
                        map.put("password", sysPwd);
                    }

                    dsMap.put(url, map);
                }
                DynamicDataSourceContextHolder.corpDataSourceMap
                        .put(code, new Corp(code, db, url));
            }
        }
        for (Map.Entry<String, Map<String, Object>> entry : dsMap.entrySet()) {
            Map<String, Object> map = entry.getValue();
            String url = (String) map.get("url");
            DataSource ds = buildDataSource(env, map);
            slaveDataSources.put(url, ds);
        }
    }

    private Class<? extends DataSource> getDataSourceType(Object type) {

        if (type == null) {
            type = DATASOURCE_TYPE_DEFAULT;
        }
        try {
            return (Class<? extends DataSource>) Class.forName((String) type);
        } catch (Exception e) {
            log.error("{}", e.getMessage(), e);
            throw new IllegalArgumentException("can not resolve class with type: " + type);
        }
    }

    public DataSource buildDataSource(Environment env,
                                      Map<String, Object> dataSourceMap) {

        Object type = dataSourceMap.get("type");
        Class<? extends DataSource> dataSourceType = getDataSourceType(type);
        String driverClassName = dataSourceMap.get("driver").toString();
        String url = dataSourceMap.get("url").toString();

        String otherConfig = env.getProperty("spring.datasource.otherConfig");
        if (StringUtil.hasLength(otherConfig, true)) {
            url += otherConfig;
        } else {
            url += "?serverTimezone=GMT%2B8&zeroDateTimeBehavior=convertToNull&useOldAliasMetadataBehavior=true&useUnicode=true&characterEncoding=utf-8&useSSL=false";
        }
        String username = dataSourceMap.get("username").toString();
        String password = dataSourceMap.get("password").toString();
        // 自定义DataSource配置
        DataSourceBuilder factory = DataSourceBuilder.create()
                .driverClassName(driverClassName).url(url).username(username)
                .password(password).type(dataSourceType);

        return factory.build();
    }

    @Override
    public void registerBeanDefinitions(AnnotationMetadata importingClassMetadata,
                                        BeanDefinitionRegistry registry) {

        Map<Object, Object> targetDataSources = new HashMap<Object, Object>();
        // 添加默认数据源
        targetDataSources.put("dataSource", this.defaultDataSource);
        // 添加其他数据源
        targetDataSources.putAll(slaveDataSources);

        // 创建DynamicDataSource
        GenericBeanDefinition beanDefinition = new GenericBeanDefinition();
        beanDefinition.setBeanClass(DynamicDataSource.class);
        beanDefinition.setSynthetic(true);
        MutablePropertyValues mpv = beanDefinition.getPropertyValues();
        mpv.addPropertyValue("defaultTargetDataSource", defaultDataSource);
        mpv.addPropertyValue("targetDataSources", targetDataSources);
        // 注册 - BeanDefinitionRegistry
        registry.registerBeanDefinition("dataSource", beanDefinition);
        log.debug("Dynamic DataSource Registry");
    }
}
