package com.dayee.wintalent.websocket.entity;

import com.dayee.wintalent.websocket.utils.StringUtil;

public class AddressUser extends Entity {


    private String gender;

    private String position;

    private String email;

    private String mobile; // 手机

    private String phone; // 电话

    private String company;

    private String department;

    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getGenderStr() {

        String genderStr = "";
        if (StringUtil.hasLength(gender)) {
            if (gender.trim().equals("0/599/604")) {
                genderStr = "男";
            } else if (gender.trim().equals("0/599/605")) {
                genderStr= "女";
            }
        }
        return genderStr;
    }
}
