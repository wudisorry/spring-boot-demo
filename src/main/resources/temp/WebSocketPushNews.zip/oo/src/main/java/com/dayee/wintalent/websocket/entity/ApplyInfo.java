package com.dayee.wintalent.websocket.entity;

import java.util.Date;

public class ApplyInfo extends Entity {

    private Integer             resumeId;

    private Integer             postId;

    private String              postName;

    private String              externalPostName;

    private Date                applyDate;

    protected Integer           applyStatus;

    /* 应聘状态 类型 */
    private Integer             applyStatusType;

    public Integer getResumeId() {
        return resumeId;
    }

    public void setResumeId(Integer resumeId) {
        this.resumeId = resumeId;
    }

    public Integer getPostId() {
        return postId;
    }

    public void setPostId(Integer postId) {
        this.postId = postId;
    }

    public String getPostName() {
        return postName;
    }

    public void setPostName(String postName) {
        this.postName = postName;
    }

    public String getExternalPostName() {
        return externalPostName;
    }

    public void setExternalPostName(String externalPostName) {
        this.externalPostName = externalPostName;
    }

    public Date getApplyDate() {
        return applyDate;
    }

    public void setApplyDate(Date applyDate) {
        this.applyDate = applyDate;
    }

    public Integer getApplyStatus() {
        return applyStatus;
    }

    public void setApplyStatus(Integer applyStatus) {
        this.applyStatus = applyStatus;
    }

    public Integer getApplyStatusType() {
        return applyStatusType;
    }

    public void setApplyStatusType(Integer applyStatusType) {
        this.applyStatusType = applyStatusType;
    }
}
