package com.dayee.wintalent.websocket.entity;

import java.util.Date;

import com.dayee.wintalent.websocket.utils.StringUtil;

public class CandidatesPersInfo extends Entity {

    private Integer           resumeId;

    private String            name;

    private String            idNum;

    private String            mobilePhone;

    private String            email;

    private String            gender;

    private Date              birthday;

    private Date              birthdayFull;

    private String            accountPlace;

    private String            livingPlace;

    private String            workYears;

    private String            school;

    private Date              graduationDate;

    private String            subject;

    private String            firstSubject;

    private String            education;

    private Integer           photoId;


    public Integer getResumeId() {
        return resumeId;
    }

    public void setResumeId(Integer resumeId) {
        this.resumeId = resumeId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIdNum() {
        return idNum;
    }

    public void setIdNum(String idNum) {
        this.idNum = idNum;
    }

    public String getMobilePhone() {
        return mobilePhone;
    }

    public void setMobilePhone(String mobilePhone) {
        this.mobilePhone = mobilePhone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public Date getBirthdayFull() {
        return birthdayFull;
    }

    public void setBirthdayFull(Date birthdayFull) {
        this.birthdayFull = birthdayFull;
    }

    public String getAccountPlace() {
        return accountPlace;
    }

    public void setAccountPlace(String accountPlace) {
        this.accountPlace = accountPlace;
    }

    public String getLivingPlace() {
        return livingPlace;
    }

    public void setLivingPlace(String livingPlace) {
        this.livingPlace = livingPlace;
    }

    public String getWorkYears() {
        return workYears;
    }

    public void setWorkYears(String workYears) {
        this.workYears = workYears;
    }

    public String getSchool() {
        return school;
    }

    public void setSchool(String school) {
        this.school = school;
    }

    public Date getGraduationDate() {
        return graduationDate;
    }

    public void setGraduationDate(Date graduationDate) {
        this.graduationDate = graduationDate;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getFirstSubject() {
        return firstSubject;
    }

    public void setFirstSubject(String firstSubject) {
        this.firstSubject = firstSubject;
    }

    public String getEducation() {
        return education;
    }

    public void setEducation(String education) {
        this.education = education;
    }

    public Integer getPhotoId() {
        return photoId;
    }

    public void setPhotoId(Integer photoId) {
        this.photoId = photoId;
    }

    public String getGenderStr() {

        String genderStr = "";
        if (StringUtil.hasLength(gender)) {
            if (gender.trim().equals("0/599/604")) {
                genderStr = "男";
            } else if (gender.trim().equals("0/599/605")) {
                genderStr= "女";
            }
        }
        return genderStr;
    }
}
