
package com.dayee.wintalent.websocket.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.dayee.wintalent.websocket.constants.RequestConstants;


public class Corp extends Entity {

    private String        code;

    private String        corpName;

    private int           port;

    private String        user;

    private String        password;

    private String        db;

    private String        host;

    private Date          registerDate;

    private Date          abateDate;

    public Corp() {

    }

    public Corp(String code, String db, String host) {

        this.code = code;
        this.db = db;
        this.host = host;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public int getPort() {

        return port;
    }

    public void setPort(int port) {

        this.port = port;
    }

    public String getUser() {

        return user;
    }

    public void setUser(String user) {

        this.user = user;
    }

    public String getPassword() {

        return password;
    }

    public void setPassword(String password) {

        this.password = password;
    }

    public String getDb() {

        return db;
    }

    public void setDb(String db) {

        this.db = db;
    }

    public String getHost() {

        return host;
    }

    public void setHost(String host) {

        this.host = host;
    }

    public String getCorpName() {

        return corpName;
    }

    public void setCorpName(String corpName) {

        this.corpName = corpName;
    }

    public Date getRegisterDate() {
        return registerDate;
    }

    public void setRegisterDate(Date registerDate) {
        this.registerDate = registerDate;
    }

    public Date getAbateDate() {
        return abateDate;
    }

    public void setAbateDate(Date abateDate) {
        this.abateDate = abateDate;
    }

    public boolean isConsole() {

        return RequestConstants.CONSOLE.equalsIgnoreCase(code);
    }

    public boolean isValid() {

        Date now = new Date();

        if (registerDate != null && registerDate.after(now)) {
            return false;
        }

        if (abateDate != null && abateDate.before(now)) {
            return false;
        }

        return true;

    }
}
