package com.dayee.wintalent.websocket.entity;

import java.util.Date;
import java.util.List;

public class CorpUser extends Entity {

    private String            userName;

    private String            realName;

    private String            password;

    private String            email;

    private Date              registerDate;

    private Date              abateDate;

    private String            phone;

    private String            orgId;

    private Integer           isSendMail;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Date getRegisterDate() {
        return registerDate;
    }

    public void setRegisterDate(Date registerDate) {
        this.registerDate = registerDate;
    }

    public Date getAbateDate() {
        return abateDate;
    }

    public void setAbateDate(Date abateDate) {
        this.abateDate = abateDate;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getOrgId() {
        return orgId;
    }

    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    public Integer getIsSendMail() {
        return isSendMail;
    }

    public void setIsSendMail(Integer isSendMail) {
        this.isSendMail = isSendMail;
    }
}
