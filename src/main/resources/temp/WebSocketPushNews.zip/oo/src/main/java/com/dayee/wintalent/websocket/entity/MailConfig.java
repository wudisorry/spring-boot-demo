
package com.dayee.wintalent.websocket.entity;

import com.dayee.wintalent.websocket.constants.Constants;
import com.dayee.wintalent.websocket.utils.AESUtils;
import com.dayee.wintalent.websocket.utils.StringUtil;

import lombok.extern.slf4j.Slf4j;


@Slf4j
public class MailConfig extends Entity {


    /** [多个发送邮箱] 自定义发件人称呼 */
    private String              showSendName;

    private String              address;

    private String              userName;

    private String              password;

    private String              smtpServer;

    private Integer             smtpPort;

    private Integer             sslStatus;

    private Integer             tlsStatus;

    private Integer             tryTime;

    private Integer             sendMode         = 0;                                         // 0

    // -默认配置
    // ,1
    // -360Mail,2
    // -qunar

    private String              mailToken;                                                    // 360

    // email
    // token

    private Integer             remainMailNum;                                                // 剩余邮件发送数量

    private Integer             isEws;                                                        // 是否exchange
                                                                                               // 邮箱
    
    private Integer             evType;
    
    private String              servicePassword;
    
    private Integer              labelId;
    
	public Integer getLabelId() {
		return labelId;
	}

	public void setLabelId(Integer labelId) {
		this.labelId = labelId;
	}

	public String getServicePassword() {
		return servicePassword;
	}
    
	public void setServicePassword(String servicePassword) {
		this.servicePassword = servicePassword;
	}

	public Integer getEvType() {
    
        return evType;
    }
    
    public void setEvType(Integer evType) {
    
        this.evType = evType;
    }

    public synchronized void removeMailNum() {

        if (this.getRemainMailNum() != null) {
            remainMailNum--;
        }
    }

    public boolean isDefaultSendMode() {

        return sendMode != null && sendMode.equals(Constants.YES);
    }

    public Integer getRemainMailNum() {

        return remainMailNum != null ? remainMailNum : 0;
    }

    public void setRemainMailNum(Integer remainMailNum) {

        this.remainMailNum = remainMailNum;
    }

    public boolean is360Mail() {

        return sendMode != null && sendMode.equals(Constants.NO);
    }

    public boolean isQunarMail() {

        return sendMode != null && sendMode.equals(2);
    }
    
    //上海外服项目
    public boolean isSHproMail() {

        return sendMode != null && sendMode.equals(4);
    }

    public Integer getSendMode() {

        return sendMode;
    }

    public void setSendMode(Integer sendMode) {

        this.sendMode = sendMode;
    }

    public String getMailToken() {

        return mailToken;
    }

    public void setMailToken(String mailToken) {

        this.mailToken = mailToken;
    }

    public int getIntTryTime() {

        return tryTime == null || tryTime < 1 || tryTime > 10
                                                             ? Constants.FTP_OR_MAIL_ATTEMPT_TIME
                                                             : tryTime;
    }

    public Integer getTryTime() {

        return tryTime;
    }

    public void setTryTime(Integer tryTime) {

        this.tryTime = tryTime;
    }

    public boolean isSsl() {

        return sslStatus != null && sslStatus.equals(Constants.YES);
    }

    public Integer getSslStatus() {

        return sslStatus;
    }

    public void setSslStatus(Integer sslStatus) {

        this.sslStatus = sslStatus;
    }

    public String getUserName() {

        return userName;
    }

    public void setUserName(String userName) {

        this.userName = userName;
    }

    public boolean canSendMail() {

        return (isDefaultSendMode() && StringUtil.hasLength(getAddress())
                && StringUtil.hasLength(getPassword()) && StringUtil
                .hasLength(getSmtpServer())) || (is360Mail() && StringUtil
                       .hasLength(mailToken))
               || (isQunarMail() && StringUtil.hasLength(mailToken, true))
               || (isSHproMail() && StringUtil.hasLength(servicePassword, true));
    }

    public String getShowName() {

        StringBuffer sb = new StringBuffer();
        if (StringUtil.hasLength(showSendName)) {
            sb.append(showSendName);
        }
        sb.append(" ( ");
        if (is360Mail()) {
            sb.append("360Email");
        } else if (isQunarMail()) {
            sb.append("Qunar Email");
        } else if (isSHproMail()){
        	sb.append("SHpro Email");
        } else {
            sb.append("SMTP");
        }
        sb.append(" )");
        return sb.toString();
    }

    public String getAddress() {

        return address;
    }

    public Integer getSmtpPort() {

        return smtpPort;
    }

    public void setSmtpPort(Integer smtpPort) {

        this.smtpPort = smtpPort;
    }

    public void setAddress(String address) {

        this.address = address;
    }

    public String getPassword() {

        return password;
    }

    public String getDecrypPassword() {

        String simplePwd = null;
        try {
            simplePwd = AESUtils.decrypt(password);
        } catch (Exception e) {
            // 解密失败，有可能就是明文密码，这里不需要error级别
            log.warn(e.getMessage(), e);
        }
        if (StringUtil.hasLength(simplePwd, true)) {
            return simplePwd;
        }

        return password;
    }

    public void setPassword(String password) {

        this.password = password;
    }

    public String getSmtpServer() {

        return smtpServer;
    }

    public void setSmtpServer(String smtpServer) {

        this.smtpServer = smtpServer;
    }

    public String getShowSendName() {

        return showSendName;
    }

    public void setShowSendName(String showSendName) {

        this.showSendName = showSendName;
    }

    public Integer getIsEws() {

        return isEws;
    }

    public void setIsEws(Integer isEws) {

        this.isEws = isEws;
    }

    public boolean isUseEws() {

        return isEws != null && isEws.equals(Constants.YES);
    }

    public Integer getTlsStatus() {

        return tlsStatus;
    }

    public void setTlsStatus(Integer tlsStatus) {

        this.tlsStatus = tlsStatus;
    }

    public boolean isTls() {

        return tlsStatus != null && tlsStatus.equals(Constants.YES);
    }
}
