package com.dayee.wintalent.websocket.entity;

import java.util.List;

public class MailPojo {

    public static final int BATCH_SIZE = 100;

    public static final int SHEEP_TIME = 1000;

    private String           corpCode;

    private PersonalCalendar personalCalendar;

    public String getCorpCode() {
        return corpCode;
    }

    public void setCorpCode(String corpCode) {
        this.corpCode = corpCode;
    }

    public PersonalCalendar getPersonalCalendar() {
        return personalCalendar;
    }

    public void setPersonalCalendar(PersonalCalendar personalCalendar) {
        this.personalCalendar = personalCalendar;
    }
}
