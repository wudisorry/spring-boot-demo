package com.dayee.wintalent.websocket.entity;

import com.dayee.wintalent.websocket.constants.Constants;

import java.util.Date;

public class PersonalCalendar extends Entity {

    private Integer           uniqueKey;

    private String            type;

    private Date              beginDate;                                    // 开始时间

    private Date              endDate;                                      // 结束时间

    private String            name;                                         // 个人事件标题

    private String            content;                                      // 人事件对应内容

    private Integer           addUser;                                      // 添加人

    private Integer           fromUserId;                                   //  来自哪个用户共享

    private Integer           sendEmail;

    private Integer           resumeType;

    private Integer           applyId;

    private Integer           resumeId;

    private Date              nextRemindDate;

    private String            candidateName;

    private String            postName;

    private String            orgDetailInfo;

    private String            applyStatusStr;

    private String            beginDateStr;

    private String            beginTimeStr;

    private String            detailContent;

    public Integer getUniqueKey() {
        return uniqueKey;
    }

    public void setUniqueKey(Integer uniqueKey) {
        this.uniqueKey = uniqueKey;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Date getBeginDate() {
        return beginDate;
    }

    public void setBeginDate(Date beginDate) {
        this.beginDate = beginDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Integer getAddUser() {
        return addUser;
    }

    public void setAddUser(Integer addUser) {
        this.addUser = addUser;
    }

    public Integer getFromUserId() {
        return fromUserId;
    }

    public void setFromUserId(Integer fromUserId) {
        this.fromUserId = fromUserId;
    }

    public boolean sendEmail() {
        return sendEmail != null && sendEmail.equals(Constants.YES);
    }

    public Integer getSendEmail() {
        return sendEmail;
    }

    public void setSendEmail(Integer sendEmail) {
        this.sendEmail = sendEmail;
    }

    public Integer getResumeType() {
        return resumeType;
    }

    public void setResumeType(Integer resumeType) {
        this.resumeType = resumeType;
    }

    public Integer getApplyId() {
        return applyId;
    }

    public void setApplyId(Integer applyId) {
        this.applyId = applyId;
    }

    public Integer getResumeId() {
        return resumeId;
    }

    public void setResumeId(Integer resumeId) {
        this.resumeId = resumeId;
    }

    public Date getNextRemindDate() {
        return nextRemindDate;
    }

    public void setNextRemindDate(Date nextRemindDate) {
        this.nextRemindDate = nextRemindDate;
    }

    public String getCandidateName() {
        return candidateName;
    }

    public void setCandidateName(String candidateName) {
        this.candidateName = candidateName;
    }

    public String getPostName() {
        return postName;
    }

    public void setPostName(String postName) {
        this.postName = postName;
    }

    public String getOrgDetailInfo() {
        return orgDetailInfo;
    }

    public void setOrgDetailInfo(String orgDetailInfo) {
        this.orgDetailInfo = orgDetailInfo;
    }

    public String getApplyStatusStr() {
        return applyStatusStr;
    }

    public void setApplyStatusStr(String applyStatusStr) {
        this.applyStatusStr = applyStatusStr;
    }

    public String getBeginDateStr() {
        return beginDateStr;
    }

    public void setBeginDateStr(String beginDateStr) {
        this.beginDateStr = beginDateStr;
    }

    public String getBeginTimeStr() {
        return beginTimeStr;
    }

    public void setBeginTimeStr(String beginTimeStr) {
        this.beginTimeStr = beginTimeStr;
    }

    public String getDetailContent() {
        return detailContent;
    }

    public void setDetailContent(String detailContent) {
        this.detailContent = detailContent;
    }
}
