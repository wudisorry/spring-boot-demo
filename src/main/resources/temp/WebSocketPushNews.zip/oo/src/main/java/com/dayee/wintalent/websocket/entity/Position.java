package com.dayee.wintalent.websocket.entity;

import com.dayee.wintalent.websocket.utils.StringUtil;

public class Position extends Entity {

    private Integer                             orgId;

    private Integer                             postStatus;

    private Integer                             recruitType;

    /* 缺省的职位Id */
    public static final int                     DEFAULT_POST_ID                 = 0;

    public Integer getOrgId() {
        return orgId;
    }

    public void setOrgId(Integer orgId) {
        this.orgId = orgId;
    }

    public Integer getPostStatus() {
        return postStatus;
    }

    public void setPostStatus(Integer postStatus) {
        this.postStatus = postStatus;
    }

    public Integer getRecruitType() {
        return recruitType;
    }

    public void setRecruitType(Integer recruitType) {
        this.recruitType = recruitType;
    }

    public String getName() {

        if (StringUtil.hasLength(cnName)) {
            return cnName;
        } else {
            return enName;
        }
    }
}
