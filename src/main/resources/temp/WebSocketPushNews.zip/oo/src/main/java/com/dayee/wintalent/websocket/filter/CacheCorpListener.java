package com.dayee.wintalent.websocket.filter;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import com.dayee.wintalent.websocket.utils.StringUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;

import com.dayee.wintalent.websocket.entity.Corp;
import com.dayee.wintalent.websocket.service.CorpService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@WebListener
public class CacheCorpListener implements ServletContextListener {

    @Resource
    private RedisTemplate redisTemplate;

    @Resource
    private CorpService corpService;

    @Value("${spring.profiles.active}")
    private String  activeProfile;

    public static final String ALL_CORP_LIST_CACHE = "SCHEDULE_REMINDER_ALL_CORP_LIST_CACHE";

    @Override
    public void contextInitialized(ServletContextEvent sce) {

        log.debug("ServletContextListener 上下文初始化...");
        //清除缓存中的corp数据
        String corpKey = getAllCorpListCacheKey(activeProfile);
        redisTemplate.delete(corpKey);
        //查询console库所有的企业
        List<Corp> corpList = corpService.getCorpList();
        //将数据放入缓存中
        redisTemplate.opsForList().leftPushAll(corpKey, corpList);
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {

        log.debug("ServletContextListener 上下文销毁...");
    }

    public static String getAllCorpListCacheKey(String activeProfile) {

        if (StringUtil.isEmpty(activeProfile)) {
            return ALL_CORP_LIST_CACHE;
        }
        return activeProfile + StringUtil.UNDERLINE + ALL_CORP_LIST_CACHE;
    }
}
