//package com.dayee.wintalent.websocket.filter;
//
//import java.io.IOException;
//
//import javax.servlet.*;
//import javax.servlet.annotation.WebFilter;
//import javax.servlet.http.HttpServletRequest;
//
//import org.springframework.boot.web.servlet.ServletComponentScan;
//import org.springframework.stereotype.Component;
//
//import com.dayee.wintalent.websocket.utils.RequestUtil;
//
//import lombok.extern.slf4j.Slf4j;
//
//@Slf4j
//@Component
//@ServletComponentScan
//@WebFilter(urlPatterns = "/*", filterName = "dataSourceFilter")
//public class DataSourceFilter implements Filter {
//
//    @Override
//    public void init(FilterConfig filterConfig) throws ServletException {
//
//    }
//
//    @Override
//    public void doFilter(ServletRequest request,
//                         ServletResponse response,
//                         FilterChain chain) throws IOException, ServletException {
//
//
//        HttpServletRequest req = (HttpServletRequest) request;
//        RequestUtil.setSession(req.getSession());
//        //String corpCode = request.getParameter("corpCode");
//        //DynamicDataSourceContextHolder.setAlias(corpCode);
//
//        String url = req.getRequestURI();
//        log.debug("request url ---" + url);
//
//        chain.doFilter(request, response);
//    }
//
//    @Override
//    public void destroy() {
//
//    }
//}
