package com.dayee.wintalent.websocket.resources;

import java.util.Locale;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;

import com.dayee.wintalent.websocket.utils.StringUtil;

public class Messages {

    @Autowired
    private static MessageSource messageSource;

    public static String getMessage(String key) {

        if (!StringUtil.hasLength(key, true)) {
            return null;
        }
        Locale locale = LocaleContextHolder.getLocale();
        String message = messageSource.getMessage(key, null, locale);
        if (!StringUtil.hasLength(message)) {
            message = key;
        }

        return message;
    }
}
