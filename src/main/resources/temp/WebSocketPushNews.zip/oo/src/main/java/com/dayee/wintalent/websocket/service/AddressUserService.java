package com.dayee.wintalent.websocket.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dayee.wintalent.websocket.dao.AddressUserDao;
import com.dayee.wintalent.websocket.entity.AddressUser;
import org.springframework.transaction.annotation.Transactional;

@Transactional
@Service
public class AddressUserService {

    @Autowired
    private AddressUserDao addressUserDao;

    public List<AddressUser> selectAddressUserListById(List<Integer> uniqueKeyList) {

        return addressUserDao.selectAddressUserListById(uniqueKeyList);
    }
}
