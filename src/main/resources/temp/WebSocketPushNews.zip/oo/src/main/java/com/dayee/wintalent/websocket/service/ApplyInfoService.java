package com.dayee.wintalent.websocket.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dayee.wintalent.websocket.dao.ApplyInfoDao;
import com.dayee.wintalent.websocket.entity.ApplyInfo;
import org.springframework.transaction.annotation.Transactional;

@Transactional
@Service
public class ApplyInfoService {

    @Autowired
    private ApplyInfoDao applyInfoDao;

    public List<ApplyInfo> selectApplyInfoById(List<Integer> applyIdList) {

        return applyInfoDao.selectApplyInfoById(applyIdList);
    }
}
