package com.dayee.wintalent.websocket.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dayee.wintalent.websocket.dao.CalendarDao;
import com.dayee.wintalent.websocket.entity.PersonalCalendar;
import org.springframework.transaction.annotation.Transactional;

@Transactional
@Service
public class CalendarService {

    @Autowired
    private CalendarDao calendarDao;

    public List<PersonalCalendar> selectCalendarList(@Param("beginDate") String beginDate,
                                                     @Param("endDate") String endDate) {

        return calendarDao.selectCalendarList(beginDate, endDate);
    }
}
