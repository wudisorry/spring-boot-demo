package com.dayee.wintalent.websocket.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dayee.wintalent.websocket.dao.CandidatesDao;
import com.dayee.wintalent.websocket.entity.CandidatesPersInfo;
import org.springframework.transaction.annotation.Transactional;

@Transactional
@Service
public class CandidatesService {

    @Autowired
    private CandidatesDao candidatesDao;

    public List<CandidatesPersInfo> selectCandidatesByResumeId(List<Integer> resumeIdList) {

        return candidatesDao.selectCandidatesByResumeId(resumeIdList);
    }
}
