package com.dayee.wintalent.websocket.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.dayee.wintalent.websocket.dao.CorpDao;
import com.dayee.wintalent.websocket.entity.Corp;
import org.springframework.transaction.annotation.Transactional;

@Transactional
@Service
public class CorpService {

    @Autowired
    private CorpDao corpDao;

    public List<Corp> getCorpList() {

        return corpDao.getCorpList();
    }
}
