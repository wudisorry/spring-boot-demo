package com.dayee.wintalent.websocket.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dayee.wintalent.websocket.dao.PositionInfoDao;
import com.dayee.wintalent.websocket.entity.Position;
import org.springframework.transaction.annotation.Transactional;

@Transactional
@Service
public class PositionInfoService {

    @Autowired
    private PositionInfoDao positionInfoDao;

    public List<Position> selectPostListById(List<Integer> postIdList) {

        return positionInfoDao.selectPostListById(postIdList);
    }
}
