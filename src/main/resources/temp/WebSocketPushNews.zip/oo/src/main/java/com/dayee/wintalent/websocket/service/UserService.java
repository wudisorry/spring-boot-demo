package com.dayee.wintalent.websocket.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dayee.wintalent.websocket.dao.UserDao;
import com.dayee.wintalent.websocket.entity.CorpUser;
import org.springframework.transaction.annotation.Transactional;

@Transactional
@Service
public class UserService {

    @Autowired
    private UserDao userDao;

    public List<CorpUser> getCorpUserList(List<Integer> userIdList) {

        return userDao.getCorpUserList(userIdList);
    }
}
