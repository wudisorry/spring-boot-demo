package com.dayee.wintalent.websocket.timer;

import java.util.*;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.jms.core.JmsTemplate;

import com.alibaba.fastjson.JSONObject;
import com.dayee.wintalent.websocket.config.ScheduleReminderServer;
import com.dayee.wintalent.websocket.datasource.DynamicDataSourceContextHolder;
import com.dayee.wintalent.websocket.entity.Corp;
import com.dayee.wintalent.websocket.entity.PersonalCalendar;
import com.dayee.wintalent.websocket.service.CalendarService;
import com.dayee.wintalent.websocket.utils.CollectionUtil;
import com.dayee.wintalent.websocket.utils.DateUtil;
import com.dayee.wintalent.websocket.utils.SpringUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class BatchHandleCorpThread implements Runnable {

    private Integer    number;

    private List<Corp> corpList;

    private CalendarService calendarService;

    private JmsTemplate jmsTemplate;

    public BatchHandleCorpThread(Integer number, List<Corp> corpList, JmsTemplate jmsTemplate) {

        this.number = number;
        this.corpList = corpList;
        this.jmsTemplate = jmsTemplate;
    }

    private void init() {

        if (calendarService == null) {
            calendarService = (CalendarService) SpringUtil.getBean("calendarService");
        }
    }

    @Override
    public void run() {

        for (Corp corp : corpList) {
            String corpCode = corp.getCode();
            if (!corp.isConsole() && corp.isValid()) {
                DynamicDataSourceContextHolder.setAlias(corpCode);
                init();
                try {
                    getCalendarInfo(corpCode);
                } catch (Exception e) {
                    log.error("异常,企业名：" + corpCode
                            + ":"
                            + ExceptionUtils.getStackTrace(e));
                }
            }
        }
    }

    private void getCalendarInfo(String corpCode) throws Exception {

        DynamicDataSourceContextHolder.setAlias(corpCode);
        String date = DateUtil.formatYMDHM(new Date());
        String beginDate = date + ":00";
        String endDate = date + ":59";

        List<PersonalCalendar> calendarList =  calendarService
                .selectCalendarList(beginDate, endDate);
        log.debug("corpCode:" + corpCode + ", beginDate-endDate:" + beginDate + "-" + endDate + "，size:" + calendarList.size());

        if (CollectionUtil.notEmpty(calendarList)) {
            Map<Integer, List<Integer>> userCalendarMap = new HashMap<>();
            Map<Integer, List<Integer>> sendEmailCalendarMap = new HashMap<>();
            for (PersonalCalendar calendar : calendarList) {
                Integer addUser = calendar.getAddUser();
                Integer calendarId = calendar.getUniqueKey();
                List<Integer> calendarIdList = userCalendarMap.get(addUser);
                if (calendarIdList == null) {
                    calendarIdList = new ArrayList<>();
                }
                calendarIdList.add(calendarId);
                userCalendarMap.put(addUser, calendarIdList);
                if (calendar.sendEmail()) {
                    List<Integer> list = sendEmailCalendarMap.get(addUser);
                    if (list == null) {
                        list = new ArrayList<>();
                    }
                    list.add(calendarId);
                    sendEmailCalendarMap.put(addUser, list);
                }
            }
            if (CollectionUtil.notEmpty(userCalendarMap)) {
                try {
                    ScheduleReminderServer.sendInfo(corpCode, userCalendarMap);
                } catch (Exception e) {
                    log.error("发送websocket消息异常,企业名：" + corpCode
                            + ":"
                            + ExceptionUtils.getStackTrace(e));
                }
            }
            if (CollectionUtil.notEmpty(sendEmailCalendarMap)) {
                try {
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("corpCode", corpCode);
                    jsonObject.put("paramData",sendEmailCalendarMap);
                    // 使用activemq异步处理发送邮件
                    jmsTemplate.convertAndSend("schedule.reminder.mail.queue",
                            jsonObject.toJSONString());
                } catch (Exception e) {
                    log.error("发送消息到activemq队列异常,企业名：" + corpCode
                            + ":"
                            + ExceptionUtils.getStackTrace(e));
                }
            }
        }
    }

    public List<Corp> getCorpList() {
        return corpList;
    }

    public void setCorpList(List<Corp> corpList) {
        this.corpList = corpList;
    }

    public Integer getNumber() {
        return number;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }

    public JmsTemplate getJmsTemplate() {
        return jmsTemplate;
    }

    public void setJmsTemplate(JmsTemplate jmsTemplate) {
        this.jmsTemplate = jmsTemplate;
    }
}
