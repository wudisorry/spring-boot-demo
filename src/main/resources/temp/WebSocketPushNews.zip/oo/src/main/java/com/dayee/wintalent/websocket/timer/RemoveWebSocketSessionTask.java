package com.dayee.wintalent.websocket.timer;

import com.dayee.wintalent.websocket.config.ScheduleReminderServer;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

@Configuration
public class RemoveWebSocketSessionTask {

    @Scheduled(cron = "0 0 3 * * ?")
    public void execute() throws Exception {

        ScheduleReminderServer.reset();
    }
}
