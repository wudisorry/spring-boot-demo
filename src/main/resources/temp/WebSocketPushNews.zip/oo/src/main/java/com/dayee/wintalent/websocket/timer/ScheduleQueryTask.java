package com.dayee.wintalent.websocket.timer;

import java.util.List;
import java.util.concurrent.*;


import com.google.common.util.concurrent.ThreadFactoryBuilder;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.scheduling.annotation.Scheduled;

import com.dayee.wintalent.websocket.entity.Corp;
import com.dayee.wintalent.websocket.filter.CacheCorpListener;
import com.dayee.wintalent.websocket.utils.*;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Configuration
public class ScheduleQueryTask {

    private final static ThreadFactory NAMED_THREAD_FACTORY = new ThreadFactoryBuilder()
            .setNameFormat("W-scheduleReminder-%d").build();

    @Autowired
    private RedisTemplate                   redisTemplate;

    @Autowired
    private JmsTemplate                     jmsTemplate;

    @Value("${spring.profiles.active}")
    private String                          activeProfile;

    private static final int                BATCH_SIZE = 5;

    private static ThreadPoolExecutor       executor = new ThreadPoolExecutor(130, 200, 120L, TimeUnit.SECONDS,
            new ArrayBlockingQueue<Runnable>(50), NAMED_THREAD_FACTORY, new ThreadPoolExecutor.DiscardOldestPolicy());

    @Scheduled(cron = "0 0/1 * * * ?")
    public void execute() throws Exception {

        List<Corp> list = null;
        try {
            String cacheKey = CacheCorpListener.getAllCorpListCacheKey(activeProfile);
            list = redisTemplate.opsForList()
                    .range(cacheKey, 0, -1);
        } catch (Exception e) {
            log.error("获得全部企业error：" + ExceptionUtils.getStackTrace(e));
        }
        if (CollectionUtil.isNotEmpty(list)) {
            List<List<Corp>> corpList = CollectionUtil.splitList(list, BATCH_SIZE);
            int size = corpList.size();
            for (int i = 0; i < size; i++) {
                BatchHandleCorpThread thread = new BatchHandleCorpThread(i, corpList.get(i), jmsTemplate);
                executor.execute(thread);
            }
        } else {
            log.error("corpList is null");
        }
    }
}
