
package com.dayee.wintalent.websocket.utils;

import java.security.Key;
import java.security.SecureRandom;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base32;
import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * AES 加密/解密
 * @author Administrator
 *
 */
public class AESUtils {

    private static final Logger logger = LoggerFactory.getLogger(AESUtils.class);
    
    public static final String KEY = "vuUJLULu4GGszgck";

    private static final String charset = "utf-8";
    private static String key="f9ffd6b95e2641f6adadc292c8769e97";

    public static String encryptAnli(String plainText) {
        Key secretKey = getKey();
        try {
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.ENCRYPT_MODE, secretKey);
            byte[] p = plainText.getBytes(charset);
            byte[] result = cipher.doFinal(p);

            Base32 base32 = new Base32();

            return base32.encodeToString(result);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private static Key getKey() {
        try {
            SecureRandom secureRandom = SecureRandom.getInstance("SHA1PRNG");
            secureRandom.setSeed(key.getBytes());
            KeyGenerator generator = KeyGenerator.getInstance("AES");
            generator.init(secureRandom);
            return generator.generateKey();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }



    public static void main(String[] args) throws Exception {
    	
    	String ss = new String("张殿鹏".getBytes(),"UTF-8");
    	
    	String jaon = "{\"userName\":\"dpzhang\",\"realName\":\""+ss+"\",\"email\":\"dpzhang@qq.com\",\"staffNum\":\"2016062511\",\"date\":\"201606281353\"}";
    	
    	//String jaon = "{\"userName\":\"dpzhang\",\"date\":\"201606272035\"}";
        
        String cSrc = "100010&201411171855";
        String kSrc=AESUtils.encrypt(jaon, "vLongFor4sTkgzny");
        
        String dSrc = AESUtils.decrypt(kSrc, "vLongFor4sTkgzny");
        
        
        System.out.println("加密后："+kSrc);
        
        System.out.println("解密后："+dSrc);
    }
    
    public static String decrypt(String sSrc) throws Exception {
        
        return decrypt(sSrc,KEY);
    }
    
    public static String encrypt(String sSrc) throws Exception {
        
        return encrypt(sSrc,KEY);
    }

    public static String decrypt(String sSrc,String key) throws Exception {

        try {
            // 判断Key是否正确
            if (key == null) {
                System.out.print("Key为空null");
                return null;
            }
            // 判断Key是否为16位
            if (key.length() != 16) {
                System.out.print("Key长度不是16位");
                return null;
            }
            byte[] raw = key.getBytes("ASCII");
            SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            cipher.init(Cipher.DECRYPT_MODE, skeySpec);
            byte[] encrypted1 = hex2byte(sSrc);
            byte[] original = cipher.doFinal(encrypted1);
            String originalString = "";
            originalString = new String(original);

            return originalString;
        } catch (Exception ex) {
            logger.error("AES解密错误："+sSrc);
            return null;
        }
    }
    
    public static String decryptUTF(String sSrc,String key) throws Exception {

        try {
            // 判断Key是否正确
            if (key == null) {
                System.out.print("Key为空null");
                return null;
            }
            // 判断Key是否为16位
            if (key.length() != 16) {
                System.out.print("Key长度不是16位");
                return null;
            }
            byte[] raw = key.getBytes("ASCII");
            SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            cipher.init(Cipher.DECRYPT_MODE, skeySpec);
            byte[] encrypted1 = hex2byte(sSrc);
            byte[] original = cipher.doFinal(encrypted1);
            String originalString = "";
            originalString = new String(original,"UTF-8");
            return originalString;
        } catch (Exception ex) {
            logger.error(ex.getMessage(),ex);
            return null;
        }
    }
    
    public static String decrypt2(String input, String key) {

        byte[] output = null;

        try {
 
            SecretKeySpec skey = new SecretKeySpec(key.getBytes(), "AES");

            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");

            cipher.init(Cipher.DECRYPT_MODE, skey);

            output = cipher.doFinal(Base64.decodeBase64(input.getBytes()));
            return new String(output,"UTF-8");

        } catch (Exception e) {
            logger.error(e.getMessage(),e);
        }

        return null;

    }

    // 判断Key是否正确
    public static String encrypt(String sSrc,String key) throws Exception {

        if (key == null) {
            System.out.print("Key为空null");
            return null;
        }
        // 判断Key是否为16位
        if (key.length() != 16) {
            System.out.print("Key长度不是16位");
            return null;
        }
        byte[] raw = key.getBytes("ASCII");
        SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
        byte[] encrypted = cipher.doFinal(sSrc.getBytes());
        return byte2hex(encrypted).toLowerCase();
    }

    public static byte[] hex2byte(String strhex) {

        if (strhex == null) {
            return null;
        }
        int l = strhex.length();
        if (l % 2 == 1) {
            return null;
        }
        byte[] b = new byte[l / 2];
        for (int i = 0; i != l / 2; i++) {
            b[i] = (byte) Integer.parseInt(strhex.substring(i * 2, i * 2 + 2),
                                           16);
        }
        return b;
    }

    public static String byte2hex(byte[] b) {

        String hs = "";
        String stmp = "";
        for (int n = 0; n < b.length; n++) {
            stmp = (Integer.toHexString(b[n] & 0XFF));
            if (stmp.length() == 1) {
                hs = hs + "0" + stmp;
            } else {
                hs = hs + stmp;
            }
        }
        return hs.toUpperCase();
    }
}