package com.dayee.wintalent.websocket.utils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CollectionUtil extends
        org.apache.commons.collections.CollectionUtils {

    private static final Logger logger = LoggerFactory.getLogger(CollectionUtil.class);

    public static boolean notEmpty(Collection<?> coll) {

        return coll != null && coll.size() > 0;
    }

    public static boolean notEmpty(Map map) {

        return map != null && map.size() > 0;
    }

    public static <E extends List> E splitList(List<?> list, int splitSize) {

        if (CollectionUtil.isEmpty(list)) {
            return null;
        }
        int size = list.size();
        int fromIndex = 0;
        int toIndex = splitSize;
        List<List<?>> result = new ArrayList<List<?>>();
        if (size < splitSize) {
            result.add(list);
        } else {

            while (fromIndex < toIndex) {
                result.add(list.subList(fromIndex, toIndex));
                fromIndex = toIndex;
                toIndex += splitSize;
                if (toIndex > size) {
                    toIndex = size;
                }
            }
        }

        return (E) result;
    }

}
