package com.dayee.wintalent.websocket.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtil extends org.apache.commons.lang3.time.DateUtils {


    public static final String   DATE_FORMAT_YMDHMS        = "yyyy-MM-dd HH:mm:ss";

    public static final String   DATE_FORMAT_YMDHM         = "yyyy-MM-dd HH:mm";

    public static String formatYMDHMS(Date date) {

        if (date == null) {
            return null;
        }
        SimpleDateFormat format = new SimpleDateFormat(DATE_FORMAT_YMDHMS);
        return format.format(date);
    }

    public static String formatYMDHM(Date date) {

        if (date == null) {
            return null;
        }
        SimpleDateFormat format = new SimpleDateFormat(DATE_FORMAT_YMDHM);
        return format.format(date);
    }
}
