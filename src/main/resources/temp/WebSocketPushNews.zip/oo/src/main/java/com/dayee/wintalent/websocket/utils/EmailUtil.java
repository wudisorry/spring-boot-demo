package com.dayee.wintalent.websocket.utils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.alibaba.fastjson.JSONObject;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class EmailUtil {

    private static String        API_KEY = "123456";

    private static String        mailUrl;

    public static String getMailUrl() {
        return mailUrl;
    }

    @Value("${wintalent.system.mailUrl}")
    public void setMailUrl(String mailUrl) {
        EmailUtil.mailUrl = mailUrl;
    }

    public static void sendMail(String corpCode, Map<Integer, List<Integer>> paramMap) {

        if (StringUtil.hasLength(mailUrl, true)) {
            if (StringUtils.hasLength(corpCode)&&CollectionUtil.notEmpty(paramMap)) {

                Map<String, Object> dataMap = new HashMap<>();
                dataMap.put("apiKey", API_KEY);
                dataMap.put("corpCode", corpCode);
                dataMap.put("paramData", JSONObject.toJSON(paramMap));
                String content = HttpClientUtil.executePost(mailUrl,
                        dataMap, null, null);

                log.debug(content);
            }
        } else {
            log.error("未配置mailUrl接口地址！");
        }
    }
}
