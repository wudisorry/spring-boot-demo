package com.dayee.wintalent.websocket.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class HttpClientUtil {

    private static HttpEntity generateHttpEntity(Map<String, Object> paramMap, String... encoding) throws Exception {

        List<NameValuePair> formParams = new ArrayList<NameValuePair>();
        if (MapUtils.isNotEmpty(paramMap)) {
            for (Map.Entry<String, Object> entry : paramMap.entrySet()) {
                formParams.add(new BasicNameValuePair(entry.getKey(), entry.getValue().toString()));
            }
        }
        if (ArrayUtils.isNotEmpty(encoding)) {
            return new UrlEncodedFormEntity(formParams, encoding[0]);
        } else {
            return new UrlEncodedFormEntity(formParams, "utf-8");
        }
    }

    private static HttpPost addHeaders(HttpPost httpPost, Map<String, String> headerMap) {

        if (MapUtils.isNotEmpty(headerMap)) {
            for (Map.Entry<String, String> entry : headerMap.entrySet()) {
                httpPost.addHeader(entry.getKey(), entry.getValue());
            }
        }
        return httpPost;
    }

    private static HttpPost generateHttpPost(String url, Map<String, Object> paramMap, Map<String, String> headerMap)
            throws Exception {

        HttpEntity httpEntity = generateHttpEntity(paramMap);
        HttpPost httpPost = new HttpPost(url);
        httpPost.setEntity(httpEntity);
        addHeaders(httpPost, headerMap);
        return httpPost;
    }

    private static HttpClient generateHttpClient() {
        try {
            SslUtil.ignoreSsl();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return new DefaultHttpClient();
    }

    private static String generateResponseString(HttpResponse response, String encoding) throws Exception {

        String result = null;
        if (response.getEntity() != null) {
            if (StringUtil.hasLength(encoding, true)) {
                result = IOUtils.toString(response.getEntity().getContent(), encoding);
            } else {
                result = IOUtils.toString(response.getEntity().getContent());
            }
            IOUtils.closeQuietly(response.getEntity().getContent());
        }
        return result;
    }

    public static String executePost(String url,
                                     Map<String, Object> paramMap,
                                     Map<String, String> headerMap,
                                     String encoding) {

        String result = null;
        HttpClient httpClient = null;
        try {
            httpClient = generateHttpClient();
            HttpPost httpPost = generateHttpPost(url, paramMap, headerMap);
            HttpResponse response = httpClient.execute(httpPost);
            result = generateResponseString(response, encoding);
        } catch (Exception e) {
            log.error(ExceptionUtils.getStackTrace(e));
        } finally {
            if (httpClient != null) {
                httpClient.getConnectionManager().shutdown();
            }
        }
        return result;
    }
}
