package com.dayee.wintalent.websocket.utils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import com.dayee.wintalent.websocket.constants.RequestConstants;

public class RequestUtil {

    private static final Logger logger = LoggerFactory.getLogger(RequestUtil.class);

    static ThreadLocal<HttpServletRequest> requestHolder = new ThreadLocal<HttpServletRequest>();

    static ThreadLocal<HttpSession> sessionHolder = new ThreadLocal<HttpSession>();

    public static void setSession(HttpSession session) {

        sessionHolder.set(session);
    }

    public static HttpSession getSession() {

        return sessionHolder.get();
    }

    public static void setRequest(HttpServletRequest request) {

        requestHolder.set(request);
    }

    public static HttpServletRequest getRequest() {

        return requestHolder.get();
    }

    //    public static HttpServletRequest getRequest() {
//
//        ServletRequestAttributes servletRequestAttributes
//              = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
//
//        logger.debug("getRequest() --- servletRequestAttributes ---" + servletRequestAttributes);
//        if (servletRequestAttributes == null) {
//            return null;
//        }
//
//        HttpServletRequest request = servletRequestAttributes.getRequest();
//        logger.debug("getRequest() --- request ---" + request);
//        if (request == null) {
//            return null;
//        }
//
//        return request;
//    }


    public static void setUserId(Integer userId) {

        HttpServletRequest request = RequestUtil.getRequest();
        logger.debug("setUserId() --- request --- " + request);
        if (request == null) {
            return;
        }
        HttpSession session = request.getSession();
        logger.debug("setUserId() --- session --- " + session);
        if (session == null) {
            return;
        }

        session.setAttribute(RequestConstants.ATTR_USER_ID_KEY, userId);
    }

    public static Integer getUserId() {

//        HttpServletRequest request = RequestUtil.getRequest();
//        logger.debug("getUserId() --- request --- " + request);
//        if (request == null) {
//            return null;
//        }
        HttpSession session = RequestUtil.getSession();
        logger.debug("getUserId() --- session --- " + session);
        if (session == null || session
                .getAttribute(RequestConstants.ATTR_USER_ID_KEY) == null) {
            return null;
        }

        return (Integer) session
                .getAttribute(RequestConstants.ATTR_USER_ID_KEY);
    }

    public static void setCorpCode(String corpCode) {

        HttpServletRequest request = RequestUtil.getRequest();
        logger.debug("setCorpCode() --- request --- " + request);
        if (request == null) {
            return;
        }
        HttpSession session = request.getSession();
        logger.debug("setCorpCode() --- session --- " + session);
        if (session == null) {
            return;
        }

        session.setAttribute(RequestConstants.ATTR_CORP_CODE_KEY, corpCode);
    }

    public static String getCorpCode() {

//        HttpServletRequest request = RequestUtil.getRequest();
//        logger.debug("getCorpCode() --- request --- " + request);
//        if (request == null) {
//            return null;
//        }
        HttpSession session = RequestUtil.getSession();
        if (session == null) {
            return null;
        }
        logger.debug("getCorpCode() --- session --- " + session);
        return (String) session
                .getAttribute(RequestConstants.ATTR_CORP_CODE_KEY);
    }
}
