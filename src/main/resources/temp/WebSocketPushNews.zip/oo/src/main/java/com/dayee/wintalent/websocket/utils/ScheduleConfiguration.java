package com.dayee.wintalent.websocket.utils;


import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "wintalent")
public class ScheduleConfiguration {

    private static String calendarScheduleCorn;

    public static String getCalendarScheduleCorn() {
        return calendarScheduleCorn;
    }

    public void setCalendarScheduleCorn(String calendarScheduleCorn) {
        ScheduleConfiguration.calendarScheduleCorn = calendarScheduleCorn;
    }
}
