package com.dayee.wintalent.websocket.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StringUtil extends org.springframework.util.StringUtils {

    private static final Pattern PATTERN_NUMBER         = Pattern.compile("^[0-9]+(.[0-9]*)?$");

    public static final String   MH                     = "：";

    public static final String   EMPTY_SPACE            = " ";

    public static final String   UNDERLINE              = "_";

    /**
     * 判断字符串是否是数字
     *
     * @param str
     * @return
     */
    public static boolean isNumber(String str) {

        Matcher match = PATTERN_NUMBER.matcher(str);
        return match.matches();
    }

    public static boolean hasLength(CharSequence s, boolean isTrim) {

        if (s == null || s.length() == 0) {
            return false;
        }
        if (isTrim) {
            String str = s.toString().trim();
            return str.length() > 0;
        } else {
            return true;
        }
    }
}
